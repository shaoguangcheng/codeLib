#include <Eigen/Dense>
#include <iostream>

using namespace Eigen;
using namespace std;

int main(int, char**)
{
  cout.precision(3);
  Array3d v(-1,2,1), w(-3,2,3);
cout << ((v<w) || (v<0)) << endl;

  return 0;
}
