var searchData=
[
  ['x86_5f64_2dunknown_2dlinux_2dgnu_2fbits_2fcompatibility_2eh',['x86_64-unknown-linux-gnu/bits/compatibility.h',['http://gcc.gnu.org/onlinedocs/gcc-4.7.3/libstdc++/api/a01044.html',1,'']]]
];
