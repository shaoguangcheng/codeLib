var searchData=
[
  ['allocate_5fshared',['allocate_shared',['http://gcc.gnu.org/onlinedocs/gcc-4.7.3/libstdc++/api/a00467.html#a88995681205fbc4fa130e4c1c01266ba',1,'std::shared_ptr']]]
];
