%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function shape_classify_res(fname, varargin)

% get parameters
train_per = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9];
n_test    = 2;

if nargin > 1
    train_per = varargin{1};
end
if nargin > 2 
    n_test = varargin{2};
end

% load train/test feature/label data
fprintf('Load file: %s\n', fname);
load(fname);


% generate fea cell array
fea_cell = generate_fea_cell(opt, fea_train, lab_train, fea_test, lab_test);


test_acc = zeros(length(train_per), 2);
test_lst = {};

for i=1:length(train_per)
    acc_test_sum  = 0;
    acc_train_sum = 0;

    lst_train_all = [];
    lst_test_all  = [];
    
    [fea_train_, lab_train_, fea_test_, lab_test_] = ...
            generate_train_test_fea(opt, fea_cell, train_per(i));
            
    for j=1:n_test
        [acc_train, acc_test, lst_train, lst_test] = dbm_classify(opt, ...
            fea_train_, lab_train_, fea_test_, lab_test_);
        
        acc_train_sum = acc_train_sum + acc_train;
        acc_test_sum  = acc_test_sum  + acc_test;
        
        lst_train_all = [lst_train_all; lst_train];
        lst_test_all  = [lst_test_all; lst_test];
    end
    
    test_acc(i, 1) = acc_train_sum/n_test;
    test_acc(i, 2) = acc_test_sum/n_test;
    
    test_lst{i, 1} = lst_train_all;
    test_lst{i, 2} = lst_test_all;
    
    fprintf('   [%f] train_acc = %f, test_acc = %f\n', ...
        train_per(i), test_acc(i, 1), test_acc(i, 2));
end


% save all results and configurations
fn_base = opt.fn_dataset;
fn_res = sprintf('%s_%s_resall.mat', fn_base, s_timestamp);
save(fn_res);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fea_cell = generate_fea_cell(opt, fea_train, lab_train, fea_test, lab_test)

fea_cell = {};
n_cat = max(max(lab_train), max(lab_test));
idx_cat = zeros(n_cat, 1);

for i=1:length(lab_train)
    cat = lab_train(i);
    if( idx_cat(cat) <= 0 )
        c = {str2num(opt.fl_train{i, 1}), str2num(opt.fl_train{i, 2}), ...
            opt.fl_train{i, 3}, fea_train(i,:)};
        fea_cell{cat} = {c};
        idx_cat(cat) = idx_cat(cat) + 1; 
    else
        idx_cat(cat) = idx_cat(cat) + 1;
        fea_cell{cat}{idx_cat(cat)} = {str2num(opt.fl_train{i, 1}), ...
            str2num(opt.fl_train{i, 2}), ...
            opt.fl_train{i, 3}, fea_train(i,:)};
    end
end

for i=1:length(lab_test)
    cat = lab_test(i);
    if( idx_cat(cat) <= 0 )
        c = {str2num(opt.fl_test{i, 1}), str2num(opt.fl_test{i, 2}), ...
            opt.fl_test{i, 3}, fea_test(i,:)};
        fea_cell{cat} = {c};
        idx_cat(cat) = idx_cat(cat) + 1; 
    else
        idx_cat(cat) = idx_cat(cat) + 1;
        fea_cell{cat}{idx_cat(cat)} = {str2num(opt.fl_test{i, 1}), ...
            str2num(opt.fl_test{i, 2}), ...
            opt.fl_test{i, 3}, fea_test(i,:)};
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fea_train, lab_train, fea_test, lab_test] = ...
        generate_train_test_fea(opt, fea_cell, train_per)

n_cat = length(fea_cell);
fea_train = [];
lab_train = [];
fea_test  = [];
lab_test  = [];

for i=1:n_cat
    n_sample = length(fea_cell{i});
    n_train = round(n_sample*train_per);
    if( n_train < 1 ) 
        n_train = 1;
    end
    
    n_test = n_sample - n_train;
    if( n_test < 1 ) 
        n_test = 1;
        n_train = n_sample - n_test;
    end
    
    idx = randperm(n_sample);
    
    for j=1:n_train
        fea_train = [fea_train; fea_cell{i}{idx(j)}{4}];
        lab_train = [lab_train; fea_cell{i}{idx(j)}{2}];
    end
    
    for j=n_train+1:n_sample
        fea_test = [fea_test;   fea_cell{i}{idx(j)}{4}];
        lab_test = [lab_test;   fea_cell{i}{idx(j)}{2}];
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [acc_train, acc_test, lst_train, lst_test] = ...
    dbm_classify(opt, fea_train, lab_train, fea_test, lab_test)

% set local parameters
op.verbose  = 0;
op.maxepoch = opt.maxepoch;
op.eta      = opt.eta;

% Train a DBN
if ~isfield(opt, 'hn')
    opt.hn = [800, 800];
end
hn_n = length(opt.hn);

if( ~isfield(opt, 'RBM_type') )
    opt.RBM_type = 'BB';
end

if( strcmp(opt.RBM_type, 'GB') )
    fun_dbnFit = @dbnFit_GB;
else
    fun_dbnFit = @dbnFit;
end

if (hn_n == 1)
    models = fun_dbnFit(fea_train, opt.hn(1), lab_train, op);
elseif (hn_n == 2)
    models = fun_dbnFit(fea_train, opt.hn, lab_train, op, op);
elseif (hn_n == 3)
    models = fun_dbnFit(fea_train, opt.hn, lab_train, op, op, op);
elseif (hn_n == 4)
    models = fun_dbnFit(fea_train, opt.hn, lab_train, op, op, op, op);
else
    fprintf('WARN: unsupport hidden layer > 4\n');
    models = fun_dbnFit(fea_train, opt.hn(1:4), lab_train, op, op, op, op);
end

% Do classification
y_train = dbnPredict(models, fea_train);
y_test  = dbnPredict(models, fea_test);

acc_train = 1.0 - sum(y_train~=lab_train)/length(y_train);
acc_test  = 1.0 - sum(y_test~=lab_test)/length(y_test);

lst_train = [y_train, lab_train];
lst_test  = [y_test,  lab_test];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function save_classify_res(fname, res)

fid = fopen(fname, 'wt');

[n, m] = size(res);

for i=1:n
    for j=1:m
        fprintf(fid, '%d ', res(i, j));
    end
    fprintf(fid, '\n');
end

fclose(fid);

