%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function err_n = descriptor_batch_check(fn_dataset)
% Batch check calculated shape descriptors
%
% Parameters:
%   fn_dataset - input dataset name (exclude .ini)
%

% load config ini file
fn_ini = sprintf('%s.ini', fn_dataset);
ini = cini;
ini.read(fn_ini);

% get settings
p_data = ini.get_s('data_p');
subdir = ini.get_i('subdir');

err_n = 0;

if( subdir == 1 ) 
    % contains subdir
    dl = cpath.lsdir(p_data);
    dl_n = size(dl, 2);
    
    for i=1:dl_n
        fl = cpath.lsdir(dl{i});
        err_n = err_n + run_files(fl);
    end
else
    % only files
    fl = cpath.lsdir(p_data);
    err_n = err_n + run_files(fl);
end

fprintf('\nERR number = %d\n', err_n);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function err_n = run_files(fl)
% batch run a given file list
% parameter:
%   fl - file list cell array 1xn, element type is string
%

err_n = 0;

fl_n = size(fl, 2);

for i=1:fl_n
    fname = fl{i};
    
    % only process OFF file
    [fa fb fc] = fileparts(fname);
    if( ~ strcmpi(fc, '.off') ) 
        continue;
    end
    
    fn_base = sprintf('%s/%s', fa, fb);
   
    fprintf('-----------------------------------------------------------------------\n');
    fprintf('  %s\n', fname);
    fprintf('-----------------------------------------------------------------------\n');
    
    m = cmesh;
    m.load_off(fname);
    
    vmax = max(m.ver);
    vmin = min(m.ver);
    s = norm(vmax-vmin);
    fprintf('min = '); fprintf('%g ', vmin); fprintf('\n');
    fprintf('max = '); fprintf('%g ', vmax); fprintf('\n');
    fprintf('BB size = %g\n\n', s);
    
    
    finished = check_finished(fn_base);
    if( ~finished )
        err_n = err_n + 1;
        msg = sprintf('ERR: descriptor file not exist!  %s', fname);
        write_log('run_log.txt', msg);
        continue;
    end
    
    % check sihks
    fn = sprintf('%s_sihks', fn_base);
    d = load(fn);
    
    vmax = max(d);
    vmin = min(d);
    fprintf('min = '); fprintf('%g ', vmin); fprintf('\n');
    fprintf('max = '); fprintf('%g ', vmax); fprintf('\n');
    
    nn = sum(sum(isnan(d)));
    if( nn > 0 ) 
        err_n = err_n + 1;
        
        msg = sprintf('ERR: descriptor file not correct! exist NaN  %s', fname);
        write_log('run_log.txt', msg);
    end
    
    % check hks2
    fn = sprintf('%s_hks2', fn_base);
    d = load(fn);
    
    vmax = max(d);
    vmin = min(d);
    fprintf('min = '); fprintf('%g ', vmin); fprintf('\n');
    fprintf('max = '); fprintf('%g ', vmax); fprintf('\n');
    
    nn = sum(sum(isnan(d)));
    if( nn > 0 ) 
        err_n = err_n + 1;
        
        msg = sprintf('ERR: descriptor file not correct! exist NaN  %s', fname);
        write_log('run_log.txt', msg);
    end
    
    fprintf('\n');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function finished = check_finished(fn_base)
% check whether a given mesh is processed
% parameter:
%   fn_base - file basename (exclude extension)
%

arr_ext = {'sihks', 'agd', 'hks2'};
ext_n = length(arr_ext);

finished = 1;
for i=1:ext_n
    fn_desc = sprintf('%s_%s', fn_base, arr_ext{i});
    if( exist(fn_desc, 'file') < 2 )
        finished = 0;
    end
end
    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function write_log(fname, msg)
fid = fopen(fname, 'a+');
fprintf(fid, '%s\n', msg);
fclose(fid);
        
fprintf('%s\n', msg);

