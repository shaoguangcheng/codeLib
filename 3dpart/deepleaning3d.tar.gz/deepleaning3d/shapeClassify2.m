%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function shapeClassify2(fname, varargin)

argin     = varargin;
%fname_old = fname;

% load train/test feature/label data
%fn_buf = sprintf('%s_resall.mat', fname);
fprintf('Load file: %s\n\n', fname);
load(fname);

%fname   = fname_old;
fn_base = fname;

if( nargin > 1 )
    opt = argin{1};
else
    shape_opt;
end

% add subdir RBM
p = sprintf('%s/RBM', pwd);
addpath(p);
r = sprintf('%s/LSSVMlab_v1.8/toolbox',pwd);
addpath(r);

% set local parameters
op.verbose  = opt.verbose;
op.maxepoch = opt.maxepoch;
op.eta      = opt.eta;

% Train a DBN
if ~isfield(opt, 'hn')
    opt.hn = [800, 800];
end
opt.hn = [1000, 800];
hn_n = length(opt.hn);

if( ~isfield(opt, 'RBM_type') )
    opt.RBM_type = 'BB';
end

opt.RBM_type = 'BB_us';

if( strcmp(opt.RBM_type, 'GB') )
    fun_dbnFit = @dbnFit_GB;
elseif( strcmp(opt.RBM_type, 'BB_us') )
    fun_dbnFit = @dbnFit_us;
else
    fun_dbnFit = @dbnFit;
end

fprintf('Trainning DBN with ['); fprintf('%d ', opt.hn); fprintf(']:\n');

% shuffle the training data
if 1
    fea_train_x = [featureTrain; featureTest];
    lab_train_x = [trainLabel; testLabel];
else
    fea_train_x = featureTrain;
    lab_train_x = trainLabel;
end

perm_idx = randperm (size(fea_train_x,1));
fea_train_x = fea_train_x(perm_idx,:);
lab_train_x = lab_train_x(perm_idx);

% perform DBN trainning
if (hn_n == 1)
    models = fun_dbnFit(fea_train_x, opt.hn(1), lab_train_x, op);
elseif (hn_n == 2)
    models = fun_dbnFit(fea_train_x, opt.hn, lab_train_x, op, op);
elseif (hn_n == 3)
    models = fun_dbnFit(fea_train_x, opt.hn, lab_train_x, op, op, op);
elseif (hn_n == 4)
    models = fun_dbnFit(fea_train_x, opt.hn, lab_train_x, op, op, op, op);
else
    fprintf('WARN: unsupport hidden layer > 4\n');
    models = fun_dbnFit(fea_train_x, opt.hn(1:4), lab_train_x, op, op, op, op);
end

% save 
fn_dl_feature = sprintf('%s_dl_fea', fname);
save(fn_dl_feature, 'featureTrain', 'featureTest', 'trainLabel', 'testLabel', 'models', 'opt');

% Do classification
% if( strcmp(opt.RBM_type, 'BB_us') )
%     fea_hl_train = dbnPredict_us(models, featureTrain);
%     fea_hl_test  = dbnPredict_us(models, featureTest);
% 
%     model_svm = initlssvm(fea_hl_train, trainLabel, 'c', [], [], 'RBF_kernel');
%     model_svm = tunelssvm(model_svm, 'simplex', 'crossvalidatelssvm', {10,'misclass'}, 'code_OneVsOne');
%     model_svm = trainlssvm(model_svm);
% 
%     y_train   = simlssvm(model_svm, fea_hl_train);
%     y_test    = simlssvm(model_svm, fea_hl_test);
% else
%     y_train   = dbnPredict(models, featureTrain);
%     y_test    = dbnPredict(models, featureTest);
% end

save('model.mat','models')

y_train   = dbnPredict(models, featureTrain);
y_test    = dbnPredict(models, featureTest);

% print classification error
fprintf('\nClassification error (train) using DBN with ['); fprintf('%d ', opt.hn);
fprintf('] hiddens is %f %%\n', sum(y_train~=trainLabel)/length(y_train)*100.0);

fprintf('Classification error (test)  using DBN with ['); fprintf('%d ', opt.hn);
fprintf('] hiddens is %f %%\n', sum(y_test~=testLabel)/length(y_test)*100.0);

   
% save results
%opt.s_timestamp = s_timestamp;

% % save text results
% res_train = [y_train, lab_train];
% fn_res = sprintf('%s_%s_trainres', fn_base, s_timestamp);
% save_classify_res(fn_res, res_train);
% 
% res_test = [y_test, lab_test];
% fn_res = sprintf('%s_%s_testres', fn_base, s_timestamp);
% save_classify_res(fn_res, res_test);

% save all results and configurations
s_timestamp = cstring.date_stamp();
fn_base = 'xie_data_BOW_1000';
fn_res = sprintf('%s_%s_resall.mat', fn_base, s_timestamp);
save(fn_res);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function save_classify_res(fname, res)

fid = fopen(fname, 'wt');

[n, m] = size(res);

for i=1:n
    for j=1:m
        fprintf(fid, '%d ', res(i, j));
    end
    fprintf(fid, '\n');
end

fclose(fid);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function da = load_darray(fname)
% Load double array
% 
% Parameters:
%   fname  - input data file name
% Output:
%   da     - double data array

fid = fopen(fname, 'rb');
n   = fread(fid, 1, 'uint64');
da  = fread(fid, n, 'double');
fclose(fid);


