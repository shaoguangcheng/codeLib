X = 2.0*rand(100, 2) - 1;
Y = sign( sin(X(:,1)) + X(:,2) );

gam = 10;
sig2 = 0.4;
type = 'classification';

[alpha, b] = trainlssvm({X, Y, type, gam, sig2, 'RBF_kernel'});

Xt = 2.0*rand(10, 2)-1;
Yt = sign( sin(Xt(:,1)) + Xt(:,2) );
Ytest = simlssvm({X, Y, type, gam, sig2, 'RBF_kernel'}, {alpha, b}, Xt);

%plotlssvm({X, Y, type, gam, sig2, 'RBF_kernel'}, {alpha, b});
plotlssvm({Xt, Ytest, type, gam, sig2, 'RBF_kernel'}, {alpha, b});