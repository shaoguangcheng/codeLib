%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% set default parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

opt = struct;

% dataset configure filename
%opt.fn_dataset = './data/dataset_1_mcgill';
opt.fn_dataset = '/home/cheng/disk-data/shapeRetrieval/deep_leaning_3d/data/SHREC_2014_result';

% train sample percentage
opt.train_per  = 0.5;

% 3D shape deep-learning exe
opt.exe_dl     = './deep_learning_3d';

% descriptor settings

% selected features (feature name, column index)
opt.fea_field = { 
    'sihks', [1 2 3 4 5 6];
    'agd',   [1];
    %'curv',  [1];
};

% feature weight factor
opt.fea_w = [
    1.2, 1.1, 1, 0.8, 0.75, 0.7, ...        % sihks 1-6
    1.5, ...                                % agd
    %0.7                                     % curv (mean curveature)
];
opt.fea_min_max = [ ...
     2,  0,  0, 0, 0, 0, 0.6;
    25, 15, 12, 8, 7, 4, 2.4];

opt.fea_normalize = 1;                      % feature normalize

% SS-BoF parameters
opt.bow_d_sig   = -10;
opt.bow_d_k     = 2;
opt.gd_scale    = 10;
opt.bow_n       = 100;
opt.bow_sort    = 1;
opt.kmeans      = 0;
opt.kmeans_beta = 4;

opt.SSBOF_norm  = 0;

% DBM settings
opt.verbose   = true;
opt.maxepoch  = 1000;
opt.eta       = 0.1;

opt.RBM_type  = 'BB';                       % Bernoulli hidden and Bernoulli visible units
%opt.RBM_type  = 'GB';                       % Bernoulli hidden and Gaussian visible units

opt.hn        = [1000, 800,400];
