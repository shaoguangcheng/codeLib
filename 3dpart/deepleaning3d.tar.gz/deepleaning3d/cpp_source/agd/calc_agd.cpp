
/* different algorithms; multiple sources and targets
    Danil Kirsanov, 01/2008
*/

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <assert.h>

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "geodesic_algorithm_dijkstra.h"
#include "geodesic_algorithm_subdivision.h"
#include "geodesic_algorithm_exact.h"


int agd_method = 1;


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
double calc_dis(double *a, double *b)
{
    double      d, v1, v2, v3;

    v1 = a[0] - b[0];
    v2 = a[1] - b[1];
    v3 = a[2] - b[2];

    d = sqrt(v1*v1 + v2*v2 + v3*v3);
    return d;
}

double vec_dot_product(double *a, double *b)
{
    double  v;

    v = a[0]*b[0] + a[1]*b[1] + a[2]*b[2];
    return v;
}

void vec_cross_product(double *a, double *b, double *c)
{
    c[0] = a[1]*b[2] - a[2]*b[1];
    c[1] = a[2]*b[0] - a[0]*b[2];
    c[2] = a[0]*b[1] - a[1]*b[0];
}


double triangle_area(double *p1, double *p2, double *p3)
{
    double 	aa, bb, cc,
            s, S, q;

    aa=calc_dis(p1, p2);
    bb=calc_dis(p2, p3);
    cc=calc_dis(p3, p1);

    s = (aa+bb+cc)/2;
    q = s*(s-aa)*(s-bb)*(s-cc);
    if( q < 0.0 ) q = 0.0;

    S = sqrt(q);

    return S;
}

typedef std::vector<std::string> StringArray;

StringArray path_splitext(const std::string &fname)
{
    size_t      found;
    StringArray r;

    r.clear();

    // find .
    found = fname.find_last_of(".");
    if( found == std::string::npos ) {
        r.push_back(fname);
        r.push_back("");
        return r;
    }

    // filename
    r.push_back(fname.substr(0, found));
    // extname
    r.push_back(fname.substr(found));

    return r;
}

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

class MeshData {
public:
    int     vex_num, ele_num, edge_num;

    double  *vex_arr;
    int     *ele_arr;

public:
    MeshData();
    ~MeshData();

    void init(void);
    void free(void);

    int load(const char *fname);
    //int load_haveedge(HalfEdge *);

    int get_ele_by_vex(int vex_id, int *ele_n, int *ele);
    int calc_vex_norm(int vex_id, double *v);

    int get_vex_num(void) { return vex_num; }
    int get_ele_num(void) { return ele_num; }
    int get_vex(int vex_id, double *v);

    double *get_vex(void) { return vex_arr; }
    int    *get_ele(void) { return ele_arr; }

    double mesh_area(void);
};

MeshData::MeshData()
{
    init();
}

MeshData::~MeshData()
{
    free();
}

void MeshData::init(void)
{
    vex_num = 0;
    ele_num = 0;
    edge_num = 0;

    vex_arr = NULL;
    ele_arr = NULL;
}

void MeshData::free(void)
{
    if( vex_arr != NULL ) {
        delete vex_arr;
        vex_arr = NULL;
    }
    if( ele_arr != NULL ) {
        delete ele_arr;
        ele_arr = NULL;
    }

    vex_num = 0;
    ele_num = 0;
    edge_num = 0;
}

int MeshData::load(const char *fname)
{
    FILE    *fp;
    char    buf[2000];
    int     i;
    int     i1, i2, i3, i4;
    float   f1, f2, f3, f4;

    fp = fopen(fname, "r");
    assert(fp);

    // read file header
    fscanf(fp, "%s", buf);

    // read vertex, element, edege number
    fscanf(fp, "%d %d %d", &i1, &i2, &i3);

    this->free();
    vex_num = i1;
    ele_num = i2;
    vex_arr = new double[vex_num*3];
    ele_arr = new int[ele_num*3];

    // read vertex array
    for(i=0; i<vex_num; i++) {
        fscanf(fp, "%f %f %f", &f1, &f2, &f3);

        vex_arr[i*3+0] = f1;
        vex_arr[i*3+1] = f2;
        vex_arr[i*3+2] = f3;
    }

    // read element array
    for(i=0; i<ele_num; i++) {
        fscanf(fp, "%d %d %d %d", &i1, &i2, &i3, &i4);

        ele_arr[i*3+0] = i2;
        ele_arr[i*3+1] = i3;
        ele_arr[i*3+2] = i4;
    }

    fclose(fp);

    return 0;
}

/**
 *  Get elements which contain the vertex
 */
int MeshData::get_ele_by_vex(int vex_id, int *ele_n, int *ele)
{
    int     i, n;

    n = 0;
    for(i=0; i<ele_num*3; i++) {
        if( ele_arr[i] == vex_id ) {
            ele[n++] = i/3;
        }
    }

    *ele_n = n;

    return 0;
}

/**
 *  Get vertex data
 */
int MeshData::get_vex(int vex_id, double *v)
{
    v[0] = vex_arr[vex_id*3+0];
    v[1] = vex_arr[vex_id*3+1];
    v[2] = vex_arr[vex_id*3+2];

    return 0;
}

/**
 *  Calculate vertex normal vector
 */
int MeshData::calc_vex_norm(int vex_id, double *v)
{
    int     ele_n, *ele;
    double  v1[3], v2[3], v3[3];
    int     i1, i2, i3, ei;
    int     i, j;
    double  l;

    // clear v
    for(i=0; i<3; i++) v[i] = 0.0;

    // get elements which contain given vertex
    ele_n = 40;
    ele = new int[ele_n];
    get_ele_by_vex(vex_id, &ele_n, ele);

    // for each element
    for(i=0; i<ele_n; i++) {
        ei = ele[i];
        i1 = ele_arr[ei*3+0];
        i2 = ele_arr[ei*3+1];
        i3 = ele_arr[ei*3+2];

        // v2 - v1
        v1[0] = vex_arr[i2*3+0] - vex_arr[i1*3+0];
        v1[1] = vex_arr[i2*3+1] - vex_arr[i1*3+1];
        v1[2] = vex_arr[i2*3+2] - vex_arr[i1*3+2];

        // v3 - v1
        v2[0] = vex_arr[i3*3+0] - vex_arr[i1*3+0];
        v2[1] = vex_arr[i3*3+1] - vex_arr[i1*3+1];
        v2[2] = vex_arr[i3*3+2] - vex_arr[i1*3+2];

        // (v2-v1)x(v3-v1)
        vec_cross_product(v1, v2, v3);
        v[0] += v3[0];
        v[1] += v3[1];
        v[2] += v3[2];
    }

    // average normal vector
    v[0] /= ele_n;
    v[1] /= ele_n;
    v[2] /= ele_n;

    // normalize length
    l = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    v[0] /= l;
    v[1] /= l;
    v[2] /= l;

    delete ele;

    return 0;
}

double MeshData::mesh_area(void)
{
    double      s;
    int         i1, i2, i3;
    double      *p1, *p2, *p3;

    int         i;

    s = 0;
    for(i=0; i<ele_num; i++) {
        i1 = ele_arr[i*3+0];
        i2 = ele_arr[i*3+1];
        i3 = ele_arr[i*3+2];

        p1 = vex_arr+i1*3;
        p2 = vex_arr+i2*3;
        p3 = vex_arr+i3*3;

        s += triangle_area(p1, p2, p3);
    }

    return s;
}


int geodesic_get_data(MeshData *md,
                      std::vector<double> &points,
                      std::vector<unsigned> &faces)
{
    int     i;
    int     np, nf;
    double  *arr_p;
    int     *arr_f;

    np = md->vex_num;
    nf = md->ele_num;

    if( np < 1 || nf < 1 ) return -1;

    arr_p = md->get_vex();
    arr_f = md->get_ele();

    points.clear();
    faces.clear();
    points.reserve(np*3);
    faces.reserve(nf*3);

    for(i=0; i<np*3; i++) points.push_back(arr_p[i]);
    for(i=0; i<nf*3; i++) faces.push_back(arr_f[i]);

    return 0;
}


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

int calc_agd(const char *fn_base)
{
    char                    fn_buf[400];

    int                     np, nf;
    int                     node_s;

    std::vector<double>     points;
    std::vector<unsigned>   faces;

    MeshData                md;

    double                  dis;
    double                  *agd;
    float                   *arr_gd;
    double                  mesh_area;

    FILE                    *fp = NULL;
    int                     i, j;

    // load mesh data
    sprintf(fn_buf, "%s.off", fn_base);
    md.load(fn_buf);
    geodesic_get_data(&md, points, faces);

    np = md.vex_num;
    nf = md.ele_num;

    printf("calc_agd: np = %d, nf = %d\n", np, nf);

    agd = new double[np];
    for(i=0; i<np; i++) agd[i] = 0.0;

    arr_gd = new float[np*np];
    for(i=0; i<np*np; i++) arr_gd[i] = 0.0;

    // initialize mesh obj
    geodesic::Mesh mesh;
    //create internal mesh data structure including edges
    mesh.initialize_mesh_data(points, faces);

    // create dijkstra algorithm obj
    //      simplest approximate algorithm: path only allowed on the edges of the mesh
    geodesic::GeodesicAlgorithmDijkstra dijkstra_algorithm(&mesh);
    geodesic::GeodesicAlgorithmBase* algorithm = &dijkstra_algorithm;

    for(node_s=0; node_s < np-1; node_s ++) {
        //printf("%6.2f %%\r", (double)(node_s*100.0/(np-1)));
        //fflush(stdout);

        std::vector<geodesic::SurfacePoint> sources;
        sources.push_back(geodesic::SurfacePoint(&mesh.vertices()[node_s]));

        // cover the whole mesh
        algorithm->propagate(sources);

        // calc geodesic distance
        std::vector<geodesic::SurfacePoint> path;
        for(i=node_s+1; i<mesh.vertices().size(); i++) {
            geodesic::SurfacePoint pt(&mesh.vertices()[i]);
            algorithm->trace_back(pt, path);

            dis = geodesic::length(path);
            agd[node_s] += dis;
            agd[i] += dis;

            arr_gd[node_s*np + i] = dis;
            arr_gd[i*np + node_s] = dis;
        }
    }

    // calculate agd
    if( agd_method == 0 ) {
        // calc mesh area
        mesh_area = md.mesh_area();

        for(int i=0; i<np; i++) {
            agd[i] /= mesh_area;
        }
    } else {
        double agd_all;

        agd_all = 0.0;
        for(int i=0; i<np; i++) agd_all += agd[i];
        agd_all /= np;

        printf("    agd_avg = %g\n", agd_all);

        for(int i=0; i<np; i++) agd[i] /= agd_all;
    }

    // output agd values
    {
        sprintf(fn_buf, "%s_agd", fn_base);
        fp = fopen(fn_buf, "w");

        for(int i=0; i<np; i++) fprintf(fp, "%g\n", agd[i]);

        fclose(fp);
    }

    // output geodesic distance matrix
    {
        uint64_t    n = np*np;

        sprintf(fn_buf, "%s_gd", fn_base);
        fp = fopen(fn_buf, "w");

        fwrite(&n, sizeof(uint64_t), 1, fp);
        fwrite(arr_gd, sizeof(float)*n, 1, fp);

        fclose(fp);
    }

    delete agd;
    delete arr_gd;

    return 0;
}

int main(int argc, char **argv)
{
    if( argc > 1 ) {
        StringArray     fa;
        std::string     fn_in;

        // get output filename
        fn_in = argv[1];
        fa = path_splitext(fn_in);

        if( argc > 2 ) agd_method = atoi(argv[2]);

        calc_agd(fa[0].c_str());
    } else
        printf("please input mesh filename!\n");

    return 0;
}
