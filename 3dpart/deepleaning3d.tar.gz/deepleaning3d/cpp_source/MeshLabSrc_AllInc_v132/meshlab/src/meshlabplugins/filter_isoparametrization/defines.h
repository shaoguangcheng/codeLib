#ifndef _ISO_DEFINES
#define _ISO_DEFINES

#define abstraction_num 10
#define flip_factor 1.5f

// it uses the from qmake definitions
//#define _USE_OMP

#define _MESHLAB


#endif
