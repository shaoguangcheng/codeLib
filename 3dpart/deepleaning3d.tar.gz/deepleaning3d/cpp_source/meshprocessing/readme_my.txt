export PROJHOME=/home/bushuhui/msdk/3d/tools_libs/manifold_mesh_processing/meshprocessing
export DEBUGTYPE=debug
export ARCH=linux
cd src/programs/MeshProcessing
