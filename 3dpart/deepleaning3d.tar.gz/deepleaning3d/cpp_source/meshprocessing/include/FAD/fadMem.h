#ifndef _FADMEM_H
#define _FADMEM_H

#if defined(__APPLE__) || defined(linux)
#include <Boost/pool/pool.hpp>
#else
#include <Boost/pool.hpp>
#endif

#include <vector>

template <class T>
class FADMemory {
protected:
    std::vector< boost::pool<> * > m_aopPools;

public:
    T *create( const size_t in_iGSize, const size_t in_iOldSize, T * in_op );
    void destroy( const size_t in_iGSize, T *in_op );

    FADMemory() { }
    ~FADMemory() {
        for ( size_t i = 0; i < m_aopPools.size(); i++ ) {
            delete m_aopPools[i];
            m_aopPools[i] = NULL;
        }
    }
};

template<class T>
inline T *FADMemory<T>::create( const size_t in_iGSize, const size_t in_iOldSize, T * in_op ) 
{
    if ( m_aopPools.size() <= in_iGSize ) {
        const size_t iOldSize = m_aopPools.size();
        for ( size_t i = iOldSize; i < in_iGSize + 1; i++ )
            m_aopPools += NULL;
    }

    if ( m_aopPools[in_iGSize] == NULL ) {
        m_aopPools[in_iGSize] = new boost::pool<>(in_iGSize * sizeof(T));
    }

    if ( in_op != NULL )
        destroy( in_iOldSize, in_op );

    T *opRet = static_cast< T * > ( m_aopPools[in_iGSize]->malloc() );
    ASSERT ( opRet != NULL );

    memset( opRet, 0, in_iGSize * sizeof(T) );

    return static_cast<T *>( opRet );
}

template<>
inline void FADMemory<double>::destroy( const size_t in_iSize, double *in_op ) 
{
    if ( in_op ) {
        m_aopPools[in_iSize]->free( static_cast<void *> (in_op) );
    }
}
    

#endif
