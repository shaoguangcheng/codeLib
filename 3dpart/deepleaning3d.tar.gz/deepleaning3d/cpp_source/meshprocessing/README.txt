There are six executables here:
FitNormals: Takes in a point set and returns an unoriented normal for each point. 
MeshProcessing: Basic mesh processing (clean up, smoothing, mesh conversion small edge/angle removal, small hole filling)
Polymender: Take in a polygon soup and produce a manifold mesh.
ShapeDescriptors: Compute a wide variety of local shape descriptors for one or more manifold meshes.
vtkShell: A front end for vtk to produce mesh files.
MeshViewer_Lite: A graphical program for reading in, viewing, and painting meshes.

These programs actually do a lot more: see
Wiki pages are here: https://sourceforge.net/apps/mediawiki/meshprocessing/index.php?title=Main_Page

To build: Each program has its own README.txt file. Nearly all of these programs will need you to install external, freely available libraries such as Boost.

MacOS: There is an xcode project file in src/programs/...
Visual studio: There is a .sln project file in src/programs/...
Linux: Read the instructions in doc/FirstTime.html for setting up the compile variables. Then cd to src/programs/... and type make.

