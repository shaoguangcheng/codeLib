#include "StdAfx.H"
#include <stdio.h>
#include <MC/MC_Polynomial.H>
#include <MC/MC_Param.H>
#include <MC/MC_Fit.H>
#include <MC/MC_MeshSubset.H>
#include <utils/Pm_MeshLite.H>
#include <fitting/FITTools_Least_squares.H>

MCPolynomial::MCPolynomial(const PMeshLite &in_mesh,
                           const int in_nRings, 
                           const MCParam::MC_ParamType &in_paramType )
: MCFit(in_mesh,POLYNOMIAL,in_paramType,in_nRings)
{

}

MCPolynomial::~MCPolynomial()
{
}

int
MCPolynomial::Evaluate(const R2Pt &in_uvPoint, R3Pt &out_xyzPoint)
{
    double u, v, x, y, z;
    
    if( A.num() < 6 ) return -1;
    
    u = in_uvPoint[0];
    v = in_uvPoint[1];

    x =  A[0][0]     + A[1][0]*u   + A[2][0]*v;
    x += A[3][0]*u*u + A[4][0]*u*v + A[5][0]*v*v;
    y =  A[0][1]     + A[1][1]*u   + A[2][1]*v;
    y += A[3][1]*u*u + A[4][1]*u*v + A[5][1]*v*v;
    z =  A[0][2]     + A[1][2]*u   + A[2][2]*v;
    z += A[3][2]*u*u + A[4][2]*u*v + A[5][2]*v*v;
    if( A.num() >= 9 ) {
        x += A[6][0]*u*u*v + A[7][0]*u*v*v + A[8][0]*u*u*v*v;
        y += A[6][1]*u*u*v + A[7][1]*u*v*v + A[8][1]*u*u*v*v;
        z += A[6][2]*u*u*v + A[7][2]*u*v*v + A[8][2]*u*u*v*v;
    }

    out_xyzPoint = R3Pt(x, y, z);
    return 0;
}

int
MCPolynomial::Evaluate(const R2Pt &in_uvPoint, R3Vec &out_normal, 
                       R3Vec &out_dU, R3Vec &out_dV, 
                       R3Vec &out_dUU, R3Vec &out_dUV, R3Vec &out_dVV )
{
    double u, v, x, y, z;

    if( A.num() < 6 ) return -1;
    
    u = in_uvPoint[0];
    v = in_uvPoint[1];

    // Evaluate df/du 
    x = A[1][0] + 2.0*A[3][0]*u + A[4][0]*v;
    y = A[1][1] + 2.0*A[3][1]*u + A[4][1]*v;
    z = A[1][2] + 2.0*A[3][2]*u + A[4][2]*v;
    if( A.num() >= 9 ) {
        x += 2.0*A[6][0]*u*v + A[7][0]*v*v + 2.0*A[8][0]*u*v*v;
        y += 2.0*A[6][1]*u*v + A[7][1]*v*v + 2.0*A[8][1]*u*v*v;
        z += 2.0*A[6][2]*u*v + A[7][2]*v*v + 2.0*A[8][2]*u*v*v;
    }
    out_dU = R3Vec( x, y, z );

    // Evaluate df/dv 
    x = A[2][0] + A[4][0]*u + 2.0*A[5][0]*v;
    y = A[2][1] + A[4][1]*u + 2.0*A[5][1]*v;
    z = A[2][2] + A[4][2]*u + 2.0*A[5][2]*v;
    if( A.num() >= 9 ) {
        x += A[6][0]*u*u + 2.0*A[7][0]*u*v + 2.0*A[8][0]*u*u*v;
        y += A[6][1]*u*u + 2.0*A[7][1]*u*v + 2.0*A[8][1]*u*u*v;
        z += A[6][2]*u*u + 2.0*A[7][2]*u*v + 2.0*A[8][2]*u*u*v;
    }
    out_dV = R3Vec( x, y, z );

    // Evaluate the normal at (u,v) 
    out_normal = Cross(out_dU,out_dV);
    out_normal.Normalize();

    // Evaluate df/duu 
    x = 2.0*A[3][0];
    y = 2.0*A[3][1];
    z = 2.0*A[3][2];
    if( A.num() >= 9 ) {
        x += 2.0*A[6][0]*v + 2.0*A[8][0]*v*v;
        y += 2.0*A[6][1]*v + 2.0*A[8][1]*v*v;
        z += 2.0*A[6][2]*v + 2.0*A[8][2]*v*v;
    }
    out_dUU = R3Vec( x, y, z );

    // Evaluate df/duv 
    x = A[4][0];
    y = A[4][1];
    z = A[4][2];
    if( A.num() >= 9 ) {
        x += 2.0*A[6][0]*u + 2.0*A[7][0]*v + 4.0*A[8][0]*u*v;
        y += 2.0*A[6][1]*u + 2.0*A[7][1]*v + 4.0*A[8][1]*u*v;
        z += 2.0*A[6][2]*u + 2.0*A[7][2]*v + 4.0*A[8][2]*u*v;
    }
    out_dUV = R3Vec( x, y, z );

    // Evaluate df/dvv 
    x = 2.0*A[5][0];
    y = 2.0*A[5][1];
    z = 2.0*A[5][2];
    if( A.num() >= 9 ) {
        x += 2.0*A[7][0]*u + 2.0*A[8][0]*u*u;
        y += 2.0*A[7][1]*u + 2.0*A[8][1]*u*u;
        z += 2.0*A[7][2]*u + 2.0*A[8][2]*u*u;
    }
    out_dVV = R3Vec( x, y, z );

    return 0;
}
        
void MCPolynomial::SetMeshSubset( const Vertex &in_vertex )
{
    m_Param.Create(in_vertex,m_iRings);
}

int 
MCPolynomial::Curvature(const Vertex &in_vertex,
						MCPoint &cpt)
{
    int ier;
    double dArea;
    R3Pt P;
    R3Vec NN, Xu, Xv, Xuu, Xuv, Xvv;
    
    FILE *out = NULL;
    //out = fopen(WINDataHome("test_new.dat"),"a");
    
    P = in_vertex->GetLoc();
    if( out != NULL ) {
        fprintf(out,"Point(%d) =(%lf,%lf,%lf)\n",
                in_vertex->IndexId(), P[0], P[1], P[2] );
    }
    
    //if( !valid || in_vertex != m_Vertex ) {
    
    ier = CalculateFit(in_vertex);
	if( ier != 0 ) {
		return ier;
	}
    
    //}
    
    if( out != NULL ) {
        m_Param.dump(out);
        dump(out);
    }
    
    // Evaluate the function to get point, normal, and derivatives 
    ier = Evaluate(m_Param.PtUV(), P);
	if( ier != 0 ) return ier;
    
    ier = Evaluate(m_Param.PtUV(), NN, Xu, Xv, Xuu, Xuv, Xvv);
	if( ier != 0 ) return ier;
    
    if( out != NULL ) {
        fprintf(out,"Point=(%lf,%lf,%lf), N=(%lf,%lf,%lf)\n",
                P[0], P[1], P[2], NN[0], NN[1], NN[2] );
    }
    
    // Calculate the curvature from the derivatives
    MCFit::Curvature(Xu, Xv, Xuu, Xuv, Xvv, dArea, cpt );
    
    if( out != NULL ) {
        fprintf(out,"Xu=(%lf,%lf,%lf), Xv=(%lf,%lf,%lf)\n",
                Xu[0], Xu[1], Xu[2], Xv[0], Xv[1], Xv[2] );
        fprintf(out,"Xuu=(%lf,%lf,%lf)\n", Xuu[0], Xuu[1], Xuu[2] );
        fprintf(out,"Xuv=(%lf,%lf,%lf)\n", Xuv[0], Xuv[1], Xuv[2] );
        fprintf(out,"Xvv=(%lf,%lf,%lf)\n", Xvv[0], Xvv[1], Xvv[2] );
        cpt.dump(out);
        
        fclose(out);
        out = NULL;
    }
    
    return 0;
}

int 
MCPolynomial::Curvature(MCPoint &cpt)
{
    int ier;
    double dArea;
    R3Pt P;
    R3Vec NN, Xu, Xv, Xuu, Xuv, Xvv;
        
    // Evaluate the function to get point, normal, and derivatives 
    ier = Evaluate(m_Param.PtUV(), P);
	if( ier != 0 ) return ier;
    
    ier = Evaluate(m_Param.PtUV(), NN, Xu, Xv, Xuu, Xuv, Xvv);
	if( ier != 0 ) return ier;
        
    // Calculate the curvature from the derivatives
    MCFit::Curvature(Xu, Xv, Xuu, Xuv, Xvv, dArea, cpt );
    
    return 0;
}

void MCPolynomial::Fit(  const Array<R3Pt> &in_apt, const Array<R2Pt> &in_aptPlane )
{
    // Setup least square problem
    FITTools_LS prob_ls( in_apt.num(), 6, 3 );
    
    // Set up the matrix to solve 
    for( int i=0; i< in_apt.num(); i++ ) {
        const R2Pt & U = in_aptPlane[i];
        const R3Pt & X = in_apt[i];
        
        prob_ls.Desired_clapack( i, 0 ) = 1.0;
        prob_ls.Desired_clapack( i, 1 ) = U[0];
        prob_ls.Desired_clapack( i, 2 ) = U[1];
        prob_ls.Desired_clapack( i, 3 ) = U[0]*U[0];
        prob_ls.Desired_clapack( i, 4 ) = U[0]*U[1];
        prob_ls.Desired_clapack( i, 5 ) = U[1]*U[1];
        prob_ls.Rhs_clapack( i, 0 ) = X[0];
        prob_ls.Rhs_clapack( i, 1 ) = X[1];
        prob_ls.Rhs_clapack( i, 2 ) = X[2];
    }
    
    // Do the least squares fit 
    A.need(6);
    if( prob_ls.Solve_clapack() == FALSE ) {
        printf("ERROR - Solving Least Square problem\n" );
        cout << "Number of points: " << in_apt.num() << "\n";
        for ( int i = 0; i < in_apt.num(); i++ ) {
            cout << in_aptPlane[i] << "  : " << in_apt[i] << "\n";
        }
        for ( FORINT i = 0; i < 6; i++ ) {
            A[i] = R3Pt(0,0,0);
        }
        const double dDiv = 1.0 / (double) in_apt.num();
        for ( FORINT i = 0; i < in_apt.num(); i++ ) {
            for ( int j = 0; j < 3; j++ ) {
                A[0][j] += in_apt[i][j] * dDiv;
            }
        }
    } else {
    
        // Store the polynomial coefficients
        for( FORINT i=0; i<6; i++ ) {
            A[i] = R3Pt(prob_ls.Solution_clapack( i, 0 ),
                               prob_ls.Solution_clapack( i, 1 ),
                               prob_ls.Solution_clapack( i, 2 ) );
        }
    }
}

int 
MCPolynomial::CalculateFit(const Vertex &in_vertex)
{
	/*
     int iDebug = 0;
     FILE *out = NULL;
     
     if( in_vertex->IndexId() == iDebug ) {
		out = fopen("c:/data/ReferenceMeshes/fit.out", "w");
	}
	*/

    Array<R2Pt> aptPlane;
    Array<R3Pt> apt;

    // Create the mesh subset
    m_Param.Create(in_vertex,m_iRings);

    // Compute parametric coordinates
    const int ier = m_Param.CalculateUV(in_vertex,m_iRings);
    if( ier < 0 ) return ier;

    // Setup least square problem
    const int n = m_Param.Vertices().num();
    apt.need(n);
    aptPlane.need(n);

    // Set up the matrix to solve 
    for( int i=0; i<n; i++ ) {
        aptPlane[i] = m_Param.UV()[i];
        apt[i] = m_Param.Vertices()[i]->GetLoc();
    }

    Fit( apt, aptPlane );
	/*
     if( out != NULL ) {
		fclose(out);
		out = NULL;
	}
	*/

    return 0;
}

void 
MCPolynomial::dump(FILE *out)
{
    int i;
    R3Pt pt;

    if( out != NULL ) {
        fprintf(out,"Polynomial: %d rings\n", m_iRings );
        fprintf(out,"  Method: %d\n", (int) m_ParamType );
        for( i=0; i<A.num(); i++ ) {
            pt = A[i];
            fprintf(out," A[%d]: (%lf, %lf, %lf)\n", i, pt[0], pt[1], pt[2] );
        }
    }
}
