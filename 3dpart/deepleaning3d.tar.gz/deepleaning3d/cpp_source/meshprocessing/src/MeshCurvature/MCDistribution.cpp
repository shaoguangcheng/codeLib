#include "StdAfx.H"
#include <MC/MC_Distribution.H>
#include <MC/MC_MeshUtils.H>
#include <MC/MC_CurvatureMap.h>
#include <MC/ArrayMesh.h>
#include <MC/tdgFunc.h>
#include <math.h>

MCDistribution::MCDistribution()
{
    m_sDescription = NULL;    
    m_iPointIndex = 0;
    m_iNumRings = 0;
    Kg.need(0);
    KgMin.need(0);
    KgMax.need(0);
    Kbar.need(0);
    KbarMin.need(0);
    KbarMax.need(0);
    StdDevKg.need(0);
    StdDevKbar.need(0);
    A.need(0);
    R.need(0);
}

MCDistribution::MCDistribution( const MCDistribution &in_dist ) 
{
    (*this) = in_dist;
}
    
MCDistribution::~MCDistribution()
{
    Clear();
    if( m_sDescription != NULL ) delete [] m_sDescription;
}
    
MCDistribution& MCDistribution::operator=(const MCDistribution &in_dist)
{
    m_sDescription = new char[strlen(in_dist.m_sDescription)+1];
    strcpy(m_sDescription,in_dist.m_sDescription);

    return *this;
}

void MCDistribution::set_description(const char *desc)
{
    if( m_sDescription != NULL ) delete [] m_sDescription;
    if( desc == NULL ) {
        m_sDescription = NULL;
        return;
    }
    m_sDescription = new char[strlen(desc)+1];
    strcpy(m_sDescription, desc);
}

void MCDistribution::Clear()
{
    m_iPointIndex = -1;
    m_iNumRings = 0;
    Kg.need(0);
    KgMax.need(0);
    KgMin.need(0);
    Kbar.need(0);
    KbarMax.need(0);
    KbarMin.need(0);
    StdDevKg.need(0);
    StdDevKbar.need(0);
    A.need(0);
    R.need(0);
}

int MCDistribution::Create( MCData &data, 
                            const Array< double > &area,
                            const int pointIndex, const int maxRings)
{
    int i, ier, nv;
    int nRings = 1;
    double pi, kgmin, kgmax, kbarmin, kbarmax;
    double KgSum, KgSumSq, KbarSum, KbarSumSq, AreaSum, Acum;
    double avgKg, avgKbar, avgKgSD, avgKbarSD;

    R3Pt P;
    R3Vec N;
    Vertex v;
    Array<Vertex> aopVs;

    MCPoint cpt;

    ArrayMesh amesh;
    int numRings, j, n, ipt;
    int *ringSizes;
    int *ringIndices;
    int ndx;
    Array<double> Reff;
    //Array<double> scalar;
    //char filename[132];

    pi = 4.0 * atan(1.0);

    FILE *out = NULL;
    //out = fopen(WINDataHome("dist_init.dat"),"w");

    m_iPointIndex = pointIndex;

    Kg.need(0);
    Kbar.need(0);
    StdDevKg.need(0);
    StdDevKbar.need(0);
    A.need(0);
    R.need(0);

    nv = data.Mesh()->NumVertices();
    data.Mesh()->AllMeshVertices(aopVs);
    v = aopVs[pointIndex];

    // Get the rings

    ier = amesh.Init(*data.Mesh());
    if( ier != 0 ) {
        return ier;
    }

    ier = amesh.FindRings(pointIndex, maxRings, numRings, 
                          ringSizes, ringIndices);
    if( ier != 0 ) {
        return ier;
    }

    if( out != NULL ) {
        if( m_sDescription == NULL ) {
            fprintf(out,"File: UNKNOWN, %d vertices, %d rings\n", 
                        nv, numRings);
        } else {
            fprintf(out,"File: \"%s\", %d vertices, %d rings\n", 
                        m_sDescription, nv, numRings);
        }
        ipt = 0;
        for( i=0; i<numRings; i++ ) {
            n = ringSizes[i];
            fprintf(out,"Ring %d: %d points\n", i, n);
            for( j=0; j<n; j++ ) {
                fprintf(out,"%5d ", ringIndices[ipt++]);
                if( (j+1)%10 == 0 ) fprintf(out,"\n");
            }
            if( j%10 != 0 ) fprintf(out,"\n");
        }
    }
    
    // For each ring

    ipt = 0;
    for( i=0; i<numRings; i++ ) {
        KgSum = 0.0;
        KgSumSq = 0.0;
        KbarSum = 0.0;
        KbarSumSq = 0.0;
        AreaSum = 0.0;
        Acum = 0.0;
        n = ringSizes[i];
        for( j=0; j<n; j++ ) {
            ndx = ringIndices[ipt++];
            v = aopVs[ndx];

            data.getPoint(v,cpt);

            // Calculate the average and stddev of Kg

            KgSum += cpt.Kg();
            KgSumSq += cpt.Kg() * cpt.Kg();

            // Calculate the average and stddev of Kbar

            KbarSum += cpt.Kbar();
            KbarSumSq += cpt.Kbar() * cpt.Kbar();

            // Calculate the max and min values

            if( j == 0 ) {
                kgmin = cpt.Kg();
                kgmax = cpt.Kg();
                kbarmin = cpt.Kbar();
                kbarmax = cpt.Kbar();
            } else {
                if( cpt.Kg() < kgmin ) kgmin = cpt.Kg();
                if( cpt.Kg() > kgmax ) kgmax = cpt.Kg();
                if( cpt.Kbar() < kbarmin ) kbarmin = cpt.Kbar();
                if( cpt.Kbar() > kbarmax ) kbarmax = cpt.Kbar();
            }

            // Calculate the ring area

            AreaSum += area[ndx];
        }
        avgKg = KgSum / (double)n;
        Kg += avgKg;
        KgMin += kgmin;
        KgMax += kgmax;
        avgKgSD = KgSumSq / (double)n - avgKg*avgKg;
        avgKgSD = (avgKgSD<0.0) ? 0.0 : avgKgSD;
        StdDevKg += sqrt( avgKgSD );
        avgKbar = KbarSum / (double)n;
        Kbar += avgKbar;
        KbarMin += kbarmin;
        KbarMax += kbarmax;
        avgKbarSD = KbarSumSq / (double)n - avgKbar*avgKbar;
        avgKbarSD = (avgKbarSD<0.0) ? 0.0 : avgKbarSD;
        StdDevKbar += sqrt( avgKbarSD );
        A += AreaSum;
    }

    // Calculate the effective radius

    Acum = 0.0;
    for( i=0; i<numRings; i++ ) {
        Acum += A[i];
        Reff += sqrt(Acum/pi);
    }

    R += 0.0;
    for( i=1; i<numRings; i++ ) {
        R += 0.5*(Reff[i-1] + Reff[i]);
    }
    m_iNumRings = numRings;

    if( out != NULL ) {
        for( i=0; i<numRings; i++ ) {
            fprintf(out,"Ring %3d: %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n",
                        i, Kg[i], StdDevKg[i], Kbar[i], 
                        StdDevKbar[i], A[i], R[i], 
                        KgMax[i], KgMin[i], KbarMax[i], KbarMin[i] );
        }
        fclose(out);
    }
    delete [] ringIndices;
    delete [] ringSizes;

    return 0;
}

int MCDistribution::Create( MCData &data, ArrayMesh &amesh,
                            const Array< double > &area,
                            const int pointIndex, const int maxRings)
{
    int i, ier, nv;
    int nRings = 1;
    double pi, kgmin, kgmax, kbarmin, kbarmax;
    double KgSum, KgSumSq, KbarSum, KbarSumSq, AreaSum, Acum;
    double avgKg, avgKbar, avgKgSD, avgKbarSD;

    R3Pt P;
    R3Vec N;
    Vertex v;
    Array<Vertex> aopVs;

    MCPoint cpt;

    int numRings, j, n, ipt;
    int *ringSizes;
    int *ringIndices;
    int ndx;
    Array<double> Reff;
    //Array<double> scalar;
    //char filename[132];

    pi = 4.0 * atan(1.0);

    FILE *out = NULL;
    //out = fopen(WINDataHome("dist_init.dat"),"w");

    m_iPointIndex = pointIndex;

    Kg.need(0);
    Kbar.need(0);
    StdDevKg.need(0);
    StdDevKbar.need(0);
    A.need(0);
    R.need(0);

    nv = data.Mesh()->NumVertices();
    data.Mesh()->AllMeshVertices(aopVs);
    v = aopVs[pointIndex];

    // Get the rings

    /*
    ier = amesh.Init(*data.Mesh());
    if( ier != 0 ) {
        return ier;
    }
    */

    ier = amesh.FindRings(pointIndex, maxRings, numRings, 
                           ringSizes, ringIndices);
    if( ier != 0 ) {
        return ier;
    }

    if( out != NULL ) {
        if( m_sDescription == NULL ) {
            fprintf(out,"File: UNKNOWN, %d vertices, %d rings\n", 
                        nv, numRings);
        } else {
            fprintf(out,"File: \"%s\", %d vertices, %d rings\n", 
                        m_sDescription, nv, numRings);
        }
        ipt = 0;
        for( i=0; i<numRings; i++ ) {
            n = ringSizes[i];
            fprintf(out,"Ring %d: %d points\n", i, n);
            for( j=0; j<n; j++ ) {
                fprintf(out,"%5d ", ringIndices[ipt++]);
                if( (j+1)%10 == 0 ) fprintf(out,"\n");
            }
            if( j%10 != 0 ) fprintf(out,"\n");
        }
    }
    
    // For each ring

    ipt = 0;
    for( i=0; i<numRings; i++ ) {
        KgSum = 0.0;
        KgSumSq = 0.0;
        KbarSum = 0.0;
        KbarSumSq = 0.0;
        AreaSum = 0.0;
        Acum = 0.0;
        n = ringSizes[i];
        for( j=0; j<n; j++ ) {
            ndx = ringIndices[ipt++];
            v = aopVs[ndx];

            data.getPoint(v,cpt);

            // Calculate the average and stddev of Kg

            KgSum += cpt.Kg();
            KgSumSq += cpt.Kg() * cpt.Kg();

            // Calculate the average and stddev of Kbar

            KbarSum += cpt.Kbar();
            KbarSumSq += cpt.Kbar() * cpt.Kbar();

            // Calculate the max and min values

            if( j == 0 ) {
                kgmin = cpt.Kg();
                kgmax = cpt.Kg();
                kbarmin = cpt.Kbar();
                kbarmax = cpt.Kbar();
            } else {
                if( cpt.Kg() < kgmin ) kgmin = cpt.Kg();
                if( cpt.Kg() > kgmax ) kgmax = cpt.Kg();
                if( cpt.Kbar() < kbarmin ) kbarmin = cpt.Kbar();
                if( cpt.Kbar() > kbarmax ) kbarmax = cpt.Kbar();
            }

            // Calculate the ring area

            AreaSum += area[ndx];
        }
        avgKg = KgSum / (double)n;
        Kg += avgKg;
        KgMin += kgmin;
        KgMax += kgmax;
        avgKgSD = KgSumSq / (double)n - avgKg*avgKg;
        avgKgSD = (avgKgSD<0.0) ? 0.0 : avgKgSD;
        StdDevKg += sqrt( avgKgSD );
        avgKbar = KbarSum / (double)n;
        Kbar += avgKbar;
        KbarMin += kbarmin;
        KbarMax += kbarmax;
        avgKbarSD = KbarSumSq / (double)n - avgKbar*avgKbar;
        avgKbarSD = (avgKbarSD<0.0) ? 0.0 : avgKbarSD;
        StdDevKbar += sqrt( avgKbarSD );
        A += AreaSum;
    }

    // Calculate the effective radius

    Acum = 0.0;
    for( i=0; i<numRings; i++ ) {
        Acum += A[i];
        Reff += sqrt(Acum/pi);
    }

    R += 0.0;
    for( i=1; i<numRings; i++ ) {
        R += 0.5*(Reff[i-1] + Reff[i]);
    }
    m_iNumRings = numRings;

    if( out != NULL ) {
        for( i=0; i<numRings; i++ ) {
            fprintf(out,"Ring %3d: %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n",
                        i, Kg[i], StdDevKg[i], Kbar[i], 
                        StdDevKbar[i], A[i], R[i], 
                        KgMax[i], KgMin[i], KbarMax[i], KbarMin[i] );
        }
        fclose(out);
    }
    delete [] ringIndices;
    delete [] ringSizes;

    return 0;
}

int MCDistribution::Create( MCData &data, ArrayMesh &amesh,
                            const Array< double > &area,
                            const int pointIndex, const int maxRings,
                            int *&queue, int *&counts, 
                            int *&flags, int *&list,
                            int *&kp, int *&ki, int *&in, int *&ij,
                            int *&ji, int *&jk, float *&xc)
{
    int i, ier, nv;
    int nRings = 1;
    double pi, kgmin, kgmax, kbarmin, kbarmax;
    double KgSum, KgSumSq, KbarSum, KbarSumSq, AreaSum, Acum;
    double avgKg, avgKbar, avgKgSD, avgKbarSD;

    R3Pt P;
    R3Vec N;
    Vertex v;
    Array<Vertex> aopVs;

    MCPoint cpt;

    int numRings, j, n, ipt;
    int *ringSizes;
    int *ringIndices;
    int ndx;
    Array<double> Reff;
    //Array<double> scalar;
    //char filename[132];

    pi = 4.0 * atan(1.0);

    FILE *out = NULL;
    //out = fopen(WINDataHome("dist_init.dat"),"w");

    m_iPointIndex = pointIndex;

    Kg.need(0);
    Kbar.need(0);
    StdDevKg.need(0);
    StdDevKbar.need(0);
    A.need(0);
    R.need(0);

    nv = data.Mesh()->NumVertices();
    data.Mesh()->AllMeshVertices(aopVs);
    v = aopVs[pointIndex];

    // Get the rings

    /*
    ier = amesh.Init(*data.Mesh());
    if( ier != 0 ) {
        return ier;
    }
    */

    ier = amesh.FindRings(pointIndex, maxRings, numRings, 
                           ringSizes, ringIndices,
                           queue, counts, flags, list,
                           kp, ki, in, ij, ji, jk, xc);
    if( ier != 0 ) {
        return ier;
    }

    if( out != NULL ) {
        if( m_sDescription == NULL ) {
            fprintf(out,"File: UNKNOWN, %d vertices, %d rings\n", 
                        nv, numRings);
        } else {
            fprintf(out,"File: \"%s\", %d vertices, %d rings\n", 
                        m_sDescription, nv, numRings);
        }
        ipt = 0;
        for( i=0; i<numRings; i++ ) {
            n = ringSizes[i];
            fprintf(out,"Ring %d: %d points\n", i, n);
            for( j=0; j<n; j++ ) {
                fprintf(out,"%5d ", ringIndices[ipt++]);
                if( (j+1)%10 == 0 ) fprintf(out,"\n");
            }
            if( j%10 != 0 ) fprintf(out,"\n");
        }
    }
    
    // For each ring

    ipt = 0;
    for( i=0; i<numRings; i++ ) {
        KgSum = 0.0;
        KgSumSq = 0.0;
        KbarSum = 0.0;
        KbarSumSq = 0.0;
        AreaSum = 0.0;
        Acum = 0.0;
        n = ringSizes[i];
        for( j=0; j<n; j++ ) {
            ndx = ringIndices[ipt++];
            v = aopVs[ndx];

            data.getPoint(v,cpt);

            // Calculate the average and stddev of Kg

            KgSum += cpt.Kg();
            KgSumSq += cpt.Kg() * cpt.Kg();

            // Calculate the average and stddev of Kbar

            KbarSum += cpt.Kbar();
            KbarSumSq += cpt.Kbar() * cpt.Kbar();

            // Calculate the max and min values

            if( j == 0 ) {
                kgmin = cpt.Kg();
                kgmax = cpt.Kg();
                kbarmin = cpt.Kbar();
                kbarmax = cpt.Kbar();
            } else {
                if( cpt.Kg() < kgmin ) kgmin = cpt.Kg();
                if( cpt.Kg() > kgmax ) kgmax = cpt.Kg();
                if( cpt.Kbar() < kbarmin ) kbarmin = cpt.Kbar();
                if( cpt.Kbar() > kbarmax ) kbarmax = cpt.Kbar();
            }

            // Calculate the ring area

            AreaSum += area[ndx];
        }
        avgKg = KgSum / (double)n;
        Kg += avgKg;
        KgMin += kgmin;
        KgMax += kgmax;
        avgKgSD = KgSumSq / (double)n - avgKg*avgKg;
        avgKgSD = (avgKgSD<0.0) ? 0.0 : avgKgSD;
        StdDevKg += sqrt( avgKgSD );
        avgKbar = KbarSum / (double)n;
        Kbar += avgKbar;
        KbarMin += kbarmin;
        KbarMax += kbarmax;
        avgKbarSD = KbarSumSq / (double)n - avgKbar*avgKbar;
        avgKbarSD = (avgKbarSD<0.0) ? 0.0 : avgKbarSD;
        StdDevKbar += sqrt( avgKbarSD );
        A += AreaSum;
    }

    // Calculate the effective radius

    Acum = 0.0;
    for( i=0; i<numRings; i++ ) {
        Acum += A[i];
        Reff += sqrt(Acum/pi);
    }

    R += 0.0;
    for( i=1; i<numRings; i++ ) {
        R += 0.5*(Reff[i-1] + Reff[i]);
    }
    m_iNumRings = numRings;

    if( out != NULL ) {
        for( i=0; i<numRings; i++ ) {
            fprintf(out,"Ring %3d: %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n",
                        i, Kg[i], StdDevKg[i], Kbar[i], 
                        StdDevKbar[i], A[i], R[i], 
                        KgMax[i], KgMin[i], KbarMax[i], KbarMin[i] );
        }
        fclose(out);
    }
    delete [] ringIndices;
    delete [] ringSizes;

    return 0;
}

int MCDistribution::Create( MCData &data, ArrayMesh &amesh,
                            const Array< double > &area,
                            const int pointIndex, const double maxRadius,
                            int *&queue, int *&counts, 
                            int *&flags, int *&list,
                            int *&kp, int *&ki, int *&in, int *&ij,
                            int *&ji, int *&jk, float *&xc)
{
    int i, ier, nv;
    int nRings = 1;
    double pi, kgmin, kgmax, kbarmin, kbarmax;
    double KgSum, KgSumSq, KbarSum, KbarSumSq, AreaSum, Acum;
    double avgKg, avgKbar, avgKgSD, avgKbarSD;

    R3Pt P;
    R3Vec N;
    Vertex v;
    Array<Vertex> aopVs;

    MCPoint cpt;

    int numRings, j, n, ipt;
    int *ringSizes;
    int *ringIndices;
    int ndx;
    Array<double> Reff;
    //Array<double> scalar;
    //char filename[132];

    pi = 4.0 * atan(1.0);

    FILE *out = NULL;
    //out = fopen(WINDataHome("dist_init.dat"),"w");

    m_iPointIndex = pointIndex;

    Kg.need(0);
    Kbar.need(0);
    StdDevKg.need(0);
    StdDevKbar.need(0);
    A.need(0);
    R.need(0);

    nv = data.Mesh()->NumVertices();
    data.Mesh()->AllMeshVertices(aopVs);
    v = aopVs[pointIndex];

    // Get the rings

    /*
    ier = amesh.Init(*data.Mesh());
    if( ier != 0 ) {
        return ier;
    }
    */

    ier = amesh.FindRings(pointIndex, maxRadius, area, numRings, 
                          ringSizes, ringIndices,
                          queue, counts, flags, list,
                          kp, ki, in, ij, ji, jk, xc);
    if( ier != 0 ) {
        return ier;
    }

    if( out != NULL ) {
        if( m_sDescription == NULL ) {
            fprintf(out,"File: UNKNOWN, %d vertices, %d rings\n", 
                        nv, numRings);
        } else {
            fprintf(out,"File: \"%s\", %d vertices, %d rings\n", 
                        m_sDescription, nv, numRings);
        }
        ipt = 0;
        for( i=0; i<numRings; i++ ) {
            n = ringSizes[i];
            fprintf(out,"Ring %d: %d points\n", i, n);
            for( j=0; j<n; j++ ) {
                fprintf(out,"%5d ", ringIndices[ipt++]);
                if( (j+1)%10 == 0 ) fprintf(out,"\n");
            }
            if( j%10 != 0 ) fprintf(out,"\n");
        }
    }
    
    // For each ring

    ipt = 0;
    for( i=0; i<numRings; i++ ) {
        KgSum = 0.0;
        KgSumSq = 0.0;
        KbarSum = 0.0;
        KbarSumSq = 0.0;
        AreaSum = 0.0;
        Acum = 0.0;
        n = ringSizes[i];
        for( j=0; j<n; j++ ) {
            ndx = ringIndices[ipt++];
            v = aopVs[ndx];

            data.getPoint(v,cpt);

            // Calculate the average and stddev of Kg

            KgSum += cpt.Kg();
            KgSumSq += cpt.Kg() * cpt.Kg();

            // Calculate the average and stddev of Kbar

            KbarSum += cpt.Kbar();
            KbarSumSq += cpt.Kbar() * cpt.Kbar();

            // Calculate the max and min values

            if( j == 0 ) {
                kgmin = cpt.Kg();
                kgmax = cpt.Kg();
                kbarmin = cpt.Kbar();
                kbarmax = cpt.Kbar();
            } else {
                if( cpt.Kg() < kgmin ) kgmin = cpt.Kg();
                if( cpt.Kg() > kgmax ) kgmax = cpt.Kg();
                if( cpt.Kbar() < kbarmin ) kbarmin = cpt.Kbar();
                if( cpt.Kbar() > kbarmax ) kbarmax = cpt.Kbar();
            }

            // Calculate the ring area

            AreaSum += area[ndx];
        }
        avgKg = KgSum / (double)n;
        Kg += avgKg;
        KgMin += kgmin;
        KgMax += kgmax;
        avgKgSD = KgSumSq / (double)n - avgKg*avgKg;
        avgKgSD = (avgKgSD<0.0) ? 0.0 : avgKgSD;
        StdDevKg += sqrt( avgKgSD );
        avgKbar = KbarSum / (double)n;
        Kbar += avgKbar;
        KbarMin += kbarmin;
        KbarMax += kbarmax;
        avgKbarSD = KbarSumSq / (double)n - avgKbar*avgKbar;
        avgKbarSD = (avgKbarSD<0.0) ? 0.0 : avgKbarSD;
        StdDevKbar += sqrt( avgKbarSD );
        A += AreaSum;
    }

    // Calculate the effective radius

    Acum = 0.0;
    for( i=0; i<numRings; i++ ) {
        Acum += A[i];
        Reff += sqrt(Acum/pi);
    }

    R += 0.0;
    for( i=1; i<numRings; i++ ) {
        R += 0.5*(Reff[i-1] + Reff[i]);
    }
    m_iNumRings = numRings;

    if( out != NULL ) {
        for( i=0; i<numRings; i++ ) {
            fprintf(out,"Ring %3d: %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n",
                        i, Kg[i], StdDevKg[i], Kbar[i], 
                        StdDevKbar[i], A[i], R[i], 
                        KgMax[i], KgMin[i], KbarMax[i], KbarMin[i] );
        }
        fclose(out);
    }
    delete [] ringIndices;
    delete [] ringSizes;

    return 0;
}

int MCDistribution::CreateFromFan(const Array< int > &spokeSize,
                                  const Array<R3Pt> &xyz,
                                  const Array<double> &K1,
                                  const Array<double> &K2,
                                  const Array<int> &valid,
                                  const int pointIndex, 
                                  const int maxRings)
{
    //int i, j, n, ipt, ier, nv, k0, k1, nRings;
    int i, j, k0, k1, nRings;
    double x0, y0, z0, x1, y1, z1, dx, dy, dz, d1, r; 
    double pi, kg, kb, denom, t;
    //double pi, kgmin, kgmax, kbarmin, kbarmax;
    //double AreaSum, Acum;
    //double avgKg, avgKbar, avgKgSD, avgKbarSD;

    //int *ringSizes;
    //int *ringIndices;
    //int ndx;

    // Work arrays
    SArray<int>    count;
    SArray<double> dist;
    SArray<double> KgSum;
    SArray<double> KgSumSq;
    SArray<double> KbarSum;
    SArray<double> KbarSumSq;

    pi = 4.0 * atan(1.0);

    FILE *out = NULL;
    //out = fopen(WINDataHome("dist_init.dat"),"w");

    // Initialize distribution data structures

    Clear();
    m_iPointIndex = pointIndex;

    // Find number of rings

    nRings = spokeSize[0]+1;
    for( i=1; i<spokeSize.num(); i++ ) {
        if( spokeSize[i] >= nRings ) nRings = spokeSize[i]+1;
    }
    if( nRings > maxRings ) nRings = maxRings;
    if( nRings < 1 ) nRings = 1;

    // Setup work arrays

    count.init(nRings);
    dist.init(nRings);
    KgSum.init(nRings);
    KgSumSq.init(nRings);
    KbarSum.init(nRings);
    KbarSumSq.init(nRings);

    m_iNumRings = nRings;

    for( j=0; j<nRings; j++ ) {
        count[j]     = 0;
        dist[j]      = 0.0;
        KgSum[j]     = 0.0;
        KgSumSq[j]   = 0.0;
        KbarSum[j]   = 0.0;
        KbarSumSq[j] = 0.0;
    }

    // Process center point (Ring 0) of fan

    kg = K1[0]*K2[0];//data[nData*0+3];
    kb = 0.5*(K1[0]+K2[0]);//data[nData*0+4]; 
    
    Kg += kg;
    KgMin += kg;
    KgMax += kg;
    StdDevKg += 0.0;
    Kbar += kb;
    KbarMin += kb;
    KbarMax += kb;
    StdDevKbar += 0.0;

    count[0]     = 1;
    dist[0]      = 0.0;
    KgSum[0]     = kg;
    KgSumSq[0]   = kg*kg;
    KbarSum[0]   = kb;
    KbarSumSq[0] = kb*kb;

    // Step through fan structure

    k1 = 0;
    for( i=0; i<spokeSize.num(); i++ ) {

        // Store the previous point
        k0 = 0;
        x0 = xyz[k0][0];//data[nData*k0  ];
        y0 = xyz[k0][1];//data[nData*k0+1];
        z0 = xyz[k0][2];//data[nData*k0+2];
        for( j=0; j<spokeSize[i]; j++ ) {
    
            k1++;
            if( !valid[k1] ) continue;

            // Compute distance to previous point
            x1 = xyz[k1][0];//data[nData*k1  ];
            y1 = xyz[k1][1];//data[nData*k1+1];
            z1 = xyz[k1][2];//data[nData*k1+2];
            dx = x1-x0;
            dy = y1-y0;
            dz = z1-z0;
            d1 = sqrt(dx*dx + dy*dy + dz*dz);

            // Update previous point
            x0 = x1;
            y0 = y1;
            z0 = z1;

            // Get curvatures
            kg = K1[k1]*K2[k1];//data[nData*k1+3];
            kb = 0.5*(K1[k1]+K2[k1]);//data[nData*k1+4];

            // Update arrays
            if( j+1 < nRings ) {
                count[j+1]     = count[j+1]     + 1;
                dist[j+1]      = dist[j+1]      + d1;
                KgSum[j+1]     = KgSum[j+1]     + kg;
                KgSumSq[j+1]   = KgSumSq[j+1]   + kg*kg;
                KbarSum[j+1]   = KbarSum[j+1]   + kb;
                KbarSumSq[j+1] = KbarSumSq[j+1] + kb*kb;
                if( count[j+1] == 1 ) {
                    KgMin   += kg;
                    KgMax   += kg;
                    KbarMin += kb;
                    KbarMax += kb;
                } else {
                    if( kg < KgMin[j+1]   ) KgMin[j+1]   = kg;
                    if( kg > KgMax[j+1]   ) KgMax[j+1]   = kg;
                    if( kb < KbarMin[j+1] ) KbarMin[j+1] = kb;
                    if( kb > KbarMax[j+1] ) KbarMax[j+1] = kb;
                }
            }
        }
    }

    // Compute the radii
    R += 0.0;
    for( j=1; j<nRings; j++ ) {
        if( count[j] > 0 ) {
            R += R[j-1] + dist[j]/(double)count[j];
        }
    }

    // Compute the areas
    r = R[1]*0.5;
    A += pi*r*r;
    for( j=1; j<nRings-1; j++ ) {
        r = 0.5*(R[j]+R[j+1]);
        A += pi*r*r - A[j-1];
    }
    r = 3.0*R[nRings-1] - R[nRings-2];
    A += pi*r*r - A[nRings-2];

    // Compute curvature properties
    //ipt = 0;
    for( i=1; i<nRings; i++ ) {
        if( count[i] < 1 ) return -1;
        denom = (double) count[i];

        Kg += KgSum[i] / denom;
        t = KgSumSq[i] / denom - Kg[i]*Kg[i];
        StdDevKg += sqrt( (t<0.0)?0.0:t );

        Kbar += KbarSum[i] / denom;
        t = KbarSumSq[i] / denom - Kbar[i]*Kbar[i];
        StdDevKbar += sqrt( (t<0.0)?0.0:t );
    }

    return 0;
}

int MCDistribution::getPoint(int iRing, double &out_Kg, double &out_Kbar, 
                             double &out_StdDevKg, double &out_StdDevKbar, 
                             double &out_A, double &out_R,
                             double &out_KgMax, double &out_KgMin, 
                             double &out_KbarMax, double &out_KbarMin ) const
{
    if( iRing < 0 || iRing >= Kg.num() ||
        iRing >= Kg.num() || iRing >= Kbar.num() ||
        iRing >= KgMin.num() || iRing >= KbarMin.num() ||
        iRing >= KgMax.num() || iRing >= KbarMax.num() ||
        iRing >= StdDevKg.num() || iRing >= StdDevKbar.num() ||
        iRing >= A.num() || iRing >= R.num() ) {
        return -1;
    }

    out_Kg         = Kg[iRing];
    out_Kbar       = Kbar[iRing];
    out_StdDevKg   = StdDevKg[iRing];
    out_StdDevKbar = StdDevKbar[iRing];
    out_A          = A[iRing];
    out_R          = R[iRing];
    out_KgMin      = KgMin[iRing];
    out_KgMax      = KgMax[iRing];
    out_KbarMin    = KbarMin[iRing];
    out_KbarMax    = KbarMax[iRing];

    return 0;
}

int MCDistribution::AddPoint(const double in_Kg,       const double in_Kbar, 
                             const double in_StdDevKg, const double in_StdDevKbar, 
                             const double in_A,        const double in_R,
                             const double in_KgMax,    const double in_KgMin, 
                             const double in_KbarMax,  const double in_KbarMin )
{
    A          += in_A;
    R          += in_R;
    Kg         += in_Kg;
    Kbar       += in_Kbar;
    StdDevKg   += in_StdDevKg;
    StdDevKbar += in_StdDevKbar;
    KgMin      += in_KgMin;
    KgMax      += in_KgMax;
    KbarMin    += in_KbarMin;
    KbarMax    += in_KbarMax;
    m_iNumRings++;

    return 0;
}

int MCDistribution::AddPoint(const int index, const int iRing, 
                             double *dbuf, const int nData )
{
    if( m_iPointIndex == -1 ) {
        m_iPointIndex = index;
    } 
    if( index != m_iPointIndex ) return -1;
    
    if( iRing != m_iNumRings ) return -1;

    if( nData < 6 ) return -1;
    A          += dbuf[0];
    R          += dbuf[1];
    Kg         += dbuf[2];
    Kbar       += dbuf[3];
    StdDevKg   += dbuf[4];
    StdDevKbar += dbuf[5];
    m_iNumRings++;

    if( nData < 10 ) return 0;
    KgMin   += dbuf[6];
    KgMax   += dbuf[7];
    KbarMin += dbuf[8];
    KbarMax += dbuf[9];

    return 0;
}

int MCDistribution::ProcessPoint(const int metric, const int statistic,
	                             const int isLog, const int isAreaWt,
						         const double kg, const double kbar, 
                                 const double kgSD, const double kbarSD, 
                                 const double area, const double radius, 
                                 const double kgMax, const double kbarMax, 
                                 const double kgMin, const double kbarMin,
						         double &gc, double &mc, 
								 double &gx, double &mx, double &r)
{
	int extra, stddev;

	extra = 0;
	stddev = 0;

	switch(statistic) {
	case 0:  // Avg
		gc = kg;
		mc = kbar;
		break;
	case 1:  // Min
		gc = kgMin;
		mc = kbarMin;
		break;
	case 2:  // Max
		gc = kgMax;
		mc = kbarMax;
		break;
	case 3:  // MinMax
		gc = kgMin;
		mc = kbarMin;
		gc = kgMax;
		mc = kbarMax;
		extra = 1;
		break;
	case 4:  // StdDev
		gc = kgSD;
		mc = kbarSD;
		stddev = 1;
		break;
	default:
		return -1;
	}

	if( isAreaWt ) {
		gc *= area;
		mc *= area;
		if( extra ) {
			gx *= area;
			mx *= area;
		}
	}

	if( metric == 3 ) {
		gc = (gc<0.0) ? -sqrt(-gc) : sqrt(gc);
		if( extra ) {
			gx = (gx<0.0) ? -sqrt(-gx) : sqrt(gx);
		}
	}

	if( isLog ) {
		gc = (gc<0.0) ? -log(1.0-gc) : log(1.0+gc);
		mc = (mc<0.0) ? -log(1.0-mc) : log(1.0+mc);
		if( extra ) {
			gx = (gx<0.0) ? -log(1.0-gx) : log(1.0+gx);
			mx = (mx<0.0) ? -log(1.0-mx) : log(1.0+mx);
		}
	}

	r = radius;

	return 0;
}

void MCDistribution::InterpolatePoint(const int extra, const double r0, 
		                              const double gc0, const double mc0, 
		                              const double gx0, const double mx0,
								      const double r1, 
									  const double gc1, const double mc1, 
		                              const double gx1, const double mx1,
								      const double r,  
									  double &gc, double &mc, 
		                              double &gx, double &mx)
{
	double u, v;

	if( r1 == r0 ) {
		u = 0.5;
	} else {
		u = ( r - r0 ) / ( r1 - r0 );
	}
	v = 1.0 - u;
		
	gc = v * gc0 + u * gc1;
	mc = v * mc0 + u * mc1;
	if( extra ) {
		gx = v * gx0 + u * gx1;
		mx = v * mx0 + u * mx1;
	}
}

double MCDistribution::Integrate(const int extra,   const int metric,
		                         const double r0,   const double r1, 
		                         const double gcA0, const double mcA0, 
		                         const double gxA0, const double mxA0,
						         const double gcA1, const double mcA1, 
		                         const double gxA1, const double mxA1,
						         const double gcB0, const double mcB0, 
		                         const double gxB0, const double mxB0,
						         const double gcB1, const double mcB1, 
		                         const double gxB1, const double mxB1)
{
	double a, dr, d0, d1, u;
	double area = 0.0;

	if( r0 == r1 ) return area;
	dr = r1 - r0;

	if( metric != 1 ) {  // Add contribution from Gaussian
		d0 = gcA0 - gcB0;
		d1 = gcA1 - gcB1;
		if( d0*d1 < 0.0 ) {
			u = d0 / (d0-d1);
			a = 0.5 * d0 * u * dr;
			area += (a<0.0) ? -a : a;
			a = 0.5 * d1 * (1.0-u) * dr;
			area += (a<0.0) ? -a : a;
		} else {
			a = 0.5 * (d0 + d1) * dr;
			area += (a<0.0) ? -a : a;
		}
		if( extra ) {
			d0 = gxA0 - gxB0;
			d1 = gxA1 - gxB1;
			if( d0*d1 < 0.0 ) {
				u = d0 / (d0-d1);
				a = 0.5 * d0 * u * dr;
				area += (a<0.0) ? -a : a;
				a = 0.5 * d1 * (1.0-u) * dr;
				area += (a<0.0) ? -a : a;
			} else {
				a = 0.5 * (d0 + d1) * dr;
				area += (a<0.0) ? -a : a;
			}
		}
	}

	if( metric != 0 ) {  // Add contribution from Mean
		d0 = mcA0 - mcB0;
		d1 = mcA1 - mcB1;
		if( d0*d1 < 0.0 ) {
			u = d0 / (d0-d1);
			a = 0.5 * d0 * u * dr;
			area += (a<0.0) ? -a : a;
			a = 0.5 * d1 * (1.0-u) * dr;
			area += (a<0.0) ? -a : a;
		} else {
			a = 0.5 * (d0 + d1) * dr;
			area += (a<0.0) ? -a : a;
		}
		if( extra ) {
			d0 = mxA0 - mxB0;
			d1 = mxA1 - mxB1;
			if( d0*d1 < 0.0 ) {
				u = d0 / (d0-d1);
				a = 0.5 * d0 * u * dr;
				area += (a<0.0) ? -a : a;
				a = 0.5 * d1 * (1.0-u) * dr;
				area += (a<0.0) ? -a : a;
			} else {
				a = 0.5 * (d0 + d1) * dr;
				area += (a<0.0) ? -a : a;
			}
		}
	}
	return area;
}

int MCDistribution::Integrate(const int extra,
		                      const double r0,   const double r1, 
		                      const double gcA0, const double mcA0, 
		                      const double gxA0, const double mxA0,
						      const double gcA1, const double mcA1, 
		                      const double gxA1, const double mxA1,
						      double &kGauss,    double &kMean) const
{
	double dr;

	if( r0 == r1 ) return -1;
	dr = r1 - r0;
	dr = (dr<0.0) ? -dr : dr;

	// Contribution from Gaussian

	kGauss = 0.5 * dr * (gcA1 + gcA0);

	if( extra ) {
		kGauss += 0.5 * dr * (gxA1 + gxA0);
	}

	// Add contribution from Mean

	kMean = 0.5 * dr * (mcA1 + mcA0);

	if( extra ) {
		kMean += 0.5 * dr * (mxA1 + mxA0);
	}

	return 0;
}

int MCDistribution::Difference(const int extra,
		                       const double r0,    const double r1, 
		                       const double gcA0,  const double mcA0, 
		                       const double gxA0,  const double mxA0,
						       const double gcA1,  const double mcA1, 
		                       const double gxA1,  const double mxA1,
						       const double gcB0,  const double mcB0, 
		                       const double gxB0,  const double mxB0,
						       const double gcB1,  const double mcB1, 
		                       const double gxB1,  const double mxB1,
							   double &deltaGauss, double &deltaMean) const
{
	double dr, d0, d1;

	if( r0 == r1 ) return -1;
	dr = r1 - r0;
	dr = (dr<0.0) ? -dr : dr;

	// Contribution from Gaussian

	d0 = gcA1 + gcA0;
	d1 = gcB1 + gcB0;
	deltaGauss = 0.5 * dr * (d1 - d0);

	if( extra ) {
		d0 = gxA1 + gxA0;
		d1 = gxB1 + gxB0;
		deltaGauss += 0.5 * dr * (d1 - d0);
	}

	// Add contribution from Mean

	d0 = mcA1 + mcA0;
	d1 = mcB1 + mcB0;
	deltaMean = 0.5 * dr * (d1 - d0);

	if( extra ) {
		d0 = mxA1 + mxA0;
		d1 = mxB1 + mxB0;
		deltaMean += 0.5 * dr * (d1 - d0);
	}

	return 0;
}

int MCDistribution::Value(MC_DataType dataType, 
                          const int iRing, double &value ) const
{
    int ier = 0;
    //const MCDistribution *m;

    if( iRing < 0 || iRing >= m_iNumRings ) return -1;

    switch(dataType) {
    case AREA:
        if( iRing >= A.num() ) return -2;
        value = A[iRing];
        break;
    case RADIUS:
        if( iRing >= R.num() ) return -2;
        value = R[iRing];
        break;
    case KG:
        if( iRing >= Kg.num() ) return -2;
        value = Kg[iRing];
        break;
    case KBAR:
        if( iRing >= Kbar.num() ) return -2;
        value = Kbar[iRing];
        break;
    case KGSD:
        if( iRing >= StdDevKg.num() ) return -2;
        value = StdDevKg[iRing];
        break;
    case KBARSD:
        if( iRing >= StdDevKbar.num() ) return -2;
        value = StdDevKbar[iRing];
        break;
    case KGMIN:
        if( iRing >= KgMin.num() ) return -2;
        value = KgMin[iRing];
        break;
    case KGMAX:
        if( iRing >= KgMax.num() ) return -2;
        value = KgMax[iRing];
        break;
    case KBARMIN:
        if( iRing >= KbarMin.num() ) return -2;
        value = KbarMin[iRing];
        break;
    case KBARMAX:
        if( iRing >= KbarMax.num() ) return -2;
        value = KbarMax[iRing];
        break;
    default:
        return -1;
    }

    return 0;
}

int MCDistribution::WriteMap(FILE *out) const
{
    int i;

    // Check for output file
    if( out == NULL ) return -1;
    
    // Check for valid curvature map
    if( m_iNumRings <= 0 ) return -2;
    if( Kg.num()    != m_iNumRings || Kbar.num()       != m_iNumRings ||
        KgMax.num() != m_iNumRings || KbarMin.num()    != m_iNumRings ||
        KgMax.num() != m_iNumRings || KbarMin.num()    != m_iNumRings ||
        A.num()     != m_iNumRings || StdDevKg.num()   != m_iNumRings ||  
        R.num()     != m_iNumRings || StdDevKbar.num() != m_iNumRings ) {
        return -2;
    }

    // Write the map
    for( i=0; i<m_iNumRings; i++ ) {
        fprintf(out,"%5d %5d %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf\n",
                    m_iPointIndex, i, A[i], R[i],
                    Kg[i], Kbar[i], StdDevKg[i], StdDevKbar[i],
                    KgMax[i], KgMin[i], KbarMax[i], KbarMin[i] );
    }
    fprintf(out,"\n\n");

    return 0;
}

int MCDistribution::CreateCurve(MCDistribution::MC_DataType indep, 
                                MCDistribution::MC_DataType dep,
                                const int maxPoints, const int id,
                                tdgCurve2D &curve ) const
{
    int ier, i, n;
    double x, y;

    curve.Clear();

    n = this->Size();
    if( n > maxPoints ) n = maxPoints;

    for( i=0; i<n; i++ ) {
        ier = Value(indep, i, x);
        if( ier != 0 ) return ier;
        ier = Value(dep, i, y);
        if( ier != 0 ) return ier;
        curve.Add(x,y);
    }
    curve.Label(Description());
    curve.Id(id);
    curve.Index(dep);

    return 0;
}

int MCDistribution::MaxPos(MCDistribution::MC_DataType type, double &r) const
{
    int ier, i, n;
    double x1, x2, r1, r2;

	r = 0.0;

    n = Size();
    if( n<2 ) return -1;

    ier = Value(type, 0, x2);
    if( ier != 0 ) return ier;

	if( x2 <= 0.0 ) {
		r = 0.0;
	} else {
		ier = Value(RADIUS, n-1, r);
		if( ier != 0 ) return ier;

		for( i=1; i<n; i++ ) {
			x1 = x2;

			ier = Value(type, i, x2);
			if( ier != 0 ) return ier;

			if( x2 <= 0.0 ) {
				ier = Value(RADIUS, i-1, r1);
				if( ier != 0 ) return ier;
				ier = Value(RADIUS, i, r2);
				if( ier != 0 ) return ier;

				if( x1 == x2 ) {
					r = r1;
				} else {
					r = (x2*r1 - x1*r2)/(x2-x1);
				}
				break;
			}
		}
	}

    return 0;
}

int MCDistribution::MaxNeg(MCDistribution::MC_DataType type, double &r) const
{
    int ier, i, n;
    double x1, x2, r1, r2;

	r = 0.0;

    n = Size();
    if( n<2 ) return -1;

    ier = Value(type, 0, x2);
    if( ier != 0 ) return ier;

	if( x2 >= 0.0 ) {
		r = 0.0;
	} else {
		ier = Value(RADIUS, n-1, r);
		if( ier != 0 ) return ier;

		for( i=1; i<n; i++ ) {
			x1 = x2;

			ier = Value(type, i, x2);
			if( ier != 0 ) return ier;

			if( x2 >= 0.0 ) {
				ier = Value(RADIUS, i-1, r1);
				if( ier != 0 ) return ier;
				ier = Value(RADIUS, i, r2);
				if( ier != 0 ) return ier;

				if( x1 == x2 ) {
					r = r1;
				} else {
					r = (x2*r1 - x1*r2)/(x2-x1);
				}
				break;
			}
		}
	}

    return 0;
}

int MCDistribution::MaxMonoPosInc(MCDistribution::MC_DataType type, double &r) const
{
    int ier, i, n;
    double x1, x2;

	r = 0.0;

    n = Size();
    if( n<2 ) return -1;

    ier = Value(type, 0, x2);
    if( ier != 0 ) return ier;

	if( x2 <= 0.0 ) {
		r = 0.0;
	} else {
		ier = Value(RADIUS, n-1, r);
		if( ier != 0 ) return ier;

		for( i=1; i<n; i++ ) {
			x1 = x2;

			ier = Value(type, i, x2);
			if( ier != 0 ) return ier;

			if( x2 < x1 ) {
				ier = Value(RADIUS, i-1, r);
				if( ier != 0 ) return ier;
				break;
			}
		}
	}

    return 0;
}

int MCDistribution::MaxMonoPosDec(MCDistribution::MC_DataType type, double &r) const
{
    int ier, i, n;
    double x1, x2, r1, r2;

	r = 0.0;

    n = Size();
    if( n<2 ) return -1;

    ier = Value(type, 0, x2);
    if( ier != 0 ) return ier;

	if( x2 <= 0.0 ) {
		r = 0.0;
	} else {
		ier = Value(RADIUS, n-1, r);
		if( ier != 0 ) return ier;

		for( i=1; i<n; i++ ) {
			x1 = x2;

			ier = Value(type, i, x2);
			if( ier != 0 ) return ier;

			if( x2 <= 0.0 ) {
				ier = Value(RADIUS, i-1, r1);
				if( ier != 0 ) return ier;
				ier = Value(RADIUS, i, r2);
				if( ier != 0 ) return ier;

				if( x1 == x2 ) {
					r = r1;
				} else {
					r = (x2*r1 - x1*r2)/(x2-x1);
				}
				break;
			}
			if( x2 > x1 ) {
				ier = Value(RADIUS, i-1, r);
				if( ier != 0 ) return ier;
				break;
			}
		}
	}

    return 0;
}

int MCDistribution::MaxMonoNegInc(MCDistribution::MC_DataType type, double &r) const
{
    int ier, i, n;
    double x1, x2, r1, r2;

	r = 0.0;

    n = Size();
    if( n<2 ) return -1;

    ier = Value(type, 0, x2);
    if( ier != 0 ) return ier;

	if( x2 >= 0.0 ) {
		r = 0.0;
	} else {
		ier = Value(RADIUS, n-1, r);
		if( ier != 0 ) return ier;

		for( i=1; i<n; i++ ) {
			x1 = x2;

			ier = Value(type, i, x2);
			if( ier != 0 ) return ier;

			if( x2 >= 0.0 ) {
				ier = Value(RADIUS, i-1, r1);
				if( ier != 0 ) return ier;
				ier = Value(RADIUS, i, r2);
				if( ier != 0 ) return ier;

				if( x1 == x2 ) {
					r = r1;
				} else {
					r = (x2*r1 - x1*r2)/(x2-x1);
				}
				break;
			}
			if( x2 < x1 ) {
				ier = Value(RADIUS, i-1, r);
				if( ier != 0 ) return ier;
				break;
			}
		}
	}

    return 0;
}

int MCDistribution::MaxMonoNegDec(MCDistribution::MC_DataType type, double &r) const
{
    int ier, i, n;
    double x1, x2;

	r = 0.0;

    n = Size();
    if( n<2 ) return -1;

    ier = Value(type, 0, x2);
    if( ier != 0 ) return ier;

	if( x2 >= 0.0 ) {
		r = 0.0;
	} else {
		ier = Value(RADIUS, n-1, r);
		if( ier != 0 ) return ier;

		for( i=1; i<n; i++ ) {
			x1 = x2;

			ier = Value(type, i, x2);
			if( ier != 0 ) return ier;

			if( x2 > x1 ) {
				ier = Value(RADIUS, i-1, r);
				if( ier != 0 ) return ier;
				break;
			}
		}
	}

    return 0;
}

int MCDistribution::MaxMonotonic(int &iDirG, int &iNg, double &dRg, double &dAg,
                                 int &iDirM, int &iNm, double &dRm, double &dAm) const
{
    int ier, i, n;
    double x1, x2;

    n = this->Size();
    if( n<2 ) return -1;

    ier = Value(KG, 0, x1);
    if( ier != 0 ) return ier;

    ier = Value(KG, 1, x2);
    if( ier != 0 ) return ier;

    i = 1;

    if( x1 < x2 ) {
        iDirG = -1;
    } else {
        iDirG = 1;
    }
    while( x1*iDirG >= x2*iDirG && i < n )
    {
        iNg = i;
        i++;
        x1 = x2;
        ier = Value(KG, i, x2);
        if( ier != 0 ) return ier;
    }
    ier = Value(RADIUS, iNg, dRg);
    if( ier != 0 ) return ier;

    ier = Value(AREA, iNg, dAg);
    if( ier != 0 ) return ier;

    ier = Value(KBAR, 0, x1);
    if( ier != 0 ) return ier;

    ier = Value(KBAR, 1, x2);
    if( ier != 0 ) return ier;

    i = 1;

    if( x1 < x2 ) {
        iDirM = -1;
    } else {
        iDirM = 1;
    }
    while( x1*iDirM >= x2*iDirM && i < n )
    {
        iNm = i;
        i++;
        x1 = x2;
        ier = Value(KBAR, i, x2);
        if( ier != 0 ) return ier;
    }
    ier = Value(RADIUS, iNm, dRm);
    if( ier != 0 ) return ier;

    ier = Value(AREA, iNm, dAm);
    if( ier != 0 ) return ier;

    return 0;
}

int MCDistribution::FindZeroGauss(double &r, int &dir) const
{
    int ier, i, j, n;
    double x1, x2, r1, r2, f;

    n = this->Size();
    if( n<2 ) return -1;

    ier = Value(KG, 0, x1);
    if( ier != 0 ) return ier;

	if( x1 == 0.0 ) {
		r = 0.0;
		dir = 0;
		return 0;
	}

	if( x1 > 0.0 ) {
		dir = -1;
	} else {
		dir = 1;
	}

	j = n-2;
	f = 1.0;
	for( i=1; i<n; i++ ) {
		ier = Value(KG, i, x2);
		if( ier != 0 ) return ier;
		
		if( x2*x1 <= 0.0 ) {
			j = i-1;
			f = -x1 / (x2-x1);
			break;
		}
        x1 = x2;
    }
    ier = Value(RADIUS, j, r1);
    if( ier != 0 ) return ier;

    ier = Value(RADIUS, j+1, r2);
    if( ier != 0 ) return ier;

	r = (1.0-f)*r1 + f*r2;

    return 0;
}

int MCDistribution::FindZeroMean(double &r, int &dir) const
{
    int ier, i, j, n;
    double x1, x2, r1, r2, f;

    n = this->Size();
    if( n<2 ) return -1;

    ier = Value(KBAR, 0, x1);
    if( ier != 0 ) return ier;

	if( x1 == 0.0 ) {
		r = 0.0;
		dir = 0;
		return 0;
	}

	if( x1 > 0.0 ) {
		dir = -1;
	} else {
		dir = 1;
	}

	j = n-2;
	f = 1.0;
	for( i=1; i<n; i++ ) {
		ier = Value(KBAR, 1, x2);
		if( ier != 0 ) return ier;
		
		if( x2*x1 <= 0.0 ) {
			j = i-1;
			f = -x1 / (x2-x1);
			break;
		}
        x1 = x2;
    }
    ier = Value(RADIUS, j, r1);
    if( ier != 0 ) return ier;

    ier = Value(RADIUS, j+1, r2);
    if( ier != 0 ) return ier;

	r = (1.0-f)*r1 + f*r2;

    return 0;
}

void MCDistribution::dump(FILE *out) const
{
    int i;

    if( out != NULL ) {
        if( m_sDescription != NULL ) {
            fprintf(out,"Mesh: \"%s\"\n",m_sDescription);
        } else {
            fprintf(out,"Mesh: UNKNOWN\n");
        }
        if( m_iNumRings > 0 ) {
            fprintf(out,"       Kg       Kbar      ");
            fprintf(out,"   Std Dev Kg Std Dev Kbar");
            fprintf(out,"      Area     Radius     ");
            fprintf(out,"     KgMax     KgMin      ");
            fprintf(out,"    KbarMax   KbarMin     \n");
            fprintf(out," Point Index: %d\n", m_iPointIndex);

            for( i=0; i<m_iNumRings; i++ ) {
                fprintf(out," Ring %d: %lf, %lf, %lf, %lf, ",
                        i, Kg[i], Kbar[i], StdDevKg[i], StdDevKbar[i]);
                fprintf(out,"%lf, %lf, %lf, %lf, %lf, %lf\n",
                        A[i], R[i],KgMax[i],KgMin[i],KbarMax[i],KbarMin[i]);
            }
        }
    }
}

/*
double MCDistribution::Compare(const MCDistribution &dist, 
                               MC_MapMetric method, 
                               const int maxRings) const
{
    int ier, nRing, iRing;
    double kg1, kg2, kbar1, kbar2, kgSD1, kgSD2, kbarSD1, kbarSD2, 
           area1, area2, radius1, radius2;
    double kgmax1, kgmax2, kgmin1, kgmin2, kbarmax1, kbarmax2, 
           kbarmin1, kbarmin2, sum, delta, value, value1, value2;

    nRing = maxRings;;
    if( Size() < nRing ) nRing = Size();
    if( dist.Size() < nRing ) nRing = dist.Size();
    if( nRing < 1 ) return 0.0;

    sum = 0.0;
    switch(method) {

    case RMS_GAUSS:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kg2 - kg1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MEAN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kbar2 - kbar1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_BOTH:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kg2 - kg1;
            sum += delta * delta;
            delta = kbar2 - kbar1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MOD:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kg2 < 0.0) ? -sqrt(-kg2) : sqrt(kg2);
            value1 = (kg1 < 0.0) ? -sqrt(-kg1) : sqrt(kg1);
            delta = value2 - value1;
            sum += delta * delta;
            delta = kbar2 - kbar1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_GAUSS:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kg2 < 0.0) ? -log(1.0-kg2) : log(1.0+kg2);
            value1 = (kg1 < 0.0) ? -log(1.0-kg1) : log(1.0+kg1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MEAN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kbar2 < 0.0) ? -log(1.0-kbar2) : log(1.0+kbar2);
            value1 = (kbar1 < 0.0) ? -log(1.0-kbar1) : log(1.0+kbar1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_BOTH:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kg2 < 0.0) ? -log(1.0-kg2) : log(1.0+kg2);
            value1 = (kg1 < 0.0) ? -log(1.0-kg1) : log(1.0+kg1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbar2 < 0.0) ? -log(1.0-kbar2) : log(1.0+kbar2);
            value1 = (kbar1 < 0.0) ? -log(1.0-kbar1) : log(1.0+kbar1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MOD:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kg2 < 0.0) ? -sqrt(-kg2) : sqrt(kg2);
            value1 = (kg1 < 0.0) ? -sqrt(-kg1) : sqrt(kg1);
            value2 = (value2 < 0.0) ? -log(1.0-value2) : log(1.0+value2);
            value1 = (value1 < 0.0) ? -log(1.0-value1) : log(1.0+value1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbar2 < 0.0) ? -log(1.0-kbar2) : log(1.0+kbar2);
            value1 = (kbar1 < 0.0) ? -log(1.0-kbar1) : log(1.0+kbar1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_SDGAUSS:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kgSD2 - kgSD1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_SDMEAN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kbarSD2 - kbarSD1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_GAUSS_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kgmin2 - kgmin1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_GAUSS_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kgmax2 - kgmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_GAUSS_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kgmin2 - kgmin1;
            sum += delta * delta;

            delta = kgmax2 - kgmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MEAN_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kbarmin2 - kbarmin1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MEAN_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kbarmax2 - kbarmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MEAN_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kbarmin2 - kbarmin1;
            sum += delta * delta;

            delta = kbarmax2 - kbarmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_BOTH_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kgmin2 - kgmin1;
            sum += delta * delta;

            delta = kbarmin2 - kbarmin1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_BOTH_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kgmax2 - kgmax1;
            sum += delta * delta;

            delta = kbarmax2 - kbarmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_BOTH_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            delta = kgmin2 - kgmin1;
            sum += delta * delta;

            delta = kbarmin2 - kbarmin1;
            sum += delta * delta;

            delta = kgmax2 - kgmax1;
            sum += delta * delta;

            delta = kbarmax2 - kbarmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MOD_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -sqrt(-kgmin2) : sqrt(kgmin2);
            value1 = (kgmin1 < 0.0) ? -sqrt(-kgmin1) : sqrt(kgmin1);
            delta = value2 - value1;
            sum += delta * delta;
            delta = kbarmin2 - kbarmin1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MOD_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmax2 < 0.0) ? -sqrt(-kgmax2) : sqrt(kgmax2);
            value1 = (kgmax1 < 0.0) ? -sqrt(-kgmax1) : sqrt(kgmax1);
            delta = value2 - value1;
            sum += delta * delta;
            delta = kbarmax2 - kbarmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case RMS_MOD_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -sqrt(-kgmin2) : sqrt(kgmin2);
            value1 = (kgmin1 < 0.0) ? -sqrt(-kgmin1) : sqrt(kgmin1);
            delta = value2 - value1;
            sum += delta * delta;
            delta = kbarmin2 - kbarmin1;
            sum += delta * delta;

            value2 = (kgmax2 < 0.0) ? -sqrt(-kgmax2) : sqrt(kgmax2);
            value1 = (kgmax1 < 0.0) ? -sqrt(-kgmax1) : sqrt(kgmax1);
            delta = value2 - value1;
            sum += delta * delta;
            delta = kbarmax2 - kbarmax1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_GAUSS_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -log(1.0-kgmin2) : log(1.0+kgmin2);
            value1 = (kgmin1 < 0.0) ? -log(1.0-kgmin1) : log(1.0+kgmin1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_GAUSS_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmax2 < 0.0) ? -log(1.0-kgmax2) : log(1.0+kgmax2);
            value1 = (kgmax1 < 0.0) ? -log(1.0-kgmax1) : log(1.0+kgmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_GAUSS_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -log(1.0-kgmin2) : log(1.0+kgmin2);
            value1 = (kgmin1 < 0.0) ? -log(1.0-kgmin1) : log(1.0+kgmin1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kgmax2 < 0.0) ? -log(1.0-kgmax2) : log(1.0+kgmax2);
            value1 = (kgmax1 < 0.0) ? -log(1.0-kgmax1) : log(1.0+kgmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MEAN_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kbarmin2 < 0.0) ? -log(1.0-kbarmin2) : log(1.0+kbarmin2);
            value1 = (kbarmin1 < 0.0) ? -log(1.0-kbarmin1) : log(1.0+kbarmin1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MEAN_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kbarmax2 < 0.0) ? -log(1.0-kbarmax2) : log(1.0+kbarmax2);
            value1 = (kbarmax1 < 0.0) ? -log(1.0-kbarmax1) : log(1.0+kbarmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MEAN_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kbarmin2 < 0.0) ? -log(1.0-kbarmin2) : log(1.0+kbarmin2);
            value1 = (kbarmin1 < 0.0) ? -log(1.0-kbarmin1) : log(1.0+kbarmin1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmax2 < 0.0) ? -log(1.0-kbarmax2) : log(1.0+kbarmax2);
            value1 = (kbarmax1 < 0.0) ? -log(1.0-kbarmax1) : log(1.0+kbarmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_BOTH_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -log(1.0-kgmin2) : log(1.0+kgmin2);
            value1 = (kgmin1 < 0.0) ? -log(1.0-kgmin1) : log(1.0+kgmin1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmin2 < 0.0) ? -log(1.0-kbarmin2) : log(1.0+kbarmin2);
            value1 = (kbarmin1 < 0.0) ? -log(1.0-kbarmin1) : log(1.0+kbarmin1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_BOTH_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmax2 < 0.0) ? -log(1.0-kgmax2) : log(1.0+kgmax2);
            value1 = (kgmax1 < 0.0) ? -log(1.0-kgmax1) : log(1.0+kgmax1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmax2 < 0.0) ? -log(1.0-kbarmax2) : log(1.0+kbarmax2);
            value1 = (kbarmax1 < 0.0) ? -log(1.0-kbarmax1) : log(1.0+kbarmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_BOTH_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -log(1.0-kgmin2) : log(1.0+kgmin2);
            value1 = (kgmin1 < 0.0) ? -log(1.0-kgmin1) : log(1.0+kgmin1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmin2 < 0.0) ? -log(1.0-kbarmin2) : log(1.0+kbarmin2);
            value1 = (kbarmin1 < 0.0) ? -log(1.0-kbarmin1) : log(1.0+kbarmin1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kgmax2 < 0.0) ? -log(1.0-kgmax2) : log(1.0+kgmax2);
            value1 = (kgmax1 < 0.0) ? -log(1.0-kgmax1) : log(1.0+kgmax1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmax2 < 0.0) ? -log(1.0-kbarmax2) : log(1.0+kbarmax2);
            value1 = (kbarmax1 < 0.0) ? -log(1.0-kbarmax1) : log(1.0+kbarmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MOD_MIN:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -sqrt(-kgmin2) : sqrt(kgmin2);
            value1 = (kgmin1 < 0.0) ? -sqrt(-kgmin1) : sqrt(kgmin1);
            value2 = (value2 < 0.0) ? -log(1.0-value2) : log(1.0+value2);
            value1 = (value1 < 0.0) ? -log(1.0-value1) : log(1.0+value1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmin2 < 0.0) ? -log(1.0-kbarmin2) : log(1.0+kbarmin2);
            value1 = (kbarmin1 < 0.0) ? -log(1.0-kbarmin1) : log(1.0+kbarmin1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MOD_MAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmax2 < 0.0) ? -sqrt(-kgmax2) : sqrt(kgmax2);
            value1 = (kgmax1 < 0.0) ? -sqrt(-kgmax1) : sqrt(kgmax1);
            value2 = (value2 < 0.0) ? -log(1.0-value2) : log(1.0+value2);
            value1 = (value1 < 0.0) ? -log(1.0-value1) : log(1.0+value1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmax2 < 0.0) ? -log(1.0-kbarmax2) : log(1.0+kbarmax2);
            value1 = (kbarmax1 < 0.0) ? -log(1.0-kbarmax1) : log(1.0+kbarmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    case LOG_MOD_MINMAX:
        for( iRing=0; iRing<nRing; iRing++ ) {
            ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

            ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                       kgmax2, kgmin2, kbarmax2, kbarmin2);

            value2 = (kgmin2 < 0.0) ? -sqrt(-kgmin2) : sqrt(kgmin2);
            value1 = (kgmin1 < 0.0) ? -sqrt(-kgmin1) : sqrt(kgmin1);
            value2 = (value2 < 0.0) ? -log(1.0-value2) : log(1.0+value2);
            value1 = (value1 < 0.0) ? -log(1.0-value1) : log(1.0+value1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmin2 < 0.0) ? -log(1.0-kbarmin2) : log(1.0+kbarmin2);
            value1 = (kbarmin1 < 0.0) ? -log(1.0-kbarmin1) : log(1.0+kbarmin1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kgmax2 < 0.0) ? -sqrt(-kgmax2) : sqrt(kgmax2);
            value1 = (kgmax1 < 0.0) ? -sqrt(-kgmax1) : sqrt(kgmax1);
            value2 = (value2 < 0.0) ? -log(1.0-value2) : log(1.0+value2);
            value1 = (value1 < 0.0) ? -log(1.0-value1) : log(1.0+value1);
            delta = value2 - value1;
            sum += delta * delta;

            value2 = (kbarmax2 < 0.0) ? -log(1.0-kbarmax2) : log(1.0+kbarmax2);
            value1 = (kbarmax1 < 0.0) ? -log(1.0-kbarmax1) : log(1.0+kbarmax1);
            delta = value2 - value1;
            sum += delta * delta;
        }
        value = sqrt(sum/(double)nRing);
        break;

    default:
        break;
    }

    return value;
}
*/

#define MC_ERROR -987.654

double MCDistribution::Compare(const MCDistribution &dist, 
                               MC_MapMetric method, 
                               const int maxRings,
                               const int areaWt) const
{
    int ier, nRing, iRing, metric, statistic, function;
    double kg1, kg2, kbar1, kbar2, kgSD1, kgSD2, kbarSD1, kbarSD2, 
           area1, area2, radius1, radius2;
    double kgmax1, kgmax2, kgmin1, kgmin2, kbarmax1, kbarmax2, 
           kbarmin1, kbarmin2, sum, delta, value;
    double g1, g2, m1, m2, Acum;

    nRing = maxRings;;
    if( Size() < nRing ) nRing = Size();
    if( dist.Size() < nRing ) nRing = dist.Size();
    if( nRing < 1 ) return 0.0;

    Decompose(method, metric, statistic, function);

    sum = 0.0;
    Acum = 0.0;
    for( iRing=0; iRing<nRing; iRing++ ) {
        ier = getPoint(iRing, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                              kgmax1, kgmin1, kbarmax1, kbarmin1);
        if( ier != 0 ) return MC_ERROR;

        if( areaWt != 0 ) {
            kg1      *= area1;
            kbar1    *= area1;
            kgSD1    *= area1;
            kbarSD1  *= area1;
            kgmax1   *= area1;
            kgmin1   *= area1;
            kbarmax1 *= area1;
            kbarmin1 *= area1;
            Acum     += area1;
        }

        ier = dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                   kgmax2, kgmin2, kbarmax2, kbarmin2);
        if( ier != 0 ) return MC_ERROR;

        if( areaWt != 0 ) {
            kg2      *= area2;
            kbar2    *= area2;
            kgSD2    *= area2;
            kbarSD2  *= area2;
            kgmax2   *= area2;
            kgmin2   *= area2;
            kbarmax2 *= area2;
            kbarmin2 *= area2;
            Acum     += area2;
        }

        switch(statistic) {
        case 0:   // Avg
            g1 = kg1;
            g2 = kg2;
            m1 = kbar1;
            m2 = kbar2;
            break;
        case 1:   // Min
        case 3:   // MinMax
            g1 = kgmin1;
            g2 = kgmin2;
            m1 = kbarmin1;
            m2 = kbarmin2;
            break;
        case 2:   // Max
            g1 = kgmax1;
            g2 = kgmax2;
            m1 = kbarmax1;
            m2 = kbarmax2;
            break;
        case 4:   // StdDev
            g1 = kgSD1;
            g2 = kgSD2;
            m1 = kbarSD1;
            m2 = kbarSD2;
            break;
        default:
            return MC_ERROR;
        }

        if( metric == 3 ) {   // Mod
            g1 = (g1<0.0) ? -sqrt(-g1) : sqrt(g1);
            g2 = (g2<0.0) ? -sqrt(-g2) : sqrt(g2);
        }
        if( function == 1 ) {   // Log
            g1 = (g1<0.0) ? -log(1.0-g1) : log(1.0+g1);
            g2 = (g2<0.0) ? -log(1.0-g2) : log(1.0+g2);
            m1 = (m1<0.0) ? -log(1.0-m1) : log(1.0+m1);
            m2 = (m2<0.0) ? -log(1.0-m2) : log(1.0+m2);
        }
        if( metric != 1 ) {   // Not just Mean
            delta = g2-g1;
            sum += delta * delta;
        }
        if( metric != 0 ) {   // Not just Gaussian
            delta = m2-m1;
            sum += delta * delta;
        }

        if( statistic == 3 ) {   // Now do max part of MinMax
            g1 = kgmax1;
            g2 = kgmax2;
            m1 = kbarmax1;
            m2 = kbarmax2;

            if( metric == 3 ) {   // Mod
                g1 = (g1<0.0) ? -sqrt(-g1) : sqrt(g1);
                g2 = (g2<0.0) ? -sqrt(-g2) : sqrt(g2);
            }
            if( function == 1 ) {   // Log
                g1 = (g1<0.0) ? -log(1.0-g1) : log(1.0+g1);
                g2 = (g2<0.0) ? -log(1.0-g2) : log(1.0+g2);
                m1 = (m1<0.0) ? -log(1.0-m1) : log(1.0+m1);
                m2 = (m2<0.0) ? -log(1.0-m2) : log(1.0+m2);
            }
            if( metric != 1 ) {   // Not just Mean
                delta = g2-g1;
                sum += delta * delta;
            }
            if( metric != 0 ) {   // Not just Gaussian
                delta = m2-m1;
                sum += delta * delta;
            }
        }
    }
    value = sqrt(sum/(double)nRing);
    if( areaWt != 0 && Acum != 0.0 ) value /= Acum;

    return value;
}

//double MCDistribution::AreaWtCompare(const MCDistribution &dist, 
//                                     MC_MapMetric method, 
//                                     const int maxRings) const
double MCDistribution::CompareIntegral(const MCDistribution &dist, 
                                       MC_MapMetric method, 
                                       const int maxRings,
                                       const int areaWt) const
{
    int ier, nRing, metric, statistic, function;
    int ia0, ia1, ib0, ib1;
    double kg1, kg2, kbar1, kbar2, kgSD1, kgSD2, kbarSD1, kbarSD2, 
           area1, area2, radius1, radius2;
    double kgmax1, kgmax2, kgmin1, kgmin2, kbarmax1, kbarmax2, 
           kbarmin1, kbarmin2, sum, delta, value;
    double gla1, glb1, gua1, gub1, mla1, mlb1, mua1, mub1;
    double gla0, glb0, gua0, gub0, mla0, mlb0, mua0, mub0;
    double u0, u1, v0, v1, Aa0, Aa1, Ab0, Ab1, Area, Acum;
    double Fgla0, Fgla1, Fgua0, Fgua1, Fmla0, Fmla1, Fmua0, Fmua1;
    double Fglb0, Fglb1, Fgub0, Fgub1, Fmlb0, Fmlb1, Fmub0, Fmub1;
    double Fgla, Fgua, Fglb, Fgub, Fmla, Fmua, Fmlb, Fmub;
    double R0, R1, Ra0, Ra1, Rb0, Rb1, pi;

    nRing = maxRings;
    if( Size() < nRing ) nRing = Size();
    if( dist.Size() < nRing ) nRing = dist.Size();
    if( nRing < 1 ) return 0.0;

    if( nRing == 1 ) return Compare(dist, method, nRing, areaWt);

    Decompose(method, metric, statistic, function);

    pi = 4.0*atan(1.0);

    gla1 = 0.0;
    glb1 = 0.0;
    gua1 = 0.0;
    gub1 = 0.0;
    mla1 = 0.0;
    mlb1 = 0.0;
    mua1 = 0.0;
    mub1 = 0.0;

    sum = 0.0;
    Acum = 0.0;
    ia0 = 0;
    ia1 = 0;
    ib0 = 0;
    ib1 = 0;
    ier = getPoint(ia0, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                        kgmax1, kgmin1, kbarmax1, kbarmin1);
    if( ier != 0 ) return MC_ERROR;

    if( areaWt != 0 ) {
        kg1      *= area1;
        kbar1    *= area1;
        kgSD1    *= area1;
        kbarSD1  *= area1;
        kgmax1   *= area1;
        kgmin1   *= area1;
        kbarmax1 *= area1;
        kbarmin1 *= area1;
    }

    ier = dist.getPoint(ib0, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                             kgmax2, kgmin2, kbarmax2, kbarmin2);
    if( ier != 0 ) return MC_ERROR;

    if( areaWt != 0 ) {
        kg2      *= area2;
        kbar2    *= area2;
        kgSD2    *= area2;
        kbarSD2  *= area2;
        kgmax2   *= area2;
        kgmin2   *= area2;
        kbarmax2 *= area2;
        kbarmin2 *= area2;
    }

    Ra1 = radius1;
    Rb1 = radius2;
    Aa1 = area1;
    Ab1 = area2;

    switch(statistic) {
    case 0:   // Avg
        gla1 = kg1;
        glb1 = kg2;
        mla1 = kbar1;
        mlb1 = kbar2;
        break;
    case 1:   // Min
        gla1 = kgmin1;
        glb1 = kgmin2;
        mla1 = kbarmin1;
        mlb1 = kbarmin2;
        break;
    case 2:   // Max
        gua1 = kgmax1;
        gub1 = kgmax2;
        mua1 = kbarmax1;
        mub1 = kbarmax2;
        break;
    case 3:   // MinMax
        gla1 = kgmin1;
        glb1 = kgmin2;
        gua1 = kgmax1;
        gub1 = kgmax2;
        mla1 = kbarmin1;
        mlb1 = kbarmin2;
        mua1 = kbarmax1;
        mub1 = kbarmax2;
        break;
    case 4:   // StdDev
        gla1 = kgSD1;
        glb1 = kgSD2;
        mla1 = kbarSD1;
        mlb1 = kbarSD2;
        break;
    default:
        return MC_ERROR;
    }

    if( metric == 3 ) {   // Mod
        gla1 = (gla1<0.0) ? -sqrt(-gla1) : sqrt(gla1);
        glb1 = (glb1<0.0) ? -sqrt(-glb1) : sqrt(glb1);
        gua1 = (gua1<0.0) ? -sqrt(-gua1) : sqrt(gua1);
        gub1 = (gub1<0.0) ? -sqrt(-gub1) : sqrt(gub1);
    }
    if( function == 1 ) {   // Log
        gla1 = (gla1<0.0) ? -log(1.0-gla1) : log(1.0+gla1);
        glb1 = (glb1<0.0) ? -log(1.0-glb1) : log(1.0+glb1);
        gua1 = (gua1<0.0) ? -log(1.0-gua1) : log(1.0+gua1);
        gub1 = (gub1<0.0) ? -log(1.0-gub1) : log(1.0+gub1);
        mla1 = (mla1<0.0) ? -log(1.0-mla1) : log(1.0+mla1);
        mlb1 = (mlb1<0.0) ? -log(1.0-mlb1) : log(1.0+mlb1);
        mua1 = (mua1<0.0) ? -log(1.0-mua1) : log(1.0+mua1);
        mub1 = (mub1<0.0) ? -log(1.0-mub1) : log(1.0+mub1);
    }

    R1 = 0.0;

    while( ia0 < nRing-1 && ib0 < nRing-1 )
    {
        // Update data for the next ring interval in Distribution A
        if( ia0 == ia1 ) {
            gla0 = gla1;
            gua0 = gua1;
            mla0 = mla1;
            mua0 = mua1;
            Ra0 = Ra1;
            Aa0 = Aa1;

            ia1++;
            ier = getPoint(ia1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                kgmax1, kgmin1, kbarmax1, kbarmin1);
            if( ier != 0 ) return MC_ERROR;

            if( areaWt != 0 ) {
                kg1      *= area1;
                kbar1    *= area1;
                kgSD1    *= area1;
                kbarSD1  *= area1;
                kgmax1   *= area1;
                kgmin1   *= area1;
                kbarmax1 *= area1;
                kbarmin1 *= area1;
            }
            Ra1 = radius1;
            Aa1 = area1;

            switch(statistic) {
            case 0:   // Avg
                gla1 = kg1;
                mla1 = kbar1;
                break;
            case 1:   // Min
                gla1 = kgmin1;
                mla1 = kbarmin1;
                break;
            case 2:   // Max
                gua1 = kgmax1;
                mua1 = kbarmax1;
                break;
            case 3:   // MinMax
                gla1 = kgmin1;
                gua1 = kgmax1;
                mla1 = kbarmin1;
                mua1 = kbarmax1;
                break;
            case 4:   // StdDev
                gla1 = kgSD1;
                mla1 = kbarSD1;
                break;
            default:
                return MC_ERROR;
            }

            if( metric == 3 ) {   // Mod
                gla1 = (gla1<0.0) ? -sqrt(-gla1) : sqrt(gla1);
                gua1 = (gua1<0.0) ? -sqrt(-gua1) : sqrt(gua1);
            }
            if( function == 1 ) {   // Log
                gla1 = (gla1<0.0) ? -log(1.0-gla1) : log(1.0+gla1);
                gua1 = (gua1<0.0) ? -log(1.0-gua1) : log(1.0+gua1);
                mla1 = (mla1<0.0) ? -log(1.0-mla1) : log(1.0+mla1);
                mua1 = (mua1<0.0) ? -log(1.0-mua1) : log(1.0+mua1);
            }
        }

        // Update data for the next ring interval in Distribution B
        if( ib0 == ib1 ) {
            glb0 = glb1;
            gub0 = gub1;
            mlb0 = mlb1;
            mub0 = mub1;
            Rb0 = Rb1;
            Ab0 = Ab1;

            ib1++;
            ier = dist.getPoint(ib1, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                     kgmax2, kgmin2, kbarmax2, kbarmin2);
            if( ier != 0 ) return MC_ERROR;

            if( areaWt != 0 ) {
                kg2      *= area2;
                kbar2    *= area2;
                kgSD2    *= area2;
                kbarSD2  *= area2;
                kgmax2   *= area2;
                kgmin2   *= area2;
                kbarmax2 *= area2;
                kbarmin2 *= area2;
            }
            Rb1 = radius2;
            Ab1 = area2;

            switch(statistic) {
            case 0:   // Avg
                glb1 = kg2;
                mlb1 = kbar2;
                break;
            case 1:   // Min
                glb1 = kgmin2;
                mlb1 = kbarmin2;
                break;
            case 2:   // Max
                gub1 = kgmax2;
                mub1 = kbarmax2;
                break;
            case 3:   // MinMax
                glb1 = kgmin2;
                gub1 = kgmax2;
                mlb1 = kbarmin2;
                mub1 = kbarmax2;
                break;
            case 4:   // StdDev
                glb1 = kgSD2;
                mlb1 = kbarSD2;
                break;
            default:
                return MC_ERROR;
            }

            if( metric == 3 ) {   // Mod
                glb1 = (glb1<0.0) ? -sqrt(-glb1) : sqrt(glb1);
                gub1 = (gub1<0.0) ? -sqrt(-gub1) : sqrt(gub1);
            }
            if( function == 1 ) {   // Log
                glb1 = (glb1<0.0) ? -log(1.0-glb1) : log(1.0+glb1);
                gub1 = (gub1<0.0) ? -log(1.0-gub1) : log(1.0+gub1);
                mlb1 = (mlb1<0.0) ? -log(1.0-mlb1) : log(1.0+mlb1);
                mub1 = (mub1<0.0) ? -log(1.0-mub1) : log(1.0+mub1);
            }
        }

        // Compute R0, R1
        R0 = R1;
        if( Ra1 > R0 && Ra1 < Rb1 ) {
            R1 = Ra1;
        } else {
            R1 = Rb1;
        }

        // Compute Fa(R0), Fa(R1)
        u0 = (R0 - Ra0) / (Ra1 - Ra0);
        Fgla0 = (1.0-u0)*gla0 + u0*gla1;
        Fgua0 = (1.0-u0)*gua0 + u0*gua1;
        Fmla0 = (1.0-u0)*mla0 + u0*mla1;
        Fmua0 = (1.0-u0)*mua0 + u0*mua1;

        u1 = (R1 - Ra0) / (Ra1 - Ra0);
        Fgla1 = (1.0-u1)*gla0 + u1*gla1;
        Fgua1 = (1.0-u1)*gua0 + u1*gua1;
        Fmla1 = (1.0-u1)*mla0 + u1*mla1;
        Fmua1 = (1.0-u1)*mua0 + u1*mua1;

        // Compute Fb(R0), Fb(R1)
        v0 = (R0 - Rb0) / (Rb1 - Rb0);
        Fglb0 = (1.0-v0)*glb0 + v0*glb1;
        Fgub0 = (1.0-v0)*gub0 + v0*gub1;
        Fmlb0 = (1.0-v0)*mlb0 + v0*mlb1;
        Fmub0 = (1.0-v0)*mub0 + v0*mub1;

        v1 = (R1 - Rb0) / (Rb1 - Rb0);
        Fglb1 = (1.0-v1)*glb0 + v1*glb1;
        Fgub1 = (1.0-v1)*gub0 + v1*gub1;
        Fmlb1 = (1.0-v1)*mlb0 + v1*mlb1;
        Fmub1 = (1.0-v1)*mub0 + v1*mub1;

        // Compute area under Curve A
        Fgla = 0.5*(Fgla0+Fgla1) * (R1-R0);
        Fgua = 0.5*(Fgua0+Fgua1) * (R1-R0);
        Fmla = 0.5*(Fmla0+Fmla1) * (R1-R0);
        Fmua = 0.5*(Fmua0+Fmua1) * (R1-R0);

        // Compute area under Curve B
        Fglb = 0.5*(Fglb0+Fglb1) * (R1-R0);
        Fgub = 0.5*(Fgub0+Fgub1) * (R1-R0);
        Fmlb = 0.5*(Fmlb0+Fmlb1) * (R1-R0);
        Fmub = 0.5*(Fmub0+Fmub1) * (R1-R0);

        // Compute surface area in current interval
        Area = pi*(R1*R1 - R0*R0);

        // Compute cumulative area
        Acum += Area;

        // Compute delta area
        switch(metric) {
        case 0:   // Gauss
            if(statistic != 2) {   // All but Max
                //delta = (Fglb - Fgla)*Area;
                delta = Fglb - Fgla;
                sum += (delta < 0.0) ? -delta : delta;
            }
            if(statistic == 2 || statistic == 3) {   // Max or MinMax
                //delta = (Fgub - Fgua)*Area;
                delta = Fgub - Fgua;
                sum += (delta < 0.0) ? -delta : delta;
            }
            break;
        case 1:   // Mean
            if(statistic != 2) {   // All but Max
                //delta = (Fmlb - Fmla)*Area;
                delta = Fmlb - Fmla;
                sum += (delta < 0.0) ? -delta : delta;
            }
            if(statistic == 2 || statistic == 3) {   // Max or MinMax
                //delta = (Fmub - Fmua)*Area;
                delta = Fmub - Fmua;
                sum += (delta < 0.0) ? -delta : delta;
            }
            break;
        case 2:   // Both
        case 3:   // Mod
            if(statistic != 2) {   // All but Max
                //delta = (Fglb - Fgla)*Area;
                delta = Fglb - Fgla;
                sum += (delta < 0.0) ? -delta : delta;
                //delta = (Fmlb - Fmla)*Area;
                delta = Fmlb - Fmla;
                sum += (delta < 0.0) ? -delta : delta;
            }
            if(statistic == 2 || statistic == 3) {   // Max or MinMax
                //delta = (Fgub - Fgua)*Area;
                delta = Fgub - Fgua;
                sum += (delta < 0.0) ? -delta : delta;
                //delta = (Fmub - Fmua)*Area;
                delta = Fmub - Fmua;
                sum += (delta < 0.0) ? -delta : delta;
            }
            break;
        default:
            break;
        }

        // Now advance to next region
        if( R1 >= Ra1 ) ia0 = ia1;
        if( R1 >= Rb1 ) ib0 = ib1;
    }

    // Divide by total area
    //value = sum / Acum;
    value = sum / R1;
    if( areaWt != 0 ) value /= Acum;

    return value;
}

double MCDistribution::Compare(const MCDistribution &dist, 
                               MC_MapMetric method, 
                               const double Rcomp,
                               const int areaWt) const
{
    int ier, metric, statistic, function, isLog, extra;
    int ia, ib, na, nb, count;
    double kg, kbar, kgSD, kbarSD, area, radius, r, pi;
    double kgmax, kgmin, kbarmax, kbarmin, sum, Acum, value;
	double gcA0, mcA0, gxA0, mxA0, rA0;
    double gcA1, mcA1, gxA1, mxA1, rA1;
    double gcA2, mcA2, gxA2, mxA2;
    double gcB0, mcB0, gxB0, mxB0, rB0;
    double gcB1, mcB1, gxB1, mxB1, rB1;
    double gcB2, mcB2, gxB2, mxB2;

    //double gla1, glb1, gua1, gub1, mla1, mlb1, mua1, mub1;
    //double gla0, glb0, gua0, gub0, mla0, mlb0, mua0, mub0;
    //double u0, u1, v0, v1, Aa0, Aa1, Ab0, Ab1, Area, Acum;
    //double Fgla0, Fgla1, Fgua0, Fgua1, Fmla0, Fmla1, Fmua0, Fmua1;
    //double Fglb0, Fglb1, Fgub0, Fgub1, Fmlb0, Fmlb1, Fmub0, Fmub1;
    //double Fgla, Fgua, Fglb, Fgub, Fmla, Fmua, Fmlb, Fmub;
    //double R0, R1, Ra0, Ra1, Rb0, Rb1, pi;

	na = Size();
	nb = dist.Size();
	if( na < 1 || nb < 1 ) return MC_ERROR;

	if( na < 2 || nb < 2 ) {
		return Compare(dist, method, 1, areaWt);
	}

    Decompose(method, metric, statistic, function);
	isLog = function;

	extra = 0;
	if( statistic == 3 ) extra = 1;

    pi = 4.0*atan(1.0);

    sum = 0.0;
    Acum = 0.0;

	// Get the first point of Distribution A

    ier = getPoint(0, kg, kbar, kgSD, kbarSD, area, radius, 
                      kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcA0, mcA0, gxA0, mxA0, rA0);
    if( ier != 0 ) return MC_ERROR;

	// Get the first point of Distribution B

    ier = dist.getPoint(0, kg, kbar, kgSD, kbarSD, area, radius, 
                           kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcB0, mcB0, gxB0, mxB0, rB0);
    if( ier != 0 ) return MC_ERROR;

	// Get the next point of Distribution A

	ia = 1;
    ier = getPoint(ia, kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcA1, mcA1, gxA1, mxA1, rA1);
    if( ier != 0 ) return MC_ERROR;

	// Get the next point of Distribution B

	ib = 1;
    ier = dist.getPoint(ib, kg, kbar, kgSD, kbarSD, area, radius, 
                            kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcB1, mcB1, gxB1, mxB1, rB1);
    if( ier != 0 ) return MC_ERROR;

	while(1)
	{
		// Set integration range
		if( rA1 < rB1 ) {
			r = rA1;
		} else {
			r = rB1;
		}
		if( r > Rcomp ) r = Rcomp;

		// Interpolate new end points
		if( rA1 > r ) {
			InterpolatePoint(extra, rA0, gcA0, mcA0, gxA0, mxA0,
				                    rA1, gcA1, mcA1, gxA1, mxA1,
									  r, gcA2, mcA2, gxA2, mxA2);
		} else {
			gcA2 = gcA1;
			mcA2 = mcA1;
			gxA2 = gxA1;
			mxA2 = mxA1;
		}

		if( rB1 > r ) {
			InterpolatePoint(extra, rB0, gcB0, mcB0, gxA0, mxB0,
				                    rB1, gcB1, mcB1, gxB1, mxB1,
									  r, gcB2, mcB2, gxB2, mxB2);
		} else {
			gcB2 = gcB1;
			mcB2 = mcB1;
			gxB2 = gxB1;
			mxB2 = mxB1;
		}

		// Integrate to get the area between the curves
		sum = Integrate(extra, metric, rA0, r, 
			            gcA0, mcA0, gxA0, mxA0,
			            gcA2, mcA2, gxA2, mxA2,
			            gcB0, mcB0, gxB0, mxB0,
			            gcB2, mcB2, gxB2, mxB2);
		Acum += sum;

		// Check for termination conditions
		if( r == Rcomp ) break;

		// Move to the next segment
		count = 0;
		gcA0 = gcA2;
		mcA0 = mcA2;
		gxA0 = gxA2;
		mxA0 = mxA2;
		rA0  = r;
		if( rA1 <= r ) {
			count++;
			ia++;
			if( ia >= na ) break;

			ier = getPoint(ia, kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin);
			if( ier != 0 ) return MC_ERROR;

			ier = ProcessPoint(metric, statistic, isLog, areaWt,
							   kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin, 
							   gcA1, mcA1, gxA1, mxA1, rA1);
			if( ier != 0 ) return MC_ERROR;
		}

		gcB0 = gcB2;
		mcB0 = mcB2;
		gxB0 = gxB2;
		mxB0 = mxB2;
		rB0  = r;
		if( rB1 <= r ) {
			count++;
			ib++;
			if( ib >= nb ) break;

			ier = dist.getPoint(ib, kg, kbar, kgSD, kbarSD, area, radius, 
									kgmax, kbarmax, kgmin, kbarmin);
			if( ier != 0 ) return MC_ERROR;

			ier = ProcessPoint(metric, statistic, isLog, areaWt,
							   kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin, 
							   gcB1, mcB1, gxB1, mxB1, rB1);
			if( ier != 0 ) return MC_ERROR;
		}
		if( count == 0 ) {
			printf("ERROR: No increment on either distribution\n");
			return MC_ERROR;
		}
	}

	// Set the return value
    value = Acum;

    // Divide by total area
    if( areaWt ) value /= (pi*r*r);

    return value;
}

double MCDistribution::Compare(const MCDistribution &dist, 
                               MC_MapMetric method, 
                               const double Rcomp,
                               const double scale,
                               const int areaWt) const
{
    int ier, metric, statistic, function, isLog, extra;
    int ia, ib, na, nb, count;
    double kg, kbar, kgSD, kbarSD, area, radius, r, pi;
    double kgmax, kgmin, kbarmax, kbarmin, sum, Acum, value;
	double gcA0, mcA0, gxA0, mxA0, rA0;
    double gcA1, mcA1, gxA1, mxA1, rA1;
    double gcA2, mcA2, gxA2, mxA2;
    double gcB0, mcB0, gxB0, mxB0, rB0;
    double gcB1, mcB1, gxB1, mxB1, rB1;
    double gcB2, mcB2, gxB2, mxB2;

    na = Size();
	nb = dist.Size();
	if( na < 1 || nb < 1 ) return MC_ERROR;

	if( scale == 0.0 ) return MC_ERROR;
	double KgScale = 1.0 / (scale*scale);
	double KbarScale = 1.0 / scale;
	double areaScale = scale*scale;
	double radScale = scale;

	if( na < 2 || nb < 2 ) {
		return Compare(dist, method, 1, areaWt);
	}

    Decompose(method, metric, statistic, function);
	isLog = function;

	extra = 0;
	if( statistic == 3 ) extra = 1;

    pi = 4.0*atan(1.0);

    sum = 0.0;
    Acum = 0.0;

	// Get the first point of Distribution A

    ier = getPoint(0, kg, kbar, kgSD, kbarSD, area, radius, 
                      kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcA0, mcA0, gxA0, mxA0, rA0);
    if( ier != 0 ) return MC_ERROR;

	// Get the first point of Distribution B

    ier = dist.getPoint(0, kg, kbar, kgSD, kbarSD, area, radius, 
                           kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	// Scale the point from Distribution B
	kg      *= KgScale;
	kbar    *= KbarScale;
	kgSD    *= KgScale;
	kbarSD  *= KbarScale;
	kgmax   *= KgScale;
	kbarmax *= KbarScale;
	kgmin   *= KgScale;
	kbarmin *= KbarScale;
	area    *= areaScale;
	radius  *= radScale;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcB0, mcB0, gxB0, mxB0, rB0);
    if( ier != 0 ) return MC_ERROR;

	// Get the next point of Distribution A

	ia = 1;
    ier = getPoint(ia, kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcA1, mcA1, gxA1, mxA1, rA1);
    if( ier != 0 ) return MC_ERROR;

	// Get the next point of Distribution B

	ib = 1;
    ier = dist.getPoint(ib, kg, kbar, kgSD, kbarSD, area, radius, 
                            kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return MC_ERROR;

	// Scale the point from Distribution B
	kg      *= KgScale;
	kbar    *= KbarScale;
	kgSD    *= KgScale;
	kbarSD  *= KbarScale;
	kgmax   *= KgScale;
	kbarmax *= KbarScale;
	kgmin   *= KgScale;
	kbarmin *= KbarScale;
	area    *= areaScale;
	radius  *= radScale;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcB1, mcB1, gxB1, mxB1, rB1);
    if( ier != 0 ) return MC_ERROR;

	while(1)
	{
		// Set integration range
		if( rA1 < rB1 ) {
			r = rA1;
		} else {
			r = rB1;
		}
		if( r > Rcomp ) r = Rcomp;

		// Interpolate new end points
		if( rA1 > r ) {
			InterpolatePoint(extra, rA0, gcA0, mcA0, gxA0, mxA0,
				                    rA1, gcA1, mcA1, gxA1, mxA1,
									  r, gcA2, mcA2, gxA2, mxA2);
		} else {
			gcA2 = gcA1;
			mcA2 = mcA1;
			gxA2 = gxA1;
			mxA2 = mxA1;
		}

		if( rB1 > r ) {
			InterpolatePoint(extra, rB0, gcB0, mcB0, gxA0, mxB0,
				                    rB1, gcB1, mcB1, gxB1, mxB1,
									  r, gcB2, mcB2, gxB2, mxB2);
		} else {
			gcB2 = gcB1;
			mcB2 = mcB1;
			gxB2 = gxB1;
			mxB2 = mxB1;
		}

		// Integrate to get the area between the curves
		sum = Integrate(extra, metric, rA0, r, 
			            gcA0, mcA0, gxA0, mxA0,
			            gcA2, mcA2, gxA2, mxA2,
			            gcB0, mcB0, gxB0, mxB0,
			            gcB2, mcB2, gxB2, mxB2);
		Acum += sum;

		// Check for termination conditions
		if( r == Rcomp ) break;

		// Move to the next segment
		count = 0;
		gcA0 = gcA2;
		mcA0 = mcA2;
		gxA0 = gxA2;
		mxA0 = mxA2;
		rA0  = r;
		if( rA1 <= r ) {
			count++;
			ia++;
			if( ia >= na ) break;

			ier = getPoint(ia, kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin);
			if( ier != 0 ) return MC_ERROR;

			ier = ProcessPoint(metric, statistic, isLog, areaWt,
							   kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin, 
							   gcA1, mcA1, gxA1, mxA1, rA1);
			if( ier != 0 ) return MC_ERROR;
		}

		gcB0 = gcB2;
		mcB0 = mcB2;
		gxB0 = gxB2;
		mxB0 = mxB2;
		rB0  = r;
		if( rB1 <= r ) {
			count++;
			ib++;
			if( ib >= nb ) break;

			ier = dist.getPoint(ib, kg, kbar, kgSD, kbarSD, area, radius, 
									kgmax, kbarmax, kgmin, kbarmin);
			if( ier != 0 ) return MC_ERROR;

			// Scale the point from Distribution B
			kg      *= KgScale;
			kbar    *= KbarScale;
			kgSD    *= KgScale;
			kbarSD  *= KbarScale;
			kgmax   *= KgScale;
			kbarmax *= KbarScale;
			kgmin   *= KgScale;
			kbarmin *= KbarScale;
			area    *= areaScale;
			radius  *= radScale;

			ier = ProcessPoint(metric, statistic, isLog, areaWt,
							   kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin, 
							   gcB1, mcB1, gxB1, mxB1, rB1);
			if( ier != 0 ) return MC_ERROR;
		}
		if( count == 0 ) {
			printf("ERROR: No increment on either distribution\n");
			return MC_ERROR;
		}
	}

	// Set the return value
    value = Acum;

    // Divide by total area
    if( areaWt ) value /= (pi*r*r);

    return value;
}

int MCDistribution::Integrate(const double Rcomp,
                              MC_MapMetric method, 
                              const int areaWt,
							  double &sumGauss,
							  double &sumMean) const
{
    int ier, metric, statistic, function, isLog, extra;
    int ia, na, count;
    double kg, kbar, kgSD, kbarSD, area, radius, r, pi;
    double kgmax, kgmin, kbarmax, kbarmin, kGauss, kMean;
	double gcA0, mcA0, gxA0, mxA0, rA0;
    double gcA1, mcA1, gxA1, mxA1, rA1;
    double gcA2, mcA2, gxA2, mxA2;

    na = Size();
	if( na < 2 ) return -1;

    Decompose(method, metric, statistic, function);
	isLog = function;

	extra = 0;
	if( statistic == 3 ) extra = 1;

    pi = 4.0*atan(1.0);

    sumGauss = 0.0;
    sumMean = 0.0;
    //Acum = 0.0;

	// Get the first point of Distribution A

    ier = getPoint(0, kg, kbar, kgSD, kbarSD, area, radius, 
                      kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return ier;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcA2, mcA2, gxA2, mxA2, r);
    if( ier != 0 ) return ier;

	ia = 0;

	while(1)
	{
		// Move to the next segment
		count = 0;
		gcA0 = gcA2;
		mcA0 = mcA2;
		gxA0 = gxA2;
		mxA0 = mxA2;
		rA0  = r;

		ia++;
		if( ia >= na ) break;

		ier = getPoint(ia, kg, kbar, kgSD, kbarSD, area, radius, 
						   kgmax, kbarmax, kgmin, kbarmin);
		if( ier != 0 ) return ier;

		ier = ProcessPoint(metric, statistic, isLog, areaWt,
						   kg, kbar, kgSD, kbarSD, area, radius, 
						   kgmax, kbarmax, kgmin, kbarmin, 
						   gcA1, mcA1, gxA1, mxA1, rA1);
		if( ier != 0 ) return ier;

		r = rA1;
		if( r > Rcomp ) r = Rcomp;

		// Interpolate new end points
		if( rA1 > r ) {
			InterpolatePoint(extra, rA0, gcA0, mcA0, gxA0, mxA0,
				                    rA1, gcA1, mcA1, gxA1, mxA1,
									  r, gcA2, mcA2, gxA2, mxA2);
		} else {
			gcA2 = gcA1;
			mcA2 = mcA1;
			gxA2 = gxA1;
			mxA2 = mxA1;
		}

		// Integrate the area under the curve
		ier = Integrate(extra, rA0, r, 
			            gcA0, mcA0, gxA0, mxA0,
			            gcA2, mcA2, gxA2, mxA2,
			            kGauss, kMean);

		sumGauss += kGauss;
		sumMean += kMean;

		//Acum += sum;

		// Check for termination conditions
		if( r == Rcomp ) break;
	}

    // Divide by total area
	if( areaWt ) {
		sumGauss /= (pi*r*r);
		sumMean /= (pi*r*r);
	}

    return 0;
}

int MCDistribution::Delta(const MCDistribution &dist, 
                          MC_MapMetric method, 
                          const double Rcomp,
                          const int areaWt,
						  double &deltaKgauss,
						  double &deltaKmean) const
{
    int ier, metric, statistic, function, isLog, extra;
    int ia, ib, na, nb, count;
    double kg, kbar, kgSD, kbarSD, area, radius, r, pi;
    double kgmax, kgmin, kbarmax, kbarmin, dkg, dkbar;
	double gcA0, mcA0, gxA0, mxA0, rA0;
    double gcA1, mcA1, gxA1, mxA1, rA1;
    double gcA2, mcA2, gxA2, mxA2;
    double gcB0, mcB0, gxB0, mxB0, rB0;
    double gcB1, mcB1, gxB1, mxB1, rB1;
    double gcB2, mcB2, gxB2, mxB2;

	na = Size();
	nb = dist.Size();
	if( na < 1 || nb < 1 ) return -1;

	if( na < 2 || nb < 2 ) return -1;

    Decompose(method, metric, statistic, function);
	isLog = function;

	extra = 0;
	if( statistic == 3 ) extra = 1;

    pi = 4.0*atan(1.0);

    deltaKgauss = 0.0;
    deltaKmean = 0.0;

	// Get the first point of Distribution A

    ier = getPoint(0, kg, kbar, kgSD, kbarSD, area, radius, 
                      kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return ier;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcA0, mcA0, gxA0, mxA0, rA0);
    if( ier != 0 ) return ier;

	// Get the first point of Distribution B

    ier = dist.getPoint(0, kg, kbar, kgSD, kbarSD, area, radius, 
                           kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return ier;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcB0, mcB0, gxB0, mxB0, rB0);
    if( ier != 0 ) return ier;

	// Get the next point of Distribution A

	ia = 1;
    ier = getPoint(ia, kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return ier;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcA1, mcA1, gxA1, mxA1, rA1);
    if( ier != 0 ) return ier;

	// Get the next point of Distribution B

	ib = 1;
    ier = dist.getPoint(ib, kg, kbar, kgSD, kbarSD, area, radius, 
                            kgmax, kbarmax, kgmin, kbarmin);
    if( ier != 0 ) return ier;

	ier = ProcessPoint(metric, statistic, isLog, areaWt,
		               kg, kbar, kgSD, kbarSD, area, radius, 
                       kgmax, kbarmax, kgmin, kbarmin, 
				       gcB1, mcB1, gxB1, mxB1, rB1);
    if( ier != 0 ) return ier;

	while(1)
	{
		// Set integration range
		if( rA1 < rB1 ) {
			r = rA1;
		} else {
			r = rB1;
		}
		if( r > Rcomp ) r = Rcomp;

		// Interpolate new end points
		if( rA1 > r ) {
			InterpolatePoint(extra, rA0, gcA0, mcA0, gxA0, mxA0,
				                    rA1, gcA1, mcA1, gxA1, mxA1,
									  r, gcA2, mcA2, gxA2, mxA2);
		} else {
			gcA2 = gcA1;
			mcA2 = mcA1;
			gxA2 = gxA1;
			mxA2 = mxA1;
		}

		if( rB1 > r ) {
			InterpolatePoint(extra, rB0, gcB0, mcB0, gxA0, mxB0,
				                    rB1, gcB1, mcB1, gxB1, mxB1,
									  r, gcB2, mcB2, gxB2, mxB2);
		} else {
			gcB2 = gcB1;
			mcB2 = mcB1;
			gxB2 = gxB1;
			mxB2 = mxB1;
		}

		// Integrate to get the area between the curves
		ier = Difference(extra, rA0, r, 
			             gcA0, mcA0, gxA0, mxA0,
			             gcA2, mcA2, gxA2, mxA2,
			             gcB0, mcB0, gxB0, mxB0,
			             gcB2, mcB2, gxB2, mxB2,
						 dkg, dkbar);
		deltaKgauss += dkg;
		deltaKmean += dkbar;

		// Check for termination conditions
		if( r == Rcomp ) break;

		// Move to the next segment
		count = 0;
		gcA0 = gcA2;
		mcA0 = mcA2;
		gxA0 = gxA2;
		mxA0 = mxA2;
		rA0  = r;
		if( rA1 <= r ) {
			count++;
			ia++;
			if( ia >= na ) break;

			ier = getPoint(ia, kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin);
			if( ier != 0 ) return ier;

			ier = ProcessPoint(metric, statistic, isLog, areaWt,
							   kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin, 
							   gcA1, mcA1, gxA1, mxA1, rA1);
			if( ier != 0 ) return ier;
		}

		gcB0 = gcB2;
		mcB0 = mcB2;
		gxB0 = gxB2;
		mxB0 = mxB2;
		rB0  = r;
		if( rB1 <= r ) {
			count++;
			ib++;
			if( ib >= nb ) break;

			ier = dist.getPoint(ib, kg, kbar, kgSD, kbarSD, area, radius, 
									kgmax, kbarmax, kgmin, kbarmin);
			if( ier != 0 ) return ier;

			ier = ProcessPoint(metric, statistic, isLog, areaWt,
							   kg, kbar, kgSD, kbarSD, area, radius, 
							   kgmax, kbarmax, kgmin, kbarmin, 
							   gcB1, mcB1, gxB1, mxB1, rB1);
			if( ier != 0 ) return ier;
		}
		if( count == 0 ) {
			printf("ERROR: No increment on either distribution\n");
			return -1;
		}
	}

	// Divide by total area
    if( areaWt ) {
		deltaKgauss /= (pi*r*r);
		deltaKmean /= (pi*r*r);
	}

    return 0;
}

int MCDistribution::GetScale(const MCDistribution &dist, 
                             MC_MapMetric method, 
                             const int nRing,
                             const int areaWt,
                             const int type,
                             float &alphaG, float &alphaM, 
                             float &offsetG, float &offsetM) const
{
    int ier, i, metric, statistic, function, size1, size2;
    double kg1, kbar1, kgSD1, kbarSD1, area1, radius1;
    double kgmax1, kgmin1, kbarmax1, kbarmin1;
    double Xa0, Xa1, Yga0, Yga1, Yma0, Yma1, Yga, Yma;
    double Xb0, Xb1, Ygb0, Ygb1, Ymb0, Ymb1, Ygb, Ymb;
    double Rref, AgaSum, AmaSum, AgbSum, AmbSum;
    double t, last_kg1, last_kbar1, last_rad1;

    alphaG = 1.0;
    alphaM = 1.0;
    offsetG = 0.0;
    offsetM = 0.0;

    Decompose(method, metric, statistic, function);

    // Compute the maximum radius

    size1 = nRing;
    if( Size() < size1 ) size1 = Size();
    if( size1 < 2 ) return -1;

    size2 = nRing;
    if( dist.Size() < size2 ) size2 = dist.Size();
    if( size2 < 2 ) return -1;

    ier = getPoint(size1-1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                   kgmax1, kgmin1, kbarmax1, kbarmin1);

    Rref = radius1;

    ier = dist.getPoint(size2-1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                        kgmax1, kgmin1, kbarmax1, kbarmin1);

    if( radius1 < Rref ) Rref = radius1;

    // Compute range for first distribution

    for( i=0; i<size1; i++ ) {
        ier = getPoint(i, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                       kgmax1, kgmin1, kbarmax1, kbarmin1);
        if( i == 0 ) {
            Yga0 = kg1;
            Yga1 = kg1;
            Yma0 = kbar1;
            Yma1 = kbar1;
            last_kg1   = kg1;
            last_kbar1 = kbar1;
            last_rad1  = radius1;
            AgaSum = 0.0;
            AmaSum = 0.0;
        } else {
            if( radius1 < Rref ) {
                AgaSum += (radius1-last_rad1)*0.5*(kg1+last_kg1);
                AmaSum += (radius1-last_rad1)*0.5*(kbar1+last_kbar1);
                last_kg1   = kg1;
                last_kbar1 = kbar1;
                last_rad1  = radius1;

                if( kg1   < Yga0 ) Yga0 = kg1;
                if( kg1   > Yga1 ) Yga1 = kg1;
                if( kbar1 < Yma0 ) Yma0 = kbar1;
                if( kbar1 > Yma1 ) Yma1 = kbar1;
            } else {
                t = (Rref-last_rad1)/(radius1-last_rad1);
                kg1 = t*kg1 + (1.0-t)*last_kg1;
                kbar1 = t*kbar1 + (1.0-t)*last_kbar1;
                radius1 = t*radius1 + (1.0-t)*last_rad1;

                AgaSum += (radius1-last_rad1)*0.5*(kg1+last_kg1);
                AmaSum += (radius1-last_rad1)*0.5*(kbar1+last_kbar1);

                if( kg1   < Yga0 ) Yga0 = kg1;
                if( kg1   > Yga1 ) Yga1 = kg1;
                if( kbar1 < Yma0 ) Yma0 = kbar1;
                if( kbar1 > Yma1 ) Yma1 = kbar1;
                break;
            }
        }
    }
    Xa0 = 0.0;
    Xa1 = Rref;

    Yga = (Yga1 > -Yga0) ? Yga1 : -Yga0;
    Yma = (Yma1 > -Yma0) ? Yma1 : -Yma0;

    // Compute range for second distribution

    for( i=0; i<size2; i++ ) {
        ier = dist.getPoint(i, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                            kgmax1, kgmin1, kbarmax1, kbarmin1);
        if( i == 0 ) {
            Ygb0 = kg1;
            Ygb1 = kg1;
            Ymb0 = kbar1;
            Ymb1 = kbar1;
            last_kg1   = kg1;
            last_kbar1 = kbar1;
            last_rad1  = radius1;
            AgbSum = 0.0;
            AmbSum = 0.0;
        } else {
            if( radius1 < Rref ) {
                AgbSum += (radius1-last_rad1)*0.5*(kg1+last_kg1);
                AmbSum += (radius1-last_rad1)*0.5*(kbar1+last_kbar1);
                last_kg1   = kg1;
                last_kbar1 = kbar1;
                last_rad1  = radius1;

                if( kg1   < Ygb0 ) Ygb0 = kg1;
                if( kg1   > Ygb1 ) Ygb1 = kg1;
                if( kbar1 < Ymb0 ) Ymb0 = kbar1;
                if( kbar1 > Ymb1 ) Ymb1 = kbar1;
            } else {
                t = (Rref-last_rad1)/(radius1-last_rad1);
                kg1 = t*kg1 + (1.0-t)*last_kg1;
                kbar1 = t*kbar1 + (1.0-t)*last_kbar1;
                radius1 = t*radius1 + (1.0-t)*last_rad1;

                AgbSum += (radius1-last_rad1)*0.5*(kg1+last_kg1);
                AmbSum += (radius1-last_rad1)*0.5*(kbar1+last_kbar1);

                if( kg1   < Ygb0 ) Ygb0 = kg1;
                if( kg1   > Ygb1 ) Ygb1 = kg1;
                if( kbar1 < Ymb0 ) Ymb0 = kbar1;
                if( kbar1 > Ymb1 ) Ymb1 = kbar1;
                break;
            }
        }
    }
    Xb0 = 0.0;
    Xb1 = Rref;

    Ygb = (Ygb1 > -Ygb0) ? Ygb1 : -Ygb0;
    Ymb = (Ymb1 > -Ymb0) ? Ymb1 : -Ymb0;

    switch(type) {
    case 1:
        if( Ygb == 0.0 ) {
            alphaG = 1.0f;
        } else {
            alphaG = (float) sqrt(Yga/Ygb);
        }
        if( Ymb == 0.0 ) {
            alphaM = 1.0f;
        } else {
            alphaM = (float) (Yma/Ymb);
        }
        break;
    case 2:
        if( Ygb1 == Ygb0 ) {
            alphaG = 1.0f;
        } else {
            alphaG = (float) sqrt((Yga1 - Yga0)/(Ygb1 - Ygb0));
        }
        if( Ymb1 == Ymb0 ) {
            alphaM = 1.0f;
        } else {
            alphaM = (float) ((Yma1 - Yma0)/(Ymb1 - Ymb0));
        }
        break;
    default:
        alphaG = 1.0f;
        alphaM = 1.0f;
        break;
    }

    if( Rref > 0.0 ) {
        offsetG = (float) ((AgaSum - AgbSum*alphaG*alphaG) / Rref);
        offsetM = (float) ((AmaSum - AmbSum*alphaM) / Rref);
    }

    return 0;
}

double MCDistribution::CompareScale(const MCDistribution &dist, 
                                    MC_MapMetric method, 
                                    const int maxRings,
                                    const int areaWt,
                                    const int scaleType,
                                    const int scaleX,
                                    const int offset,
                                    float &alphaG, float &alphaM, 
                                    float &offsetG, float &offsetM) const
{
    int ier, nRing, metric, statistic, function;
    int ia0, ia1, ib0, ib1;
    double kg1, kg2, kbar1, kbar2, kgSD1, kgSD2, kbarSD1, kbarSD2, 
           area1, area2, radius1, radius2;
    double kgmax1, kgmax2, kgmin1, kgmin2, kbarmax1, kbarmax2, 
           kbarmin1, kbarmin2, sum, delta, value;
    double gla1, glb1, gua1, gub1, mla1, mlb1, mua1, mub1;
    double gla0, glb0, gua0, gub0, mla0, mlb0, mua0, mub0;
    double u0, u1, v0, v1, Aa0, Aa1, Ab0, Ab1, Area, Acum;
    double Fgla0, Fgla1, Fgua0, Fgua1, Fmla0, Fmla1, Fmua0, Fmua1;
    double Fglb0, Fglb1, Fgub0, Fgub1, Fmlb0, Fmlb1, Fmub0, Fmub1;
    double Fgla, Fgua, Fglb, Fgub, Fmla, Fmua, Fmlb, Fmub;
    double R0, R1, Ra0, Ra1, Rb0, Rb1, pi, alphaGsq;

    nRing = maxRings;
    if( Size() < nRing ) nRing = Size();
    if( dist.Size() < nRing ) nRing = dist.Size();
    if( nRing < 1 ) return 0.0;

    if( nRing == 1 ) return Compare(dist, method, nRing, areaWt);

    Decompose(method, metric, statistic, function);

    pi = 4.0*atan(1.0);
    alphaGsq = alphaG*alphaG;

    gla1 = 0.0;
    glb1 = 0.0;
    gua1 = 0.0;
    gub1 = 0.0;
    mla1 = 0.0;
    mlb1 = 0.0;
    mua1 = 0.0;
    mub1 = 0.0;

    sum = 0.0;
    Acum = 0.0;
    ia0 = 0;
    ia1 = 0;
    ib0 = 0;
    ib1 = 0;
    ier = getPoint(ia0, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                        kgmax1, kgmin1, kbarmax1, kbarmin1);
    if( ier != 0 ) return MC_ERROR;

    if( areaWt != 0 ) {
        kg1      *= area1;
        kbar1    *= area1;
        kgSD1    *= area1;
        kbarSD1  *= area1;
        kgmax1   *= area1;
        kgmin1   *= area1;
        kbarmax1 *= area1;
        kbarmin1 *= area1;
    }

    ier = dist.getPoint(ib0, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                             kgmax2, kgmin2, kbarmax2, kbarmin2);
    if( ier != 0 ) return MC_ERROR;

    switch(scaleType) {
    case 1:
    case 2:
        kg2      *= alphaGsq;
        kbar2    *= alphaM;
        kgSD2    *= alphaGsq;
        kbarSD2  *= alphaM;
        kgmax2   *= alphaGsq;
        kbarmax2 *= alphaM;
        kgmin2   *= alphaGsq;
        kbarmin2 *= alphaM;
        break;
    default:
        break;
    }

    if( areaWt != 0 ) {
        kg2      *= area2;
        kbar2    *= area2;
        kgSD2    *= area2;
        kbarSD2  *= area2;
        kgmax2   *= area2;
        kgmin2   *= area2;
        kbarmax2 *= area2;
        kbarmin2 *= area2;
    }

    if( offset ) {
        kg2      += offsetG;
        kbar2    += offsetM;
        kgmax2   += offsetG;
        kbarmax2 += offsetM;
        kgmin2   += offsetG;
        kbarmin2 += offsetM;
    }

    Ra1 = radius1;
    Rb1 = radius2;
    Aa1 = area1;
    Ab1 = area2;

    switch(statistic) {
    case 0:   // Avg
        gla1 = kg1;
        glb1 = kg2;
        mla1 = kbar1;
        mlb1 = kbar2;
        break;
    case 1:   // Min
        gla1 = kgmin1;
        glb1 = kgmin2;
        mla1 = kbarmin1;
        mlb1 = kbarmin2;
        break;
    case 2:   // Max
        gua1 = kgmax1;
        gub1 = kgmax2;
        mua1 = kbarmax1;
        mub1 = kbarmax2;
        break;
    case 3:   // MinMax
        gla1 = kgmin1;
        glb1 = kgmin2;
        gua1 = kgmax1;
        gub1 = kgmax2;
        mla1 = kbarmin1;
        mlb1 = kbarmin2;
        mua1 = kbarmax1;
        mub1 = kbarmax2;
        break;
    case 4:   // StdDev
        gla1 = kgSD1;
        glb1 = kgSD2;
        mla1 = kbarSD1;
        mlb1 = kbarSD2;
        break;
    default:
        return MC_ERROR;
    }

    if( metric == 3 ) {   // Mod
        gla1 = (gla1<0.0) ? -sqrt(-gla1) : sqrt(gla1);
        glb1 = (glb1<0.0) ? -sqrt(-glb1) : sqrt(glb1);
        gua1 = (gua1<0.0) ? -sqrt(-gua1) : sqrt(gua1);
        gub1 = (gub1<0.0) ? -sqrt(-gub1) : sqrt(gub1);
    }
    if( function == 1 ) {   // Log
        gla1 = (gla1<0.0) ? -log(1.0-gla1) : log(1.0+gla1);
        glb1 = (glb1<0.0) ? -log(1.0-glb1) : log(1.0+glb1);
        gua1 = (gua1<0.0) ? -log(1.0-gua1) : log(1.0+gua1);
        gub1 = (gub1<0.0) ? -log(1.0-gub1) : log(1.0+gub1);
        mla1 = (mla1<0.0) ? -log(1.0-mla1) : log(1.0+mla1);
        mlb1 = (mlb1<0.0) ? -log(1.0-mlb1) : log(1.0+mlb1);
        mua1 = (mua1<0.0) ? -log(1.0-mua1) : log(1.0+mua1);
        mub1 = (mub1<0.0) ? -log(1.0-mub1) : log(1.0+mub1);
    }

    R1 = 0.0;

    while( ia0 < nRing-1 && ib0 < nRing-1 )
    {
        // Update data for the next ring interval in Distribution A
        if( ia0 == ia1 ) {
            gla0 = gla1;
            gua0 = gua1;
            mla0 = mla1;
            mua0 = mua1;
            Ra0 = Ra1;
            Aa0 = Aa1;

            ia1++;
            ier = getPoint(ia1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                kgmax1, kgmin1, kbarmax1, kbarmin1);
            if( ier != 0 ) return MC_ERROR;

            if( areaWt != 0 ) {
                kg1      *= area1;
                kbar1    *= area1;
                kgSD1    *= area1;
                kbarSD1  *= area1;
                kgmax1   *= area1;
                kgmin1   *= area1;
                kbarmax1 *= area1;
                kbarmin1 *= area1;
            }
            Ra1 = radius1;
            Aa1 = area1;

            switch(statistic) {
            case 0:   // Avg
                gla1 = kg1;
                mla1 = kbar1;
                break;
            case 1:   // Min
                gla1 = kgmin1;
                mla1 = kbarmin1;
                break;
            case 2:   // Max
                gua1 = kgmax1;
                mua1 = kbarmax1;
                break;
            case 3:   // MinMax
                gla1 = kgmin1;
                gua1 = kgmax1;
                mla1 = kbarmin1;
                mua1 = kbarmax1;
                break;
            case 4:   // StdDev
                gla1 = kgSD1;
                mla1 = kbarSD1;
                break;
            default:
                return MC_ERROR;
            }

            if( metric == 3 ) {   // Mod
                gla1 = (gla1<0.0) ? -sqrt(-gla1) : sqrt(gla1);
                gua1 = (gua1<0.0) ? -sqrt(-gua1) : sqrt(gua1);
            }
            if( function == 1 ) {   // Log
                gla1 = (gla1<0.0) ? -log(1.0-gla1) : log(1.0+gla1);
                gua1 = (gua1<0.0) ? -log(1.0-gua1) : log(1.0+gua1);
                mla1 = (mla1<0.0) ? -log(1.0-mla1) : log(1.0+mla1);
                mua1 = (mua1<0.0) ? -log(1.0-mua1) : log(1.0+mua1);
            }
        }

        // Update data for the next ring interval in Distribution B
        if( ib0 == ib1 ) {
            glb0 = glb1;
            gub0 = gub1;
            mlb0 = mlb1;
            mub0 = mub1;
            Rb0 = Rb1;
            Ab0 = Ab1;

            ib1++;
            ier = dist.getPoint(ib1, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                     kgmax2, kgmin2, kbarmax2, kbarmin2);
            if( ier != 0 ) return MC_ERROR;

            switch(scaleType) {
            case 1:
            case 2:
                kg2      *= alphaGsq;
                kbar2    *= alphaM;
                kgSD2    *= alphaGsq;
                kbarSD2  *= alphaM;
                kgmax2   *= alphaGsq;
                kbarmax2 *= alphaM;
                kgmin2   *= alphaGsq;
                kbarmin2 *= alphaM;
                break;
                /*
                kg2      = kg2      * alphaG*alphaG + offsetG;
                kbar2    = kbar2    * alphaM        + offsetM;
                kgSD2    = kgSD2    * alphaG*alphaG;
                kbarSD2  = kbarSD2  * alphaM;
                kgmax2   = kgmax2   * alphaG*alphaG + offsetG;
                kbarmax2 = kbarmax2 * alphaM        + offsetM;
                kgmin2   = kgmin2   * alphaG*alphaG + offsetG;
                kbarmin2 = kbarmin2 * alphaM        + offsetM;
                break;
                */
            default:
                break;
            }

            if( areaWt != 0 ) {
                kg2      *= area2;
                kbar2    *= area2;
                kgSD2    *= area2;
                kbarSD2  *= area2;
                kgmax2   *= area2;
                kgmin2   *= area2;
                kbarmax2 *= area2;
                kbarmin2 *= area2;
            }
    
            if( offset ) {
                kg2      += offsetG;
                kbar2    += offsetM;
                kgmax2   += offsetG;
                kbarmax2 += offsetM;
                kgmin2   += offsetG;
                kbarmin2 += offsetM;
            }

            Rb1 = radius2;
            Ab1 = area2;

            switch(statistic) {
            case 0:   // Avg
                glb1 = kg2;
                mlb1 = kbar2;
                break;
            case 1:   // Min
                glb1 = kgmin2;
                mlb1 = kbarmin2;
                break;
            case 2:   // Max
                gub1 = kgmax2;
                mub1 = kbarmax2;
                break;
            case 3:   // MinMax
                glb1 = kgmin2;
                gub1 = kgmax2;
                mlb1 = kbarmin2;
                mub1 = kbarmax2;
                break;
            case 4:   // StdDev
                glb1 = kgSD2;
                mlb1 = kbarSD2;
                break;
            default:
                return MC_ERROR;
            }

            if( metric == 3 ) {   // Mod
                glb1 = (glb1<0.0) ? -sqrt(-glb1) : sqrt(glb1);
                gub1 = (gub1<0.0) ? -sqrt(-gub1) : sqrt(gub1);
            }
            if( function == 1 ) {   // Log
                glb1 = (glb1<0.0) ? -log(1.0-glb1) : log(1.0+glb1);
                gub1 = (gub1<0.0) ? -log(1.0-gub1) : log(1.0+gub1);
                mlb1 = (mlb1<0.0) ? -log(1.0-mlb1) : log(1.0+mlb1);
                mub1 = (mub1<0.0) ? -log(1.0-mub1) : log(1.0+mub1);
            }
        }

        // Compute R0, R1
        R0 = R1;
        if( Ra1 > R0 && Ra1 < Rb1 ) {
            R1 = Ra1;
        } else {
            R1 = Rb1;
        }

        // Compute Fa(R0), Fa(R1)
        u0 = (R0 - Ra0) / (Ra1 - Ra0);
        Fgla0 = (1.0-u0)*gla0 + u0*gla1;
        Fgua0 = (1.0-u0)*gua0 + u0*gua1;
        Fmla0 = (1.0-u0)*mla0 + u0*mla1;
        Fmua0 = (1.0-u0)*mua0 + u0*mua1;

        u1 = (R1 - Ra0) / (Ra1 - Ra0);
        Fgla1 = (1.0-u1)*gla0 + u1*gla1;
        Fgua1 = (1.0-u1)*gua0 + u1*gua1;
        Fmla1 = (1.0-u1)*mla0 + u1*mla1;
        Fmua1 = (1.0-u1)*mua0 + u1*mua1;

        // Compute Fb(R0), Fb(R1)
        v0 = (R0 - Rb0) / (Rb1 - Rb0);
        Fglb0 = (1.0-v0)*glb0 + v0*glb1;
        Fgub0 = (1.0-v0)*gub0 + v0*gub1;
        Fmlb0 = (1.0-v0)*mlb0 + v0*mlb1;
        Fmub0 = (1.0-v0)*mub0 + v0*mub1;

        v1 = (R1 - Rb0) / (Rb1 - Rb0);
        Fglb1 = (1.0-v1)*glb0 + v1*glb1;
        Fgub1 = (1.0-v1)*gub0 + v1*gub1;
        Fmlb1 = (1.0-v1)*mlb0 + v1*mlb1;
        Fmub1 = (1.0-v1)*mub0 + v1*mub1;

        // Compute area under Curve A
        Fgla = 0.5*(Fgla0+Fgla1) * (R1-R0);
        Fgua = 0.5*(Fgua0+Fgua1) * (R1-R0);
        Fmla = 0.5*(Fmla0+Fmla1) * (R1-R0);
        Fmua = 0.5*(Fmua0+Fmua1) * (R1-R0);

        // Compute area under Curve B
        Fglb = 0.5*(Fglb0+Fglb1) * (R1-R0);
        Fgub = 0.5*(Fgub0+Fgub1) * (R1-R0);
        Fmlb = 0.5*(Fmlb0+Fmlb1) * (R1-R0);
        Fmub = 0.5*(Fmub0+Fmub1) * (R1-R0);

        // Compute surface area in current interval
        Area = pi*(R1*R1 - R0*R0);

        // Compute cumulative area
        Acum += Area;

        // Compute delta area
        switch(metric) {
        case 0:   // Gauss
            if(statistic != 2) {   // All but Max
                //delta = (Fglb - Fgla)*Area;
                delta = Fglb - Fgla;
                sum += (delta < 0.0) ? -delta : delta;
            }
            if(statistic == 2 || statistic == 3) {   // Max or MinMax
                //delta = (Fgub - Fgua)*Area;
                delta = Fgub - Fgua;
                sum += (delta < 0.0) ? -delta : delta;
            }
            break;
        case 1:   // Mean
            if(statistic != 2) {   // All but Max
                //delta = (Fmlb - Fmla)*Area;
                delta = Fmlb - Fmla;
                sum += (delta < 0.0) ? -delta : delta;
            }
            if(statistic == 2 || statistic == 3) {   // Max or MinMax
                //delta = (Fmub - Fmua)*Area;
                delta = Fmub - Fmua;
                sum += (delta < 0.0) ? -delta : delta;
            }
            break;
        case 2:   // Both
        case 3:   // Mod
            if(statistic != 2) {   // All but Max
                //delta = (Fglb - Fgla)*Area;
                delta = Fglb - Fgla;
                sum += (delta < 0.0) ? -delta : delta;
                //delta = (Fmlb - Fmla)*Area;
                delta = Fmlb - Fmla;
                sum += (delta < 0.0) ? -delta : delta;
            }
            if(statistic == 2 || statistic == 3) {   // Max or MinMax
                //delta = (Fgub - Fgua)*Area;
                delta = Fgub - Fgua;
                sum += (delta < 0.0) ? -delta : delta;
                //delta = (Fmub - Fmua)*Area;
                delta = Fmub - Fmua;
                sum += (delta < 0.0) ? -delta : delta;
            }
            break;
        default:
            break;
        }

        // Now advance to next region
        if( R1 >= Ra1 ) ia0 = ia1;
        if( R1 >= Rb1 ) ib0 = ib1;
    }

    // Divide by total area
    //value = sum / Acum;
    value = sum / R1;
    if( areaWt != 0 ) value /= Acum;

    return value;
}

int MCDistribution::ComputeScale(const MCDistribution &dist, 
		                         MC_MapMetric method, 
                                 const double Rcomp, 
					             const int areaWt,
					             double &scale,
								 const double scaleLimit,
								 const int maxIter) const
{
	int count;
	double a0, a1, a2, s0, s1, s2, invLimit, invLambda;
	double LAMBDA = 1.618;
	double dAlpha = 0.1;

	a1 = 1.0;
	a2 = 1.0 + dAlpha;
	a0 = 1.0 /(1.0 + dAlpha);
	invLimit = 1.0/scaleLimit;
	invLambda = 1.0/LAMBDA;

	s0 = Compare(dist, method, Rcomp, a0, areaWt);
	s1 = Compare(dist, method, Rcomp, a1, areaWt);
	s2 = Compare(dist, method, Rcomp, a2, areaWt);
	if( s0 >= s1 && s1 > s2 ) {
		// Look for larger scale
		a0 = a1;
		s0 = s1;
		a1 = a2;
		s1 = s2;
		a2 = a1 + LAMBDA * (a1 - a0);
		if( a2 > scaleLimit ) a2 = scaleLimit;
		s2 = Compare(dist, method, Rcomp, a2, areaWt);
		while( s2 < s1 && a2 < scaleLimit )
		{
			a0 = a1;
			s0 = s1;
			a1 = a2;
			s1 = s2;
			a2 = a1 + LAMBDA * (a1 - a0);
			if( a2 > scaleLimit ) a2 = scaleLimit;
			s2 = Compare(dist, method, Rcomp, a2, areaWt);
		}
	} else {
		if( s0 < s1 && s1 <= s2 ) {
			// Look for smaller scale
			a2 = a1;
			s2 = s1;
			a1 = a0;
			s1 = s0;
			a0 = a1 + invLambda * (a1 - a2);
			if( a0 < invLimit ) a0 = invLimit;
			s0 = Compare(dist, method, Rcomp, a0, areaWt);
			while( s0 < s1 && a0 > invLimit )
			{
				a2 = a1;
				s2 = s1;
				a1 = a0;
				s1 = s0;
				a0 = a1 - invLambda * (a1 - a2);
				if( a0 < invLimit ) a0 = invLimit;
				s0 = Compare(dist, method, Rcomp, a0, areaWt);
			}
		}
	}

	// Now find the min
	double GOLD = 0.38196;
	double ZEPS = 1.e-10;
	double x, sx;
	double a = 0.0;
	count = 0;
	s1 = Compare(dist, method, Rcomp, a1, areaWt);
	while(fabs(a2-a0) > fabs(a1*a)+ZEPS && count++ < maxIter)
	{
		double mid = 0.5*(a0 + a2);
		if( a1 > mid ) {
			x = a1 + GOLD * (a0 - a1);
		} else {
			x = a1 + GOLD * (a2 - a1);
		}
		sx = Compare(dist, method, Rcomp, x, areaWt);
		if( sx < s1 ) {
			if( x > a1 ) {
				a0 = a1;
				s0 = s1;
			} else {
				a2 = a1;
				s2 = s1;
			}
			a1 = x;
			s1 = sx;
		} else {
			if( x < a1 ) {
				a0 = x;
				s0 = sx;
			} else {
				a2 = x;
				s2 = sx;
			}
		}
	}

	scale = a1;

	return 0;
}

int MCDistribution::Copy(const MCDistribution &in_dist)
{
    int i, ier;
    double kg, kbar, kgSD, kbarSD, area, radius;
    double kgmax, kgmin, kbarmax, kbarmin;

    Clear();

    delete [] m_sDescription;
    m_sDescription = NULL;
    if( in_dist.m_sDescription != NULL ) {
        m_sDescription = new char[strlen(in_dist.m_sDescription)+1];
        strcpy(m_sDescription,in_dist.m_sDescription);
    }

    for( i=0; i<in_dist.m_iNumRings; i++ ) {
        ier = in_dist.getPoint(i, kg, kbar, kgSD, kbarSD, area, radius, 
                                  kgmax, kgmin, kbarmax, kbarmin);
        if( ier != 0 ) return ier;

        Kg         += kg;
        Kbar       += kbar;
        StdDevKg   += kgSD;
        StdDevKbar += kbarSD;
        KgMax      += kgmax;
        KgMin      += kgmin;
        KbarMax    += kbarmax;
        KbarMin    += kbarmin;
        A          += area;
        R          += radius;
    }

    m_iPointIndex = in_dist.m_iPointIndex;
    m_iNumRings = in_dist.m_iNumRings;

    return 0;
}
    
MCDistribution& MCDistribution::operator+=(const MCDistribution &in_dist)
{
    int i, iRing, ier;
    double kg, kbar, kgSD, kbarSD, u, radius;
    double kgmax, kgmin, kbarmax, kbarmin;
    double kg1, kbar1, kgSD1, kbarSD1, area1, radius1;
    double kgmax1, kgmin1, kbarmax1, kbarmin1;
    double kg2, kbar2, kgSD2, kbarSD2, area2, radius2;
    double kgmax2, kgmin2, kbarmax2, kbarmin2;

    iRing = 1;
    ier = in_dist.getPoint(iRing-1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                    kgmax1, kgmin1, kbarmax1, kbarmin1);

    ier = in_dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                  kgmax2, kgmin2, kbarmax2, kbarmin2);

    for( i=0; i<m_iNumRings; i++ ) {
        radius = R[i];
        while( radius > radius2 && iRing < in_dist.m_iNumRings-1 ) {
            kg1      = kg2;
            kbar1    = kbar2;
            kgSD1    = kgSD2;
            kbarSD1  = kbarSD2;
            kgmax1   = kgmax2;
            kbarmax1 = kbarmax2;
            kgmin1   = kgmin2;
            kbarmin1 = kbarmin2;
            iRing++;
            ier = in_dist.getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, 
                                          area2, radius2, kgmax2, 
                                          kgmin2, kbarmax2, kbarmin2);
        }

        u = (radius - radius1) / (radius2 - radius1);
        kg      = Kg[i]         + (1.0-u)*kg1      + u*kg2;
        kbar    = Kbar[i]       + (1.0-u)*kbar1    + u*kbar2;
        kgSD    = StdDevKg[i]   + (1.0-u)*kgSD1    + u*kgSD2;
        kbarSD  = StdDevKbar[i] + (1.0-u)*kbarSD1  + u*kbarSD2;
        kgmin   = KgMin[i]      + (1.0-u)*kgmin1   + u*kgmin2;
        kbarmin = KbarMin[i]    + (1.0-u)*kbarmin1 + u*kbarmin2;
        kgmax   = KgMax[i]      + (1.0-u)*kgmax1   + u*kgmax2;
        kbarmax = KbarMax[i]    + (1.0-u)*kbarmax1 + u*kbarmax2;
        Kg[i]         = kg;
        Kbar[i]       = kbar;
        StdDevKg[i]   = kgSD;
        StdDevKbar[i] = kbarSD;
        KgMin[i]      = kgmin;
        KbarMin[i]    = kbarmin;
        KgMax[i]      = kgmax;
        KbarMax[i]    = kbarmax;
    }

    return *this;
}

MCDistribution& MCDistribution::operator*=(const double scale)
{
    int i;

    for( i=0; i<m_iNumRings; i++ ) {
        Kg[i]         = Kg[i]         * scale;
        Kbar[i]       = Kbar[i]       * scale;
        StdDevKg[i]   = StdDevKg[i]   * scale;
        StdDevKbar[i] = StdDevKbar[i] * scale;
        KgMin[i]      = KgMin[i]      * scale;
        KbarMin[i]    = KbarMin[i]    * scale;
        KgMax[i]      = KgMax[i]      * scale;
        KbarMax[i]    = KbarMax[i]    * scale;
    }

    return *this;
}

MCDistribution& MCDistribution::operator/=(const double scale)
{
    int i;
    double scale_inv;

    if( scale == 0.0 ) return *this;
    scale_inv = 1.0/scale;
    
    for( i=0; i<m_iNumRings; i++ ) {
        Kg[i]         = Kg[i]         * scale_inv;
        Kbar[i]       = Kbar[i]       * scale_inv;
        StdDevKg[i]   = StdDevKg[i]   * scale_inv;
        StdDevKbar[i] = StdDevKbar[i] * scale_inv;
        KgMin[i]      = KgMin[i]      * scale_inv;
        KbarMin[i]    = KbarMin[i]    * scale_inv;
        KgMax[i]      = KgMax[i]      * scale_inv;
        KbarMax[i]    = KbarMax[i]    * scale_inv;
    }

    return *this;
}

MCDistribution& MCDistribution::Add(const MCDistribution &in_dist,
                                    const int trim,
                                    double &Rmin)
{
    int i, iRing, ier, mm, m1, m2, n1, n2, nBr, nBa, nAr, nAa;
    double r1, r2, Reff, pi;
    double kg, kbar, kgSD, kbarSD, u, area, radius;
    double kgmax, kgmin, kbarmax, kbarmin;
    double kg1, kbar1, kgSD1, kbarSD1, area1, radius1;
    double kgmax1, kgmin1, kbarmax1, kbarmin1;
    double kg2, kbar2, kgSD2, kbarSD2, area2, radius2;
    double kgmax2, kgmin2, kbarmax2, kbarmin2;
    const MCDistribution *Aref;
    const MCDistribution *Bref;
    const MCDistribution *Aadd;
    const MCDistribution *Badd;
    MCDistribution tmp;

	pi = 4.0*atan(1.0);

    n1 = this->Size();
    n2 = in_dist.Size();

    ier = getPoint(n1-1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                         kgmax1, kgmin1, kbarmax1, kbarmin1);

    ier = in_dist.getPoint(n2-1, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                 kgmax2, kgmin2, kbarmax2, kbarmin2);
    
    r1 = radius1;
    r2 = radius2;
    Rmin = (r1<r2) ? r1 : r2;

    if( r1 > r2 ) {
        Bref = this;
        Badd = &in_dist;
        nBr = n1;
        nBa = n2;
        m2 = nBa;
    } else {
        Bref = &in_dist;
        Badd = this;
        nBr = n2;
        nBa = n1;
        m1 = nBa;
    }

    mm = 1;
    for( i=0; i<nBr; i++ ) {
        ier = Bref->getPoint(i, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                               kgmax1, kgmin1, kbarmax1, kbarmin1);
        if( radius1 >= Rmin ) break;
        mm++;
    }

    if( mm > nBa ) {
        Aref = Bref;
        Aadd = Badd;
        nAr = mm;
        nAa = nBa;
    } else {
        Aref = Badd;
        Aadd = Bref;
        nAr = nBa;
        nAa = nBr;
    }

    tmp.Clear();

    iRing = 1;
    ier = Aadd->getPoint(iRing-1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                  kgmax1, kgmin1, kbarmax1, kbarmin1);

    ier = Aadd->getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                kgmax2, kgmin2, kbarmax2, kbarmin2);

    for( i=0; i<nAr; i++ ) {
        ier = Aref->getPoint(i, kg, kbar, kgSD, kbarSD, area, radius, 
                                kgmax, kbarmax, kgmin, kbarmin);
        //radius = R[i];
		if( radius > Rmin ) {
			ier = Aref->getPoint(i-1, kg1, kbar1, kgSD1, kbarSD1, 
                                      area1, radius1, kgmax1, 
                                      kgmin1, kbarmax1, kbarmin1);
			u = (Rmin - radius1) / (radius - radius1);
            kg      = u*kg      + (1.0-u)*kg1;
            kbar    = u*kbar    + (1.0-u)*kbar1;
            kgSD    = u*kgSD    + (1.0-u)*kgSD1;
            kbarSD  = u*kbarSD  + (1.0-u)*kbarSD1;
            kgmax   = u*kgmax   + (1.0-u)*kgmax1;
            kbarmax = u*kbarmax + (1.0-u)*kbarmax1;
            kgmin   = u*kgmin   + (1.0-u)*kgmin1;
            kbarmin = u*kbarmin + (1.0-u)*kbarmin1;
			Reff    = 2.0*Rmin - sqrt(area1/pi);
			area    = pi*Reff*Reff - area1;
			radius  = Rmin;

			ier = Aadd->getPoint(iRing-1, kg1, kbar1, kgSD1, kbarSD1, 
                                          area1, radius1, kgmax1, 
                                          kgmin1, kbarmax1, kbarmin1);
		}

        while( radius > radius2 && iRing < nAa ) {
            kg1      = kg2;
            kbar1    = kbar2;
            kgSD1    = kgSD2;
            kbarSD1  = kbarSD2;
            kgmax1   = kgmax2;
            kbarmax1 = kbarmax2;
            kgmin1   = kgmin2;
            kbarmin1 = kbarmin2;
			radius1  = radius2;
            iRing++;
            ier = Aadd->getPoint(iRing, kg2, kbar2, kgSD2, kbarSD2, 
                                        area2, radius2, kgmax2, 
                                        kgmin2, kbarmax2, kbarmin2);
        }

        u = (radius - radius1) / (radius2 - radius1);
        kg      += (1.0-u)*kg1      + u*kg2;
        kbar    += (1.0-u)*kbar1    + u*kbar2;
        kgSD    += (1.0-u)*kgSD1    + u*kgSD2;
        kbarSD  += (1.0-u)*kbarSD1  + u*kbarSD2;
        kgmin   += (1.0-u)*kgmin1   + u*kgmin2;
        kbarmin += (1.0-u)*kbarmin1 + u*kbarmin2;
        kgmax   += (1.0-u)*kgmax1   + u*kgmax2;
        kbarmax += (1.0-u)*kbarmax1 + u*kbarmax2;

        tmp.AddPoint(kg, kbar, kgSD, kbarSD, area, radius, 
                     kgmax, kbarmax, kgmin, kbarmin);
    }

    if( radius < Rmin ) {
		printf("Radius = %lf, Rmin= %lf\n", radius, Rmin);
		/*
        ier = Bref->getPoint(nBr-1, kg1, kbar1, kgSD1, kbarSD1, area1, radius1, 
                                    kgmax1, kgmin1, kbarmax1, kbarmin1);

        ier = Bref->getPoint(nBr, kg2, kbar2, kgSD2, kbarSD2, area2, radius2, 
                                  kgmax2, kgmin2, kbarmax2, kbarmin2);

        ier = Badd->getPoint(nBa-1, kg, kbar, kgSD, kbarSD, area, radius, 
                                kgmax, kbarmax, kgmin, kbarmin);

        u = (radius - radius1) / (radius2 - radius1);
        kg      += (1.0-u)*kg1      + u*kg2;
        kbar    += (1.0-u)*kbar1    + u*kbar2;
        kgSD    += (1.0-u)*kgSD1    + u*kgSD2;
        kbarSD  += (1.0-u)*kbarSD1  + u*kbarSD2;
        kgmin   += (1.0-u)*kgmin1   + u*kgmin2;
        kbarmin += (1.0-u)*kbarmin1 + u*kbarmin2;
        kgmax   += (1.0-u)*kgmax1   + u*kgmax2;
        kbarmax += (1.0-u)*kbarmax1 + u*kbarmax2;

        tmp.AddPoint(kg, kbar, kgSD, kbarSD, area, radius, 
                     kgmax, kbarmax, kgmin, kbarmin);
        */
    }

    Copy(tmp);

    return *this;
}

int MCDistribution::Average(const MCCurvatureMap &cmap,
                            const Array<int> &points)
{
    int ier, i, n, i_ref;
    double r_min, value;
    const MCDistribution *dist;

    // Determine range of distribution
    for( i=0; i<points.num(); i++ ) {
        dist = &(cmap.Distribution(points[i]));
        n = dist->Size();
        ier = dist->Value(RADIUS, n-1, value);
        if( ier != 0 ) return ier;

        if( i == 0 ) {
            r_min = value;
            i_ref = i;
        } else {
            if( value < r_min ) {
                r_min = value;
                i_ref = i;
            }
        }
    }

    ier = Copy( cmap.Distribution(points[i_ref]) );
    if( ier != 0 ) return ier;

    for( i=0; i<points.num(); i++ ) {
        if( i == i_ref ) continue;
        *this += cmap.Distribution(points[i]);
    }

    if( points.num() > 1 ) {
        *this /= (double) points.num();
    }

    return 0;
}

int MCDistribution::WeightedAverage(const MCCurvatureMap &cmap,
                                    const Array<int> &points,
									const Array<double> &weights)
{
    int ier, i, n, i_ref;
    double r_min, value;
    const MCDistribution *dist;
    MCDistribution cur;

	if( weights.num() != points.num() ) return -1;

    // Determine range of distribution
    for( i=0; i<points.num(); i++ ) {
        dist = &(cmap.Distribution(points[i]));
        n = dist->Size();
        ier = dist->Value(RADIUS, n-1, value);
        if( ier != 0 ) return ier;

        if( i == 0 ) {
            r_min = value;
            i_ref = i;
        } else {
            if( value < r_min ) {
                r_min = value;
                i_ref = i;
            }
        }
    }

    ier = Copy( cmap.Distribution(points[i_ref]) );
    if( ier != 0 ) return ier;
	*this *= weights[i_ref]; 

    for( i=0; i<points.num(); i++ ) {
        if( i == i_ref ) continue;
        cur.Copy(cmap.Distribution(points[i]));
		cur *= weights[i];
		*this += cur;
    }

    return 0;
}

MCDistribution::MC_MapMetric MCDistribution::Compose(const int metric, const int statistic,
                                     const int function)
{
    switch(function) {
    case 0:   // RMS
        switch(metric) {
        case 0:    // Gauss
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::RMS_GAUSS;
                break;
            case 1:    // Minimum
                return MCDistribution::RMS_GAUSS_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::RMS_GAUSS_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::RMS_GAUSS_MINMAX;
                break;
            case 4:    // Std. Dev.
                return MCDistribution::RMS_SDGAUSS;
                break;
            default:
                break;
            }
            break;
        case 1:    // Mean
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::RMS_MEAN;
                break;
            case 1:    // Minimum
                return MCDistribution::RMS_MEAN_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::RMS_MEAN_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::RMS_MEAN_MINMAX;
                break;
            case 4:    // Std. Dev.
                return MCDistribution::RMS_SDMEAN;
                break;
            default:
                break;
            }
            break;
        case 2:    // Both
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::RMS_BOTH;
                break;
            case 1:    // Minimum
                return MCDistribution::RMS_BOTH_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::RMS_BOTH_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::RMS_BOTH_MINMAX;
                break;
            case 4:    // Std. Dev.
                break;
            default:
                break;
            }
            break;
        case 3:    // Mod
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::RMS_MOD;
                break;
            case 1:    // Minimum
                return MCDistribution::RMS_MOD_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::RMS_MOD_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::RMS_MOD_MINMAX;
                break;
            case 4:    // Std. Dev.
                break;
            default:
                break;
            }
            break;
        default:
            break;
        }
        break;
    case 1:   // LOG
        switch(metric) {
        case 0:    // Gauss
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::LOG_GAUSS;
                break;
            case 1:    // Minimum
                return MCDistribution::LOG_GAUSS_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::LOG_GAUSS_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::LOG_GAUSS_MINMAX;
                break;
            case 4:    // Std. Dev.
                break;
            default:
                break;
            }
            break;
        case 1:    // Mean
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::LOG_MEAN;
                break;
            case 1:    // Minimum
                return MCDistribution::LOG_MEAN_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::LOG_MEAN_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::LOG_MEAN_MINMAX;
                break;
            case 4:    // Std. Dev.
                break;
            default:
                break;
            }
            break;
        case 2:    // Both
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::LOG_BOTH;
                break;
            case 1:    // Minimum
                return MCDistribution::LOG_BOTH_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::LOG_BOTH_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::LOG_BOTH_MINMAX;
                break;
            case 4:    // Std. Dev.
                break;
            default:
                break;
            }
            break;
        case 3:    // Mod
            switch(statistic) {
            case 0:    // Average
                return MCDistribution::LOG_MOD;
                break;
            case 1:    // Minimum
                return MCDistribution::LOG_MOD_MIN;
                break;
            case 2:    // Maximum
                return MCDistribution::LOG_MOD_MAX;
                break;
            case 3:    // Min-Max
                return MCDistribution::LOG_MOD_MINMAX;
                break;
            case 4:    // Std. Dev.
                break;
            default:
                break;
            }
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
    return MCDistribution::RMS_GAUSS;
}

void MCDistribution::Decompose(const MC_MapMetric mm, int &metric,
                               int &statistic, int &function)
{
    switch(mm) {
    case RMS_GAUSS:
    case RMS_GAUSS_MIN:
    case RMS_GAUSS_MAX:
    case RMS_GAUSS_MINMAX:
    case LOG_GAUSS:
    case LOG_GAUSS_MIN:
    case LOG_GAUSS_MAX:
    case LOG_GAUSS_MINMAX:
    case RMS_SDGAUSS:
    case RMS_SDMEAN:
        metric = 0;
        break;
    case RMS_MEAN:
    case RMS_MEAN_MIN:
    case RMS_MEAN_MAX:
    case RMS_MEAN_MINMAX:
    case LOG_MEAN:
    case LOG_MEAN_MIN:
    case LOG_MEAN_MAX:
    case LOG_MEAN_MINMAX:
        metric = 1;
        break;
    case RMS_BOTH:
    case RMS_BOTH_MIN:
    case RMS_BOTH_MAX:
    case RMS_BOTH_MINMAX:
    case LOG_BOTH:
    case LOG_BOTH_MIN:
    case LOG_BOTH_MAX:
    case LOG_BOTH_MINMAX:
        metric = 2;
        break;
    case RMS_MOD:
    case RMS_MOD_MIN:
    case RMS_MOD_MAX:
    case RMS_MOD_MINMAX:
    case LOG_MOD:
    case LOG_MOD_MIN:
    case LOG_MOD_MAX:
    case LOG_MOD_MINMAX:
        metric = 3;
        break;
    default:
        metric = 0;
        break;
    }

    switch(mm) {
    case RMS_GAUSS:
    case RMS_MEAN:
    case RMS_BOTH:
    case RMS_MOD:
    case LOG_GAUSS:
    case LOG_MEAN:
    case LOG_BOTH:
    case LOG_MOD:
        statistic = 0;
        break;
    case RMS_GAUSS_MIN:
    case RMS_MEAN_MIN:
    case RMS_BOTH_MIN:
    case RMS_MOD_MIN:
    case LOG_GAUSS_MIN:
    case LOG_MEAN_MIN:
    case LOG_BOTH_MIN:
    case LOG_MOD_MIN:
        statistic = 1;
        break;
    case RMS_GAUSS_MAX:
    case RMS_MEAN_MAX:
    case RMS_BOTH_MAX:
    case RMS_MOD_MAX:
    case LOG_GAUSS_MAX:
    case LOG_MEAN_MAX:
    case LOG_BOTH_MAX:
    case LOG_MOD_MAX:
        statistic = 2;
        break;
    case RMS_GAUSS_MINMAX:
    case RMS_MEAN_MINMAX:
    case RMS_BOTH_MINMAX:
    case RMS_MOD_MINMAX:
    case LOG_GAUSS_MINMAX:
    case LOG_MEAN_MINMAX:
    case LOG_BOTH_MINMAX:
    case LOG_MOD_MINMAX:
        statistic = 3;
        break;
    case RMS_SDGAUSS:
    case RMS_SDMEAN:
        statistic = 4;
        break;
    default:
        statistic = 0;
        break;
    }

    switch(mm) {
    case RMS_GAUSS:
    case RMS_GAUSS_MIN:
    case RMS_GAUSS_MAX:
    case RMS_GAUSS_MINMAX:
    case RMS_MEAN:
    case RMS_MEAN_MIN:
    case RMS_MEAN_MAX:
    case RMS_MEAN_MINMAX:
    case RMS_BOTH:
    case RMS_BOTH_MIN:
    case RMS_BOTH_MAX:
    case RMS_BOTH_MINMAX:
    case RMS_MOD:
    case RMS_MOD_MIN:
    case RMS_MOD_MAX:
    case RMS_MOD_MINMAX:
    case RMS_SDGAUSS:
    case RMS_SDMEAN:
        function = 0;
        break;
    case LOG_GAUSS:
    case LOG_GAUSS_MIN:
    case LOG_GAUSS_MAX:
    case LOG_GAUSS_MINMAX:
    case LOG_MEAN:
    case LOG_MEAN_MIN:
    case LOG_MEAN_MAX:
    case LOG_MEAN_MINMAX:
    case LOG_BOTH:
    case LOG_BOTH_MIN:
    case LOG_BOTH_MAX:
    case LOG_BOTH_MINMAX:
    case LOG_MOD:
    case LOG_MOD_MIN:
    case LOG_MOD_MAX:
    case LOG_MOD_MINMAX:
        function = 1;
        break;
    default:
        function = 0;
        break;
    }
}

const char * MCDistribution::Metric(MC_MapMetric method)
{
    switch(method) {

    case RMS_GAUSS:
        return "RMS Gauss";
        break;

    case RMS_GAUSS_MIN:
        return "RMS Gauss (min)";
        break;

    case RMS_GAUSS_MAX:
        return "RMS Gauss (max)";
        break;

    case RMS_GAUSS_MINMAX:
        return "RMS Gauss (minmax)";
        break;

    case RMS_MEAN:
        return "RMS Mean";
        break;

    case RMS_MEAN_MIN:
        return "RMS Mean (min)";
        break;

    case RMS_MEAN_MAX:
        return "RMS Mean (max)";
        break;

    case RMS_MEAN_MINMAX:
        return "RMS Mean (minmax)";
        break;

    case RMS_BOTH:
        return "RMS Gauss and Mean";
        break;

    case RMS_BOTH_MIN:
        return "RMS Gauss and Mean (min)";
        break;

    case RMS_BOTH_MAX:
        return "RMS Gauss and Mean (max)";
        break;

    case RMS_BOTH_MINMAX:
        return "RMS Gauss and Mean (minmax)";
        break;

    case RMS_MOD:
        return "RMS Mod Gauss and Mean";
        break;

    case RMS_MOD_MIN:
        return "RMS Mod Gauss and Mean (min)";
        break;

    case RMS_MOD_MAX:
        return "RMS Mod Gauss and Mean (max)";
        break;

    case RMS_MOD_MINMAX:
        return "RMS Mod Gauss and Mean (minmax)";
        break;

    case LOG_GAUSS:
        return "Log Gauss";
        break;

    case LOG_GAUSS_MIN:
        return "Log Gauss (min)";
        break;

    case LOG_GAUSS_MAX:
        return "Log Gauss (max)";
        break;

    case LOG_GAUSS_MINMAX:
        return "Log Gauss (minmax)";
        break;

    case LOG_MEAN:
        return "Log Mean";
        break;

    case LOG_MEAN_MIN:
        return "Log Mean (min)";
        break;

    case LOG_MEAN_MAX:
        return "Log Mean (max)";
        break;

    case LOG_MEAN_MINMAX:
        return "Log Mean (minmax)";
        break;

    case LOG_BOTH:
        return "Log Gauss and Mean";
        break;

    case LOG_BOTH_MIN:
        return "Log Gauss and Mean (min)";
        break;

    case LOG_BOTH_MAX:
        return "Log Gauss and Mean (max)";
        break;

    case LOG_BOTH_MINMAX:
        return "Log Gauss and Mean (minmax)";
        break;

    case LOG_MOD:
        return "Log Mod Gauss and Mean";
        break;

    case LOG_MOD_MIN:
        return "Log Mod Gauss and Mean (min)";
        break;

    case LOG_MOD_MAX:
        return "Log Mod Gauss and Mean (max)";
        break;

    case LOG_MOD_MINMAX:
        return "Log Mod Gauss and Mean (minmax)";
        break;

    case RMS_SDGAUSS:
        return "RMS Gauss Std Dev";
        break;

    case RMS_SDMEAN:
        return "RMS Mean Std Dev";
        break;

    default:
        break;
    }

    return "Unknown";
}

int MCDistribution::Smooth(const int nTerm)
{
	int ier, i, n;
	double kg, km;
	Array<R2Pt> KgCrv;
	Array<R2Pt> KmCrv;
	Array<R2Pt> SmoothKgCrv;
	Array<R2Pt> SmoothKmCrv;

	n = m_iNumRings;
	KgCrv.need(0);
	KmCrv.need(0);
	for( i=0; i<n; i++ ) {
		KgCrv += R2Pt(R[i], Kg[i]);
		KmCrv += R2Pt(R[i], Kbar[i]);
	}
	ier = tdgSmoothCurve(KgCrv, n, nTerm, SmoothKgCrv);
	if( ier != 0 ) return ier;

	ier = tdgSmoothCurve(KmCrv, n, nTerm, SmoothKmCrv);
	if( ier != 0 ) return ier;

	for( i=0; i<n; i++ ) {
		kg = SmoothKgCrv[i][1];
		km = SmoothKmCrv[i][1];
		Kg[i]   = kg;
		Kbar[i] = km;
	}

	return 0;
}

int MCDistribution::Filter(const double sigma)
{
	int ier, i, n;
	double kg, km;
	Array<R2Pt> KgCrv;
	Array<R2Pt> KmCrv;
	Array<R2Pt> SmoothKgCrv;
	Array<R2Pt> SmoothKmCrv;

	n = m_iNumRings;
	KgCrv.need(0);
	KmCrv.need(0);
	for( i=0; i<n; i++ ) {
		KgCrv += R2Pt(R[i], Kg[i]);
		KmCrv += R2Pt(R[i], Kbar[i]);
	}
	ier = tdgFilterCurve(KgCrv, sigma, SmoothKgCrv);
	if( ier != 0 ) return ier;

	ier = tdgFilterCurve(KmCrv, sigma, SmoothKmCrv);
	if( ier != 0 ) return ier;

	for( i=0; i<n; i++ ) {
		kg = SmoothKgCrv[i][1];
		km = SmoothKmCrv[i][1];
		Kg[i]   = kg;
		Kbar[i] = km;
	}

	return 0;
}

int MCDistribution::Flatness(const double r,
		                     double &min_km, double &max_km,
				             double &min_kg, double &max_kg,
				             double &avg_km, double &avg_kg) const
{
	int i;
	double f, r0, r1, km0, km1, kg0, kg1, area_km, area_kg, value;

	min_km = Kbar[0];
	max_km = Kbar[0];
	min_kg = Kg[0];
	max_kg = Kg[0];
	area_km = 0.0;
	area_kg = 0.0;

	for( i=1; i<R.num(); i++ ) {
		r0 = R[i-1];
		r1 = R[i];
		km0 = Kbar[i-1];
		km1 = Kbar[i];
		kg0 = Kg[i-1];
		kg1 = Kg[i];

		// Limit to the specified range
		if( r0 >= r ) break;
		if( r1 > r ) {
			f = (r-r0)/(r1-r0);
			km1 = (1.0-f)*km0 + f*km1;
			kg1 = (1.0-f)*kg0 + f*kg1;
			r1 = r;
		}

		if( km1 < min_km ) min_km = km1;
		if( km1 > max_km ) max_km = km1;
		if( kg1 < min_kg ) min_kg = kg1;
		if( kg1 > max_kg ) max_kg = kg1;

		value = (r1-r0)*0.5*(km0+km1);
		area_km += value;

		value = (r1-r0)*0.5*(kg0+kg1);
		area_kg += value;
	
		if( r1 >= r ) break;
	}
	avg_km = area_km / r1;
	avg_kg = area_kg / r1;

	return 0;
}

int MCDistribution::Analyze(const double &r, 
		                    int &pos_km,      int &pos_kg, 
		                    int &dir_km,      int &dir_kg, 
		                    double &km,       double &kg,
		                    double &dist1_km, double &dist1_kg, 
				            double &dist2_km, double &dist2_kg, 
				            double &distM_km, double &distM_kg, 
				            double &area1_km, double &area1_kg, 
				            double &area2_km, double &area2_kg, 
				            double &areaM_km, double &areaM_kg, 
				            double &areaR_km, double &areaR_kg, 
				            double &abs_R_km, double &abs_R_kg, 
				            double &delta_km) const
{
	int i;
	double found_1m, found_2m, found_mm, found_1g, found_2g, found_mg;
	double del_d, del_km, del_kg, f, r0, r1, km0, km1, kg0, kg1, tmp;
	double radical, value;

	int verbose = 0;

	km = Kbar[0];
	kg = Kg[0];
	if( km < 0 ) {
		pos_km = 0;
	} else {
		pos_km = 1;
	}
	if( kg < 0 ) {
		pos_kg = 0;
	} else {
		pos_kg = 1;
	}

	dir_km = 0;
	for( i=1; i<R.num(); i++ ) {
		if( Kbar[i] > Kbar[i-1] ) {
			dir_km = 1;
			break;
		}
		if( Kbar[i] < Kbar[i-1] ) {
			dir_km = -1;
			break;
		}
	}

	dir_kg = 0;
	for( i=1; i<R.num(); i++ ) {
		if( Kg[i] > Kg[i-1] ) {
			dir_kg = 1;
			break;
		}
		if( Kg[i] < Kg[i-1] ) {
			dir_kg = -1;
			break;
		}
	}

	found_1m = 0;
	found_2m = 0;
	found_mm = 0;
	found_1g = 0;
	found_2g = 0;
	found_mg = 0;
	dist1_km = r;
	dist2_km = r;
	distM_km = r;
	dist1_kg = r;
	dist2_kg = r;
	distM_kg = r;
	for( i=1; i<R.num(); i++ ) {

		// Find monotonic Km range
		if( dir_km == 1 && !found_mm && Kbar[i] < Kbar[i-1] ) {
			distM_km = R[i-1];
			found_mm = 1;
		}
		if( dir_km == -1 && !found_mm && Kbar[i] > Kbar[i-1] ) {
			distM_km = R[i-1];
			found_mm = 1;
		}

		// Find Km zero crossings
		if( (Kbar[i] >= 0.0 && Kbar[i-1] < 0.0) ||
			(Kbar[i] <= 0.0 && Kbar[i-1] > 0.0) ) {
			if( !found_1m ) {
				f = -Kbar[i-1]/(Kbar[i]-Kbar[i-1]);
				dist1_km = (1.0-f)*R[i-1] + f*R[i];
				if( dist1_km > r ) dist1_km = r;
				found_1m = 1;
			} else {
				if( !found_2m ) {
					f = -Kbar[i-1]/(Kbar[i]-Kbar[i-1]);
					dist2_km = (1.0-f)*R[i-1] + f*R[i];
					if( dist2_km > r ) dist2_km = r;
					found_2m = 1;
				}
			}
		}

		// Find monotonic Kg range
		if( dir_kg == 1 && !found_mg && Kg[i] < Kg[i-1] ) {
			distM_kg = R[i-1];
			found_mg = 1;
		}
		if( dir_kg == -1 && !found_mg && Kg[i] > Kg[i-1] ) {
			distM_kg = R[i-1];
			found_mg = 1;
		}
		
		// Find Kg zero crossings
		if( (Kg[i] >= 0.0 && Kg[i-1] < 0.0) ||
			(Kg[i] <= 0.0 && Kg[i-1] > 0.0) ) {
			if( !found_1g ) {
				f = -Kg[i-1]/(Kg[i]-Kg[i-1]);
				dist1_kg = (1.0-f)*R[i-1] + f*R[i];
				if( dist1_kg > r ) dist1_kg = r;
				found_1g = 1;
			} else {
				if( !found_2g ) {
					f = -Kg[i-1]/(Kg[i]-Kg[i-1]);
					dist2_kg = (1.0-f)*R[i-1] + f*R[i];
					if( dist2_kg > r ) dist2_kg = r;
					found_2g = 1;
				}
			}
		}

		if( R[i] > r ) break;
	}

	// Limit monotonic range to first zero crossing
	if( distM_km > dist1_km ) distM_km = dist1_km;
	if( distM_kg > dist1_kg ) distM_kg = dist1_kg;
	del_d = (dist1_km < dist1_kg) ? dist1_km : dist1_kg;

	// Integrate areas
	area1_km = 0.0;
	area2_km = 0.0;
	areaM_km = 0.0;
	areaR_km = 0.0;
	abs_R_km = 0.0;
	area1_kg = 0.0;
	area2_kg = 0.0;
	areaM_kg = 0.0;
	areaR_kg = 0.0;
	abs_R_kg = 0.0;
	del_km   = 0.0;
	del_kg   = 0.0;
	for( i=1; i<R.num(); i++ ) {
		r0 = R[i-1];
		r1 = R[i];
		km0 = Kbar[i-1];
		km1 = Kbar[i];
		kg0 = Kg[i-1];
		kg1 = Kg[i];

		// Limit to the specified range
		if( r0 >= r ) break;
		if( r1 > r ) {
			f = (r-r0)/(r1-r0);
			km1 = (1.0-f)*km0 + f*km1;
			kg1 = (1.0-f)*kg0 + f*kg1;
			if(verbose) printf("Setting r1 from %lf to %lf: km1=%lf, kg1=%lf\n",
				               R[i], r, km1, kg1);
			r1 = r;
		}

		// Find Km areas
		if( r1 <= dist1_km ) {
			value = (r1-r0)*0.5*(km0+km1);
			area1_km += value;
			if(verbose) printf("r (%lf-%lf): area1_km += %lf\n", r0, r1, value);
		}
		if( r0 <= dist1_km && r1 > dist1_km ) {
			f = (dist1_km-r0)/(r1-r0);
			tmp = (1.0-f)*km0 + f*km1;
			value = (dist1_km-r0)*0.5*(km0+tmp);
			area1_km += value;
			if(verbose) printf("r (%lf-%lf): area1_km += %lf\n", r0, dist1_km, value);
			value = (r1-dist1_km)*0.5*(tmp+km1);
			area2_km += value;
			if(verbose) printf("r (%lf-%lf): area2_km += %lf\n", dist1_km, r1, value);
		}
		if( r0 > dist1_km && r1 <= dist2_km ) {
			value = (r1-r0)*0.5*(km0+km1);
			area2_km += value;
			if(verbose) printf("r (%lf-%lf): area2_km += %lf\n", r0, r1, value);
		}
		if( r0 <= dist2_km && r1 > dist2_km ) {
			f = (dist2_km-r0)/(r1-r0);
			tmp = (1.0-f)*km0 + f*km1;
			value = (dist2_km-r0)*0.5*(km0+tmp);
			area2_km += value;
			if(verbose) printf("r (%lf-%lf): area2_km += %lf\n", r0, dist2_km, value);
			value = (r1-dist2_km)*0.5*(tmp+km1);
			areaR_km += value;
			if(verbose) printf("r (%lf-%lf): areaR_km += %lf\n", dist2_km, r1, value);
			abs_R_km += abs(value);
			if(verbose) printf("r (%lf-%lf): abs_R_km += %lf\n", dist2_km, r1, abs(value));
		}
		if( r0 > dist2_km ) {
			value = (r1-r0)*0.5*(km0+km1);
			areaR_km += value;
			if(verbose) printf("r (%lf-%lf): areaR_km += %lf\n", r0, r1, value);
			if( ( km0 < 0.0 && km1 > 0.0 ) ||
				( km0 > 0.0 && km1 < 0.0 ) ) {
				f = -km0/(km1-km0);
				tmp = (1.0-f)*r0 + f*r1;
				value = abs((tmp-r0)*0.5*km0);
				abs_R_km += value;
				if(verbose) printf("r (%lf-%lf): abs_R_km += %lf\n", r0, tmp, value);
				value = abs((r1-tmp)*0.5*km1);
				abs_R_km += value;
				if(verbose) printf("r (%lf-%lf): abs_R_km += %lf\n", tmp, r1, value);
			} else {
				value = abs((r1-r0)*0.5*(km0+km1));
				abs_R_km += value;
				if(verbose) printf("r (%lf-%lf): abs_R_km += %lf\n", r0, r1, value);
			}
		}
		if( r1 <= distM_km ) {
			value = (r1-r0)*0.5*(km0+km1);
			areaM_km += value;
			if(verbose) printf("r (%lf-%lf): areaM_km += %lf\n", r0, r1, value);
		}
		if( r0 <= distM_km && r1 > distM_km ) {
			f = (distM_km-r0)/(r1-r0);
			tmp = (1.0-f)*km0 + f*km1;
			value = (distM_km-r0)*0.5*(km0+tmp);
			areaM_km += value;
			if(verbose) printf("r (%lf-%lf): areaM_km += %lf\n", r0, distM_km, value);
		}

		// Find Kg areas
		if( r1 <= dist1_kg ) {
			value = (r1-r0)*0.5*(kg0+kg1);
			area1_kg += value;
			if(verbose) printf("r (%lf-%lf): area1_kg += %lf\n", r0, r1, value);
		}
		if( r0 <= dist1_kg && r1 > dist1_kg ) {
			f = (dist1_kg-r0)/(r1-r0);
			tmp = (1.0-f)*kg0 + f*kg1;
			value = (dist1_kg-r0)*0.5*(kg0+tmp);
			area1_kg += value;
			if(verbose) printf("r (%lf-%lf): area1_kg += %lf\n", r0, dist1_kg, value);
			value = (r1-dist1_kg)*0.5*(tmp+kg1);
			area2_kg += value;
			if(verbose) printf("r (%lf-%lf): area2_kg += %lf\n", dist1_kg, r1, value);
		}
		if( r0 > dist1_kg && r1 <= dist2_kg ) {
			value = (r1-r0)*0.5*(kg0+kg1);
			area2_kg += value;
			if(verbose) printf("r (%lf-%lf): area2_kg += %lf\n", r0, r1, value);
		}
		if( r0 <= dist2_kg && r1 > dist2_kg ) {
			f = (dist2_kg-r0)/(r1-r0);
			tmp = (1.0-f)*kg0 + f*kg1;
			value = (dist2_kg-r0)*0.5*(kg0+tmp);
			area2_kg += value;
			if(verbose) printf("r (%lf-%lf): area2_kg += %lf\n", r0, dist2_kg, value);
			value = (r1-dist2_kg)*0.5*(tmp+kg1);
			areaR_kg += value;
			if(verbose) printf("r (%lf-%lf): areaR_kg += %lf\n", dist2_kg, r1, value);
		}
		if( r0 > dist2_kg ) {
			value = (r1-r0)*0.5*(kg0+kg1);
			areaR_kg += value;
			if(verbose) printf("r (%lf-%lf): areaR_kg += %lf\n", r0, r1, value);
			if( ( kg0 < 0.0 && kg1 > 0.0 ) ||
				( kg0 > 0.0 && kg1 < 0.0 ) ) {
				f = -kg0/(kg1-kg0);
				tmp = (1.0-f)*r0 + f*r1;
				value = abs((tmp-r0)*0.5*kg0);
				abs_R_kg += value;
				if(verbose) printf("r (%lf-%lf): abs_R_kg += %lf\n", r0, tmp, value);
				value = abs((r1-tmp)*0.5*kg1);
				abs_R_kg += value;
				if(verbose) printf("r (%lf-%lf): abs_R_kg += %lf\n", tmp, r1, value);
			} else {
				value = abs((r1-r0)*0.5*(kg0+kg1));
				abs_R_kg += value;
				if(verbose) printf("r (%lf-%lf): abs_R_kg += %lf\n", r0, r1, value);
			}
		}
		if( r1 <= distM_kg ) {
			value = (r1-r0)*0.5*(kg0+kg1);
			areaM_kg += value;
			if(verbose) printf("r (%lf-%lf): areaM_kg += %lf\n", r0, r1, value);
		}
		if( r0 <= distM_kg && r1 > distM_kg ) {
			f = (distM_kg-r0)/(r1-r0);
			tmp = (1.0-f)*kg0 + f*kg1;
			value = (distM_kg-r0)*0.5*(kg0+tmp);
			areaM_kg += value;
			if(verbose) printf("r (%lf-%lf): areaM_kg += %lf\n", r0, distM_kg, value);
		}

		// Find areas for delta Km
		if( r1 <= del_d ) {
			value = (r1-r0)*0.5*(km0+km1);
			del_km += value;
			if(verbose) printf("r (%lf-%lf): del_km += %lf\n", r0, r1, value);
			value = (r1-r0)*0.5*(kg0+kg1);
			del_kg += value;
			if(verbose) printf("r (%lf-%lf): del_kg += %lf\n", r0, r1, value);
		}
		if( r0 <= del_d && r1 > del_d ) {
			f = (del_d-r0)/(r1-r0);
			tmp = (1.0-f)*km0 + f*km1;
			value = (del_d-r0)*0.5*(km0+tmp);
			del_km += value;
			if(verbose) printf("r (%lf-%lf): del_km += %lf\n", r0, del_d, value);
			tmp = (1.0-f)*kg0 + f*kg1;
			value = (del_d-r0)*0.5*(kg0+tmp);
			del_kg += value;
			if(verbose) printf("r (%lf-%lf): del_kg += %lf\n", r0, del_d, value);
		}

		if( r1 >= r ) break;
	}
	value = area1_km + area2_km;
	areaR_km += value;
	if(verbose) printf("r (%lf-%lf): areaR_km += %lf\n", 0.0, dist2_km, value);
	value = abs(area1_km) + abs(area2_km);
	abs_R_km += value;
	if(verbose) printf("r (%lf-%lf): abs_R_km += %lf\n", 0.0, dist2_km, value);
	value = area1_kg + area2_kg;
	areaR_kg += value;
	if(verbose) printf("r (%lf-%lf): areaR_kg += %lf\n", 0.0, dist2_kg, value);
	value = abs(area1_kg) + abs(area2_kg);
	abs_R_kg += value;
	if(verbose) printf("r (%lf-%lf): abs_R_kg += %lf\n", 0.0, dist2_kg, value);

	radical = del_km*del_km - del_kg;
	radical = (radical <= 0.0) ? 0.0 : sqrt(radical);
	if( del_kg >= 0 ) {
		delta_km = 2.0*radical;
	} else {
		delta_km = 2.0*del_km;
	}

	return 0;
}
