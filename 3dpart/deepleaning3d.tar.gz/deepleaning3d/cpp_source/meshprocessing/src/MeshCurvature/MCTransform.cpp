#include "StdAfx.H"
#include "math.h"
#include <MC/MC_Transform.H>
#include <utils/Pm_MeshLite.H>

MCTransform::MCTransform()
{
    m_Xref   = R3Pt(0.0, 0.0, 0.0);
    m_Nref   = R3Vec(0.0, 0.0, 1.0);
    m_Lambda = R3Vec(1.0, 0.0, 0.0);
    m_Mu     = R3Vec(0.0, 1.0, 0.0);
    m_Nu     = R3Vec(0.0, 0.0, 1.0);
}

MCTransform::~MCTransform()
{
}

int MCTransform::setTransform( const R3Pt &in_point, const R3Vec &in_normal )
{
    double mag;
    R3Vec axis1;
    R3Vec axis2;
    R3Vec ref;

    mag = in_normal[0]*in_normal[0] 
        + in_normal[1]*in_normal[1] 
        + in_normal[2]*in_normal[2];
    if( mag <= 0.0 ) return -1;

    m_Xref = in_point;
    m_Nref = in_normal;
    m_Nref.Normalize();

	double a = m_Nref[0] * m_Nref[0];
    double b = m_Nref[1] * m_Nref[1];
    double c = m_Nref[2] * m_Nref[2];

	ref = R3Vec(1.0, 0.0, 0.0);
	if( b < a ) ref = R3Vec(0.0, 1.0, 0.0);
	if( c < a && c < b ) ref = R3Vec(0.0, 0.0, 1.0);

	//axis2 = m_Nref x ref
    axis2[0] = m_Nref[1] * ref[2] - m_Nref[2] * ref[1];
    axis2[1] = m_Nref[2] * ref[0] - m_Nref[0] * ref[2];
    axis2[2] = m_Nref[0] * ref[1] - m_Nref[1] * ref[0];
    axis2.Normalize();

	//axis1 = axis2 x in_normal
    axis1[0] = axis2[1] * in_normal[2] - axis2[2] * in_normal[1];
    axis1[1] = axis2[2] * in_normal[0] - axis2[0] * in_normal[2];
    axis1[2] = axis2[0] * in_normal[1] - axis2[1] * in_normal[0];
    axis1.Normalize();	

    m_Lambda = R3Vec(axis1[0], -axis2[0], m_Nref[0]);
    m_Mu     = R3Vec(axis1[1], -axis2[1], m_Nref[1]);
    m_Nu     = R3Vec(axis1[2], -axis2[2], m_Nref[2]);
/*
	UTILSDotArray mDots;
	
	mDots.Add(in_point, UTILSColor::BLACK);
	mDots.AddPair( in_point, in_point + m_Nref, UTILSColor::RED );
	mDots.AddPair( in_point, in_point + axis1, UTILSColor::GREEN );
	mDots.AddPair( in_point, in_point + axis2, UTILSColor::BLUE );
	mDots.AddPair( in_point, in_point + m_Lambda, UTILSColor::PURPLE );
	mDots.AddPair( in_point, in_point + m_Mu, UTILSColor::YELLOW );
	mDots.AddPair( in_point, in_point + m_Nu, UTILSColor::GREY );
	mDots.Write( "E:/CVS-graphics-XP/cmg/Data/data-from-Sandra/chick1-040410-Mar1/m-files/180/test/Transform.txt" );
*/
    return 0;
}

void MCTransform::toLocal( const R3Pt &in_point, const R3Vec &in_normal,
                                 R3Pt &out_point,      R3Vec &out_normal ) const
{
   R3Vec dx;

   dx = in_point - m_Xref;

   out_point[0] = m_Lambda[0] * dx[0] + m_Mu[0] * dx[1] + m_Nu[0] * dx[2];
   out_point[1] = m_Lambda[1] * dx[0] + m_Mu[1] * dx[1] + m_Nu[1] * dx[2];
   out_point[2] = m_Lambda[2] * dx[0] + m_Mu[2] * dx[1] + m_Nu[2] * dx[2];

   out_normal[0] = m_Lambda[0] * in_normal[0] 
                 +     m_Mu[0] * in_normal[1] 
                 +     m_Nu[0] * in_normal[2];
   out_normal[1] = m_Lambda[1] * in_normal[0] 
                 +     m_Mu[1] * in_normal[1] 
                 +     m_Nu[1] * in_normal[2];
   out_normal[2] = m_Lambda[2] * in_normal[0] 
                 +     m_Mu[2] * in_normal[1] 
                 +     m_Nu[2] * in_normal[2];
}

void MCTransform::toLocal( R3Pt &point ) const
{
    R3Vec dx;

    dx = point - m_Xref;

    point[0] = m_Lambda[0] * dx[0] + m_Mu[0] * dx[1] + m_Nu[0] * dx[2];
    point[1] = m_Lambda[1] * dx[0] + m_Mu[1] * dx[1] + m_Nu[1] * dx[2];
    point[2] = m_Lambda[2] * dx[0] + m_Mu[2] * dx[1] + m_Nu[2] * dx[2];
}

void MCTransform::toLocal( R3Vec &normal ) const
{
   R3Vec old_normal;

   old_normal = normal;

   normal[0] = m_Lambda[0] * old_normal[0] 
             +     m_Mu[0] * old_normal[1] 
             +     m_Nu[0] * old_normal[2];
   normal[1] = m_Lambda[1] * old_normal[0] 
             +     m_Mu[1] * old_normal[1] 
             +     m_Nu[1] * old_normal[2];
   normal[2] = m_Lambda[2] * old_normal[0] 
             +     m_Mu[2] * old_normal[1] 
             +     m_Nu[2] * old_normal[2];
}

void MCTransform::fromLocal( const R3Pt &in_point, const R3Vec &in_normal,
                             R3Pt &out_point,      R3Vec &out_normal ) const
{
    R3Pt X;

    X = R3Pt( m_Lambda[0]*in_point[0] + m_Lambda[1]*in_point[1]
                                      + m_Lambda[2]*in_point[2],
              m_Mu[0]*in_point[0] + m_Mu[1]*in_point[1] + m_Mu[2]*in_point[2],
              m_Nu[0]*in_point[0] + m_Nu[1]*in_point[1] + m_Nu[2]*in_point[2] );

    out_point = R3Pt(X[0] + m_Xref[0], X[1] + m_Xref[1], X[2] + m_Xref[2]);
   
    out_normal[0] = m_Lambda[0] * in_normal[0] 
                  + m_Lambda[1] * in_normal[1]
                  + m_Lambda[2] * in_normal[2];
    out_normal[1] = m_Mu[0] * in_normal[0] 
                  + m_Mu[1] * in_normal[1] 
                  + m_Mu[2] * in_normal[2];
    out_normal[2] = m_Nu[0] * in_normal[0] 
                  + m_Nu[1] * in_normal[1] 
                  + m_Nu[2] * in_normal[2];
}

void MCTransform::fromLocal( R3Pt &point ) const
{
    R3Pt X;

    X = R3Pt( m_Lambda[0]*point[0] + m_Lambda[1]*point[1] + m_Lambda[2]*point[2],
              m_Mu[0]*point[0] + m_Mu[1]*point[1] + m_Mu[2]*point[2],
              m_Nu[0]*point[0] + m_Nu[1]*point[1] + m_Nu[2]*point[2] );

    point = R3Pt(X[0] + m_Xref[0], X[1] + m_Xref[1], X[2] + m_Xref[2]);
}

void MCTransform::fromLocal( R3Vec &normal ) const
{
    R3Vec old_normal;

    old_normal = normal;

    normal[0] = m_Lambda[0] * old_normal[0] 
              + m_Lambda[1] * old_normal[1]
              + m_Lambda[2] * old_normal[2];
    normal[1] = m_Mu[0] * old_normal[0] 
              + m_Mu[1] * old_normal[1] 
              + m_Mu[2] * old_normal[2];
    normal[2] = m_Nu[0] * old_normal[0] 
              + m_Nu[1] * old_normal[1] 
              + m_Nu[2] * old_normal[2];
}

void MCTransform::Weingarten( const double A,
                              const double B,
                              const double C,
                              double &k1, double &k2, 
                              R3Vec &v1, R3Vec &v2 )
{
   double rad, tmp;

   if( B == 0.0 ) {
      if( abs(A) > abs(C) ) {
         k1 = A;
         k2 = C;
         v1 = R3Vec(1.0, 0.0, 0.0);
         v2 = R3Vec(0.0, 1.0, 0.0);
      } else {
         k1 = C;
         k2 = A;
         v1 = R3Vec(0.0, 1.0, 0.0);
         v2 = R3Vec(1.0, 0.0, 0.0);
      }
      return;
   }
   tmp = A*A + C*C + 4.0*B*B - 2.0*A*C;
   if( tmp < 0.0 ) {
      rad = 0.0;
   } else {
      rad = sqrt( tmp );
   }
   k1 = 0.5 * ( A + C + rad );
   k2 = 0.5 * ( A + C - rad );
   if( abs(k2) > abs(k1) ) {
      tmp = k1;
      k1 = k2;
      k2 = tmp;
   }

   v1 = R3Vec(1.0, (k1-A)/B, 0.0);
   v1.Normalize();

   v2 = R3Vec(1.0, (k2-A)/B, 0.0);
   v2.Normalize();
}

void MCTransform::dump( FILE *out ) const
{
   if( out != NULL ) {
      fprintf(out," Point= %lf, %lf, %lf\n", m_Xref[0], m_Xref[1], m_Xref[2] );
      fprintf(out,"Normal= %lf, %lf, %lf\n", m_Nref[0], m_Nref[1], m_Nref[2] );
      fprintf(out,"Lambda= %lf, %lf, %lf\n", 
                  m_Lambda[0], m_Lambda[1], m_Lambda[2] );
      fprintf(out,"    Mu= %lf, %lf, %lf\n", m_Mu[0], m_Mu[1], m_Mu[2] );
      fprintf(out,"    Nu= %lf, %lf, %lf\n", m_Nu[0], m_Nu[1], m_Nu[2] );
   }
}
