#include "StdAfx.H"
#include <stdio.h>
#include <MC/MC_DiscreteOperator.H>
#include <MC/MC_Param.H>
#include <MC/MC_Fit.H>
#include <MC/MC_MeshSubset.H>
#include <MC/MC_Transform.H>
#include <utils/Pm_MeshLite.H>
#include <fitting/FITTools_Least_squares.H>
//#include <MC/MC_Point.H>

MCDiscreteOperator::MCDiscreteOperator( const PMeshLite &in_mesh,
                                        const MCDiscreteOperator::MC_DiscreteType &in_discreteType )
: MCFit(in_mesh, DISCRETE, MCParam::NONE)
{
    m_DiscreteType = in_discreteType;
}

MCDiscreteOperator::~MCDiscreteOperator()
{
}

int 
MCDiscreteOperator::Curvature(const Vertex &in_vertex, MCPoint &cpt)
{
    int ier;
    R3Pt P;
    R3Vec NN, Xu, Xv, Xuu, Xuv, Xvv;

    //if( !valid || in_vertex != m_Vertex ) {
        ier = CalculateFit(in_vertex);
		if( ier != 0 ) return ier;
    //}

    switch(m_DiscreteType) {
        case DCO:
        case ModDCO:
			ier = calcDCO(in_vertex, cpt);
			break;
        case ANCe:
        case ANC:
            ier = calcANC(in_vertex, cpt);
            break;
        case IEV:
            ier = calcIEV(in_vertex, cpt);
            break;
        case HST:
            ier = calcHST(in_vertex, cpt);
            break;
        case DGM:
            ier = calcDGM(in_vertex, cpt);
            break;
        default:
            break;
    }
    return 0;
}

int
MCDiscreteOperator::calcDCO(const Vertex &in_vertex, MCPoint &out_point)
{
    int i, ier;
    double pi, Amixed, cotAlphaBeta;
    double TotalTheta, TotalAngle, DotProduct, factor;
    double theta, alpha, beta, t, a, b, kg, kbar;
    R3Vec N, e1, e2;
    R3Vec localEdge;
    R3Vec kNormal = R3Vec(0.0,0.0,0.0);
    Array<Face> aof;
    Array<Vertex> aov;

    int verbose = 0;

    pi = 4.0 * atan(1.0);

    // Compute Amixed 
	switch(m_DiscreteType) {
        case ModDCO:       // Use modified method for obtuse triangles
            Amixed = m_Param.VertexArea(in_vertex,MCMeshSubset::MODIFIED);
            break;
        case DCO:
        default:         // Use 1/3 area for obtuse triangles
			Amixed = m_Param.VertexArea(in_vertex,MCMeshSubset::MIXED);
			break;
	}

    // Compute the component of each face 
    aof = m_Param.VertexFaces(in_vertex);
    TotalTheta = 0.0;
    for( i=0; i<aof.num(); i++ ) {
        ier = m_pMesh.AlphaBeta(aof[i],in_vertex,theta,alpha,beta,t,a,b);
      
        // Sum the angles 
        TotalTheta += theta;
    }

    
    aov = m_pMesh.VertexVertices(in_vertex);
    for( i=0; i<aov.num(); i++ ) {
        localEdge = aov[i]->GetLoc() - in_vertex->GetLoc();
        cotAlphaBeta = m_pMesh.CotAlphaBeta(in_vertex, aov[i]);
        localEdge *= cotAlphaBeta;
        kNormal += localEdge;
        
        if( verbose != 0 ) {
            printf("i=%d, cotAlphaBeta=%lf, Edge=(%lf,%lf,%lf)\n",
                i, cotAlphaBeta, localEdge[0], localEdge[1], localEdge[2] );
        }
    }
/*
   // Add correction for boundary vertices 
   if( NumBoundaries( *aopVs[iPoint] ) == 1 ) {
      BoundaryProject( *aopVs[iPoint], TotalAngle, corr );

      if( verbose != 0 ) {
         printf("i=%d, v1=(%f, %f, %f), kn=(%f, %f, %f), corr=(%f, %f, %f)\n",
                iPoint,              T.getVertex(id )[0],
                T.getVertex(id )[1], T.getVertex(id )[2],
                kn[0], kn[1], kn[2], corr[0], corr[1], corr[2] );
      }

      for( k=0; k<3; k++ ) {
         kn[k] = kn[k] + corr[k];
      }
   } else {
*/
      TotalAngle = 2.0 * pi;
/*
   }
*/

    kNormal /= 2.0 * Amixed;

    // Compute the sign relative to outward pointing normal 
    N = m_Param.Nref();
    DotProduct = kNormal[0]*N[0] + kNormal[1]*N[1] + kNormal[2]*N[2];
    factor = ( DotProduct < 0.0 ) ? 1.0 : -1.0;

    // Compute the scalar values 
    kbar = 0.5 * sqrt( kNormal[0]*kNormal[0] 
                     + kNormal[1]*kNormal[1] 
                     + kNormal[2]*kNormal[2] ) * factor;
    kg = ( TotalAngle - TotalTheta ) / Amixed;
    out_point.setKgKbar(kg,kbar);

	N = kNormal;
	N.Normalize();
	N *= -factor;

	ier = calcDCOdirections(in_vertex->GetLoc(), N, aov, e1, e2);
	out_point.setNormal(N);
	out_point.setMaxMinVec(e1,e2);

    if( verbose != 0 ) {
        FILE *out;
        out = fopen("discrete.dat","a");
        out_point.dump(out);
        fclose(out);
    }

    return 0;
}

int
MCDiscreteOperator::calcDCOdirections(const R3Pt &P, const R3Vec &N,
									  const Array<Vertex> &aov,
									  R3Vec &e1, R3Vec &e2)
{
    int i, nv, axis;
    double A, B, C, Vmag, d1, d2, k;

    R3Pt Q;

    R3Vec V;
    R3Vec v1;
    R3Vec v2;
    R3Vec T1;
    R3Vec T2;
	R3Vec Mag;

	R2Vec t1;
	R2Vec t2;

    // Get reference vectors in the tangent plane
	Mag[0] = N[0]*N[0];
	Mag[1] = N[1]*N[1];
	Mag[2] = N[2]*N[2];
	axis = 0;
	if( Mag[0]    > Mag[1] ) axis = 1;
	if( Mag[axis] > Mag[2] ) axis = 2;

	T1[0]    = 0.0;
	T1[1]    = 0.0;
	T1[2]    = 0.0;
	T1[axis] = 1.0;

	T2[0] = N[1]*T1[2] - N[2]*T1[1];
	T2[1] = N[2]*T1[0] - N[0]*T1[2];
	T2[2] = N[0]*T1[1] - N[1]*T1[0];
	T2.Normalize();

	T1[0] = T2[1]*N[2] - T2[2]*N[1];
	T1[1] = T2[2]*N[0] - T2[0]*N[2];
	T1[2] = T2[0]*N[1] - T2[1]*N[0];
	T1.Normalize();

	// Setup least square problem
    nv = aov.num();
    FITTools_LS prob_ls(nv, 3, 1);

	// Loop of each adjacent edge
    for( i=0; i<nv; i++ ) {
        Q = aov[i]->GetLoc();
		V = Q - P;
		Vmag = V.Normalize();
		if( Vmag == 0.0 ) return -1;

		d1 = V[0]*T1[0] + V[1]*T1[1] + V[2]*T1[2];
        d2 = V[0]*T2[0] + V[1]*T2[1] + V[2]*T2[2];

		k = 2.0*(V[0]*N[0] + V[1]*N[1] + V[2]*N[2])/Vmag;

        prob_ls.Desired_clapack( i  , 0 ) = d1*d1;
        prob_ls.Desired_clapack( i  , 1 ) = d1*d2*2.0;
        prob_ls.Desired_clapack( i  , 2 ) = d2*d2;
        prob_ls.Rhs_clapack( i, 0 ) = k;
    }

    // Do the least squares fit 
    if( prob_ls.Solve_clapack() == FALSE ) {
        printf("ERROR - Solving Least Square problem\n" );;
        prob_ls.Print_clapack( cout, FALSE );
    }

    A = prob_ls.Solution_clapack( 0, 0 );
    B = prob_ls.Solution_clapack( 1, 0 );
    C = prob_ls.Solution_clapack( 2, 0 );

    const R2Matrix M( R2Vec( A, B ), R2Vec( B, C ) );
    double eig1, eig2;
    M.EigenReal( eig1, eig2, t1, t2 );
	t1.Normalize();
	t2.Normalize();

	e1[0] = t1[0]*T1[0] + t1[1]*T2[0];
	e1[1] = t1[0]*T1[1] + t1[1]*T2[1];
	e1[2] = t1[0]*T1[2] + t1[1]*T2[2];
	e1.Normalize();

	e2[0] = t2[0]*T1[0] + t2[1]*T2[0];
	e2[1] = t2[0]*T1[1] + t2[1]*T2[1];
	e2[2] = t2[0]*T1[2] + t2[1]*T2[2];
	e2.Normalize();

    return 0;
}

int
MCDiscreteOperator::calcANC(const Vertex &in_vertex, MCPoint &out_point)
{
    int i, nv;
    double A, B, C, D, E, F, G, k1, k2, factor, vsign;
    R3Pt P;
    R3Vec N;
    R3Pt Q;
    R3Vec V;
    R3Pt Qloc;
    R3Vec Vloc;
    R3Vec v1;
    R3Vec v2;
	R3Vec Nref;

    Array<Vertex> aov;
    MCTransform tr;

    int verbose = 0;
	factor = 1.0;
	Nref = in_vertex->GetNorm();

    P = in_vertex->GetLoc();
    switch(m_DiscreteType) {
        case ANCe:       // Use the exact normals stored with the Vertex
            N = in_vertex->GetNorm();

            // For a sphere we can provide exact normals
            //N[0] = P[0];
            //N[1] = P[1];
            //N[2] = P[2];
            //N.Normalize();
            break;
        case ANC:
        default:         // Compute the normals
            m_Param.CalculateNormal(in_vertex, MCMeshSubset::ANGLE, N);
    }

	if( N[0]*Nref[0] + N[1]*Nref[1] + N[2]*Nref[2] < 0.0 ) factor = -1.0;

    tr.setTransform(P,N);

    aov = m_pMesh.VertexVertices(in_vertex);
    nv = aov.num();

    FITTools_LS prob_ls(3*nv, 7, 1);

    for( i=0; i<nv; i++ ) {
        Q = aov[i]->GetLoc();
        switch(m_DiscreteType) {
            case ANCe:       // Use the exact normals stored with the Vertex
                V = aov[i]->GetNorm();

                // For a sphere we can provide exact normals
                //V[0] = Q[0];
                //V[1] = Q[1];
                //V[2] = Q[2];
                //V.Normalize();
                break;
            case ANC:
            default:         // Compute the normals
                m_Param.CalculateNormal(aov[i], MCMeshSubset::ANGLE, V);
        }
        tr.toLocal(Q,V,Qloc,Vloc);
        
        prob_ls.Desired_clapack( 3*i  , 0 ) = 0.5 * Qloc[0] * Qloc[0];
        prob_ls.Desired_clapack( 3*i  , 1 ) = Qloc[0] * Qloc[1];
        prob_ls.Desired_clapack( 3*i  , 2 ) = 0.5 * Qloc[1] * Qloc[1];
        prob_ls.Desired_clapack( 3*i  , 3 ) = Qloc[0] * Qloc[0] * Qloc[0];
        prob_ls.Desired_clapack( 3*i  , 4 ) = Qloc[0] * Qloc[0] * Qloc[1];
        prob_ls.Desired_clapack( 3*i  , 5 ) = Qloc[0] * Qloc[1] * Qloc[1];
        prob_ls.Desired_clapack( 3*i  , 6 ) = Qloc[1] * Qloc[1] * Qloc[1];
        prob_ls.Rhs_clapack( 3*i, 0 ) = Qloc[2];

        prob_ls.Desired_clapack( 3*i+1, 0 ) = Qloc[0];
        prob_ls.Desired_clapack( 3*i+1, 1 ) = Qloc[1];
        prob_ls.Desired_clapack( 3*i+1, 2 ) = 0.0;
        prob_ls.Desired_clapack( 3*i+1, 3 ) = 3.0 * Qloc[0] * Qloc[0];
        prob_ls.Desired_clapack( 3*i+1, 4 ) = 2.0 * Qloc[0] * Qloc[1];
        prob_ls.Desired_clapack( 3*i+1, 5 ) = Qloc[1] * Qloc[1];
        prob_ls.Desired_clapack( 3*i+1, 6 ) = 0.0;
        prob_ls.Rhs_clapack( 3*i+1, 0 ) = -Vloc[0] / Vloc[2];

        prob_ls.Desired_clapack( 3*i+2, 0 ) = 0.0;
        prob_ls.Desired_clapack( 3*i+2, 1 ) = Qloc[0];
        prob_ls.Desired_clapack( 3*i+2, 2 ) = Qloc[1];
        prob_ls.Desired_clapack( 3*i+2, 3 ) = 0.0;
        prob_ls.Desired_clapack( 3*i+2, 4 ) = Qloc[0] * Qloc[0];
        prob_ls.Desired_clapack( 3*i+2, 5 ) = 2.0 * Qloc[0] * Qloc[1];
        prob_ls.Desired_clapack( 3*i+2, 6 ) = 3.0 * Qloc[1] * Qloc[1];
        prob_ls.Rhs_clapack( 3*i+2, 0 ) = -Vloc[1] / Vloc[2];
    }

    // Do the least squares fit 
    if( prob_ls.Solve_clapack() == FALSE ) {
        printf("ERROR - Solving Least Square problem\n" );;
        prob_ls.Print_clapack( cout, FALSE );
    }

    A = prob_ls.Solution_clapack( 0, 0 );
    B = prob_ls.Solution_clapack( 1, 0 );
    C = prob_ls.Solution_clapack( 2, 0 );
    D = prob_ls.Solution_clapack( 3, 0 );
    E = prob_ls.Solution_clapack( 4, 0 );
    F = prob_ls.Solution_clapack( 5, 0 );
    G = prob_ls.Solution_clapack( 6, 0 );

    if( verbose != 0 ) {
        printf("A= %lf, B= %lf, C= %lf\n", A, B, C );
        printf("D= %lf, E= %lf, F= %lf, G= %lf\n", D, E, F, G );
    }

    // Compute the curvature 
    tr.Weingarten( A, B, C, k1, k2, v1, v2 );

	tr.fromLocal(v1);
	tr.fromLocal(v2);

	if( factor < 0.0 ) {
		k1 = -k1;
		k2 = -k2;
	}

	if( k1 < k2 ) {
		out_point.setMaxMin(k2, k1);
		out_point.setMaxMinVec(v2, v1);
	} else {
		out_point.setMaxMin(k1, k2);
		out_point.setMaxMinVec(v1, v2);
	}

	V = R3Vec(v1[1]*v2[2] - v1[2]*v2[1],
		      v1[2]*v2[0] - v1[0]*v2[2],
		      v1[0]*v2[1] - v1[1]*v2[0]);
	V.Normalize();

	vsign = V[0]*N[0] + V[1]*N[1] + V[2]*N[2];
	if( vsign < 0.0 ) V *= -1.0;

    out_point.setNormal(V);

    return 0;
}

int
MCDiscreteOperator::calcIEV(const Vertex &in_vertex, MCPoint &out_point)
{
    R3Vec N;
    R3Vec localEdge;
    R3Vec kNormal = R3Vec(0.0,0.0,0.0);
    Array<Face> aof;
    Array<Vertex> aov;

    int j, id, id1, id2;
    int ne;
    double Atot, DVmagsq, Kij, Wij, w1mag, w2mag, ka, kb, k1, k2, theta;

    R3Pt O, P;
    R3Vec DV, Tij, Tt, W, Wt, w1, w2, T1, T2, Tp1, Tp2;
   
    R3Matrix NI;
    R3Matrix NN;
    R3Matrix M;
    R3Matrix WW;
    R3Matrix Q;
    R3Matrix QMQ;
    R2Matrix submatrix;

    Array<Edge> aoe;
    Array<Vertex> aopVs;
    Face f1, f2;
    FILE *log = NULL;

    //int verbose = 0;

    m_Param.CalculateNormal(in_vertex, MCMeshSubset::ANGLE, N);
   
    NI.MakeIdentity();
    NN = OuterProduct(N, N);
    NI = NI - NN;

    aoe = m_pMesh.VertexEdges( in_vertex );
    ne = aoe.num();
    O = in_vertex->GetLoc();

    // Compute Atot 

    Atot = 0.0;
    for( j=0; j<ne; j++ ) {
        f1 = m_pMesh.EdgeFace1(aoe[j]);
        f2 = m_pMesh.EdgeFace2(aoe[j]);
        if( f1 != NULL ) {
            Atot += m_Param.FaceArea(f1);
        }
        if( f2 != NULL ) {
            Atot += m_Param.FaceArea(f2);
        }
    }

    // Get contribution from each edge 

    M = R3Matrix( R3Vec(0,0,0), R3Vec(0,0,0), R3Vec(0,0,0) );

    id = in_vertex->IndexId();
    for( j=0; j<ne; j++ ) {
        id1 = m_pMesh.EdgeVertex1( aoe[j] )->IndexId();
        id2 = m_pMesh.EdgeVertex2( aoe[j] )->IndexId();
        if( id2 == id ) {
            P = m_pMesh.EdgeVertex1( aoe[j] )->GetLoc();
        } else {
            P = m_pMesh.EdgeVertex2( aoe[j] )->GetLoc();
        }

        DV = P - O;
        //DV[0] = P[0] - O[0];
        //DV[1] = P[1] - O[1];
        //DV[2] = P[2] - O[2];
        DVmagsq = DV[0]*DV[0] + DV[1]*DV[1] + DV[2]*DV[2];

        // Compute the projection to the tangent plane 
        Tij = NI * DV;
        Tij.Normalize();
        //mag = sqrt( Tij[0]*Tij[0] + Tij[1]*Tij[1] + Tij[2]*Tij[2] );
        //Tij[0] /= mag;
        //Tij[1] /= mag;
        //Tij[2] /= mag;

        // Compute the local curvature 
        Kij = 2.0 * ( N[0]*DV[0] + N[1]*DV[1] + N[2]*DV[2] ) / DVmagsq;

        // Compute the weight 
        Wij = 0.0;
        f1 = m_pMesh.EdgeFace1( aoe[j] );
        f2 = m_pMesh.EdgeFace2( aoe[j] );
        if( f1 != NULL ) {
            Wij += m_Param.FaceArea(f1);
        }
        if( f2 != NULL ) {
            Wij += m_Param.FaceArea(f2);
        }
        Wij /= Atot;

        // Form the M matrix 
        Tt[0] = Kij * Wij * Tij[0];
        Tt[1] = Kij * Wij * Tij[1];
        Tt[2] = Kij * Wij * Tij[2];

        M = M + OuterProduct( Tij, Tt );
    }

    w1[0] = 1.0 + N[0];
    w1[1] = 0.0 + N[1];
    w1[2] = 0.0 + N[2];
    w2[0] = 1.0 - N[0];
    w2[1] = 0.0 - N[1];
    w2[2] = 0.0 - N[2];
    w1mag = sqrt( w1[0]*w1[0] + w1[1]*w1[1] + w1[2]*w1[2] );
    w2mag = sqrt( w2[0]*w2[0] + w2[1]*w2[1] + w2[2]*w2[2] );
    if( w1mag > w2mag ) {
        W[0] = w1[0]/w1mag;
        W[1] = w1[1]/w1mag;
        W[2] = w1[2]/w1mag;
    } else {
        W[0] = w2[0]/w2mag;
        W[1] = w2[1]/w2mag;
        W[2] = w2[2]/w2mag;
    }
    Wt[0] = 2.0 * W[0];
    Wt[1] = 2.0 * W[1];
    Wt[2] = 2.0 * W[2];

    WW = OuterProduct( W, Wt );

    Q.MakeIdentity();
    Q = Q - WW;

    for ( int i = 0; i < 3; i++ ) {
	    Tp1[i] = Q(i,1);
	    Tp2[i] = Q(i,2);
    }

    QMQ = Q.Transpose() * M * Q;

    for ( int iI = 0; iI < 2; iI++ ) {
        for ( int iJ = 0; iJ < 2; iJ++ ) {
            submatrix(iI, iJ) = QMQ( iI+1, iJ+1 );
        }
    }
    R2Vec vec1, vec2;
    if ( submatrix.EigenReal( ka, kb, vec1, vec2 ) ) {
        k1 = 3.0 * ka - kb;
        k2 = 3.0 * kb - ka;
    } else {
        k1 = k2 = 0.0;
    }

	//Tp1 = M.column(1);
	//Tp2 = M.column(2);
	theta = submatrix.Givens();


	T1[0] = cos(theta) * Tp1[0] - sin(theta) * Tp2[0];
	T1[1] = cos(theta) * Tp1[1] - sin(theta) * Tp2[1];
	T1[2] = cos(theta) * Tp1[2] - sin(theta) * Tp2[2];
	T1.Normalize();

	T2[0] = sin(theta) * Tp1[0] + cos(theta) * Tp2[0];
	T2[1] = sin(theta) * Tp1[1] + cos(theta) * Tp2[1];
	T2[2] = sin(theta) * Tp1[2] + cos(theta) * Tp2[2];
	T2.Normalize();

    // Reverse sign of k1, k2 to make consistent with other metrics 
    //out_point.setMaxMin(-k1,-k2);
	out_point.setNormal(N);
	if( k1 < k2 ) {
		out_point.setMaxMin(k2,k1);
		out_point.setMaxMinVec(T1, T2);
	} else {
		out_point.setMaxMin(k1,k2);
		out_point.setMaxMinVec(T2, T1);
	}

    if( log != NULL ) fclose(log);

    return 0;
}

int
MCDiscreteOperator::calcHST(const Vertex &in_vertex, MCPoint &out_point)
{
    R3Vec N;
    R3Vec localEdge;
    R3Vec kNormal = R3Vec(0.0,0.0,0.0);
    Array<Face> aof;
    Array<Vertex> aov;

    int j, id, id1, id2;
    int ne;
    double Atot, DVmagsq, Kij, Wij, w1mag, w2mag, ka, kb, k1, k2, theta, Wtot, d;

    R3Pt O, P;
    R3Vec DV, Tij, Tt, W, Wt, w1, w2, T1, T2, Tp1, Tp2;
   
    R3Matrix NI;
    R3Matrix NN;
    R3Matrix M;
    R3Matrix WW;
    R3Matrix Q;
    R3Matrix QMQ;
    R2Matrix submatrix;

    Array<Edge> aoe;
    Array<Vertex> aopVs;
    Face f1, f2;
    FILE *log = NULL;

    //int verbose = 0;

    m_Param.CalculateNormal(in_vertex, MCMeshSubset::ANGLE, N);
   
    NI.MakeIdentity();
    NN = OuterProduct(N,N);
    NI = NI - NN;

    aoe = m_pMesh.VertexEdges( in_vertex );
    ne = aoe.num();
    O = in_vertex->GetLoc();

    // Compute Atot 

    Atot = 0.0;
    for( j=0; j<ne; j++ ) {
        f1 = m_pMesh.EdgeFace1(aoe[j]);
        f2 = m_pMesh.EdgeFace2(aoe[j]);
        if( f1 != NULL ) {
            Atot += m_Param.FaceArea(f1);
        }
        if( f2 != NULL ) {
            Atot += m_Param.FaceArea(f2);
        }
    }

	// Compute total weight
	Wtot = 0.0;
    id = in_vertex->IndexId();
    for( j=0; j<ne; j++ ) {
        id1 = m_pMesh.EdgeVertex1( aoe[j] )->IndexId();
        id2 = m_pMesh.EdgeVertex2( aoe[j] )->IndexId();
        if( id2 == id ) {
            P = m_pMesh.EdgeVertex1( aoe[j] )->GetLoc();
        } else {
            P = m_pMesh.EdgeVertex2( aoe[j] )->GetLoc();
        }

        DV = P - O;
		d = sqrt(DV[0]*DV[0] + DV[1]*DV[1] + DV[2]*DV[2]);
		if( d != 0.0 ) Wtot += 1.0/d;
	}

    // Get contribution from each edge 

    M = R3Matrix( R3Vec(0,0,0), R3Vec(0,0,0), R3Vec(0,0,0) );

    id = in_vertex->IndexId();
    for( j=0; j<ne; j++ ) {
        id1 = m_pMesh.EdgeVertex1( aoe[j] )->IndexId();
        id2 = m_pMesh.EdgeVertex2( aoe[j] )->IndexId();
        if( id2 == id ) {
            P = m_pMesh.EdgeVertex1( aoe[j] )->GetLoc();
        } else {
            P = m_pMesh.EdgeVertex2( aoe[j] )->GetLoc();
        }

        DV = P - O;
        //DV[0] = P[0] - O[0];
        //DV[1] = P[1] - O[1];
        //DV[2] = P[2] - O[2];
        DVmagsq = DV[0]*DV[0] + DV[1]*DV[1] + DV[2]*DV[2];

        // Compute the projection to the tangent plane 
        Tij = NI * DV;
        Tij.Normalize();
        //mag = sqrt( Tij[0]*Tij[0] + Tij[1]*Tij[1] + Tij[2]*Tij[2] );
        //Tij[0] /= mag;
        //Tij[1] /= mag;
        //Tij[2] /= mag;

        // Compute the local curvature 
        Kij = 2.0 * ( N[0]*DV[0] + N[1]*DV[1] + N[2]*DV[2] ) / DVmagsq;

        // Compute the weight
        d = sqrt(DVmagsq);
		if( d != 0.0 ) {
			Wij = 1.0 / (d*Wtot);
		} else {
			Wij = 0.0;
		}
		/*
		Wij = 0.0;
        f1 = m_pMesh.EdgeFace1( aoe[j] );
        f2 = m_pMesh.EdgeFace2( aoe[j] );
        if( f1 != NULL ) {
            Wij += m_Param.FaceArea(f1);
        }
        if( f2 != NULL ) {
            Wij += m_Param.FaceArea(f2);
        }
        Wij /= Atot;
		*/

        // Form the M matrix 
        Tt[0] = Kij * Wij * Tij[0];
        Tt[1] = Kij * Wij * Tij[1];
        Tt[2] = Kij * Wij * Tij[2];

        M = M + OuterProduct( Tij, Tt );
    }

    w1[0] = 1.0 + N[0];
    w1[1] = 0.0 + N[1];
    w1[2] = 0.0 + N[2];
    w2[0] = 1.0 - N[0];
    w2[1] = 0.0 - N[1];
    w2[2] = 0.0 - N[2];
    w1mag = sqrt( w1[0]*w1[0] + w1[1]*w1[1] + w1[2]*w1[2] );
    w2mag = sqrt( w2[0]*w2[0] + w2[1]*w2[1] + w2[2]*w2[2] );
    if( w1mag > w2mag ) {
        W[0] = w1[0]/w1mag;
        W[1] = w1[1]/w1mag;
        W[2] = w1[2]/w1mag;
    } else {
        W[0] = w2[0]/w2mag;
        W[1] = w2[1]/w2mag;
        W[2] = w2[2]/w2mag;
    }
    Wt[0] = 2.0 * W[0];
    Wt[1] = 2.0 * W[1];
    Wt[2] = 2.0 * W[2];

    WW = OuterProduct( W, Wt );

    Q.MakeIdentity();
    Q = Q - WW;

    for ( int i = 0; i < 3; i++ ) {
	    Tp1[i] = Q(i,1);
	    Tp2[i] = Q(i,2);
    }

    QMQ = Q.Transpose() * M * Q;

    for ( int iI = 0; iI < 2; iI++ ) {
        for ( int iJ = 0; iJ < 2; iJ++ ) {
            submatrix(iI, iJ) = QMQ( iI+1, iJ+1 );
        }
    }

    R2Vec vec1, vec2;
    if ( submatrix.EigenReal( ka, kb, vec1, vec2 ) ) {
        k1 = 3.0 * ka - kb;
        k2 = 3.0 * kb - ka;
    } else {
        k1 = k2 = 0.0;
    }

	theta = submatrix.Givens();

	T1[0] = cos(theta) * Tp1[0] - sin(theta) * Tp2[0];
	T1[1] = cos(theta) * Tp1[1] - sin(theta) * Tp2[1];
	T1[2] = cos(theta) * Tp1[2] - sin(theta) * Tp2[2];
	T1.Normalize();

	T2[0] = sin(theta) * Tp1[0] + cos(theta) * Tp2[0];
	T2[1] = sin(theta) * Tp1[1] + cos(theta) * Tp2[1];
	T2[2] = sin(theta) * Tp1[2] + cos(theta) * Tp2[2];
	T2.Normalize();

	out_point.setNormal(N);
	if( k1 < k2 ) {
		out_point.setMaxMin(k2,k1);
		out_point.setMaxMinVec(T1, T2);
	} else {
		out_point.setMaxMin(k1,k2);
		out_point.setMaxMinVec(T2, T1);
	}

    if( log != NULL ) fclose(log);

    return 0;
}

int
MCDiscreteOperator::calcDGM(const Vertex &in_vertex, MCPoint &out_point)
{
	// Curvature based on the differential of the normal Gauss map
    int ier, i, k, k1, k2, k3;
    double a, b, d1, d2, d3, kg, kbar, factor;
	double dNx, dNy, dNz;
	double d1x, d1y, d1z, d2x, d2y, d2z, dg1, dg2, wt, wtSum;
	double a11, a12, a21, a22, b11, b12, b21, b22, det;
    R3Vec V, V1, V2, N, N1, N2, N3, e1, e2;
    R3Vec localEdge, dN1, dN2, dN3;
    R3Vec kNormal = R3Vec(0.0,0.0,0.0);
	R3Pt P, P1, P2, P3;
    Array<Face> aof;
    Array<Vertex> aov;

    int verbose = 0;

    // Initialize variables

	factor = -1.0;
	wtSum = 0.0;
	for( k=0; k<3; k++ ) {
		dN1[k] = 0.0;
		dN2[k] = 0.0;
		dN3[k] = 0.0;
	}
	P = in_vertex->GetLoc();

	// For each face adjacent to the vertex

    aof = m_Param.VertexFaces(in_vertex);
	for( i=0; i<aof.num(); i++ ) {
		aov = m_pMesh.FaceVertices(aof[i]);
		if( aov[0] == in_vertex ) {
			k1 = 0;
			k2 = 1;
			k3 = 2;
		} else {
			if( aov[1] == in_vertex ) {
				k1 = 1;
				k2 = 2;
				k3 = 0;
			} else {
				k1 = 2;
				k2 = 0;
				k3 = 1;
			}
		}

		P1 = aov[k1]->GetLoc();
		P2 = aov[k2]->GetLoc();
		P3 = aov[k3]->GetLoc();

		ier = m_Param.CalculateNormal(aov[k1],MCMeshSubset::CENTROID, N1);
		if( ier != 0 ) return ier;
		ier = m_Param.CalculateNormal(aov[k2],MCMeshSubset::CENTROID, N2);
		if( ier != 0 ) return ier;
		ier = m_Param.CalculateNormal(aov[k3],MCMeshSubset::CENTROID, N3);
		if( ier != 0 ) return ier;

		for( k=0; k<3; k++ ) {
			N1[k] = factor*N1[k];
			N2[k] = factor*N2[k];
			N3[k] = factor*N3[k];
		}

		if( verbose == 2 ) {
			printf("p1=(%lf,%lf,%lf), n1=(%lf,%lf,%lf)\n", 
					P1[0], P1[1], P1[2], N1[0], N1[1], N1[2]); 
			printf("p2=(%lf,%lf,%lf), n2=(%lf,%lf,%lf)\n", 
					P2[0], P2[1], P2[2], N2[0], N2[1], N2[2]); 
			printf("p3=(%lf,%lf,%lf), n3=(%lf,%lf,%lf)\n", 
					P3[0], P3[1], P3[2], N3[0], N3[1], N3[2]); 
		}

		d1x = P2[0] - P1[0];
		d1y = P2[1] - P1[1];
		d1z = P2[2] - P1[2];
		d2x = P3[0] - P1[0];
		d2y = P3[1] - P1[1];
		d2z = P3[2] - P1[2];

		a11 = d1x*d1x + d1y*d1y + d1z*d1z; 
		a12 = d1x*d2x + d1y*d2y + d1z*d2z; 
		a21 = a12; 
		a22 = d2x*d2x + d2y*d2y + d2z*d2z;
		det = a11*a22 - a12*a21;
		if( det == 0.0 ) return -1;

		det = 1.0/det;
		b11 =  det*a22;
		b12 = -det*a12;
		b21 = -det*a21;
		b22 =  det*a11;

		ier = m_Param.Centroid(aof[i], aov[k1], P, wt);
		if( ier != 0 ) return ier;
		wtSum += wt;
		
		// For each component
		for( k=0; k<3; k++ ) {
			dg1 = N2[k] - N1[k];
			dg2 = N3[k] - N1[k];
			a = b11 * dg1 + b12 * dg2;
			b = b21 * dg1 + b22 * dg2;
			dNx = a*(P2[0]-P1[0]) + b*(P3[0]-P1[0]);
			dNy = a*(P2[1]-P1[1]) + b*(P3[1]-P1[1]);
			dNz = a*(P2[2]-P1[2]) + b*(P3[2]-P1[2]);
			dN1[k] += wt*dNx;
			dN2[k] += wt*dNy;
			dN3[k] += wt*dNz;
			if( verbose == 2 ) {
				printf("Face %d-%d: %lf, %lf, %lf, wt=%lf\n", 
					    i, k, dNx, dNy, dNz, wt); 
			}
		}
	}
	if( wtSum == 0.0 ) return -1;
	wtSum = 1.0/wtSum;

	for( k=0; k<3; k++ ) {
		dN1[k] *= wtSum;
		dN2[k] *= wtSum;
		dN3[k] *= wtSum;
	}

	// Set up an orthonormal coordinate system

	d1 = N1[0]*N1[0];
	d2 = N1[1]*N1[1];
	d3 = N1[2]*N1[2];
	V = R3Vec(1.0, 0.0, 0.0);
	if( d2 < d1 ) V = R3Vec(0.0, 1.0, 0.0);
	if( d3 < d1 && d3 < d2 ) V = R3Vec(0.0, 0.0, 1.0);

	e1[0] = N1[1]*V[2] - N1[2]*V[1];
	e1[1] = N1[2]*V[0] - N1[0]*V[2];
	e1[2] = N1[0]*V[1] - N1[1]*V[0];
	e1.Normalize();

	e2[0] = N1[1]*e1[2] - N1[2]*e1[1];
	e2[1] = N1[2]*e1[0] - N1[0]*e1[2];
	e2[2] = N1[0]*e1[1] - N1[1]*e1[0];
	e2.Normalize();

	// Get the Weingarten matrix

	V1[0] = dN1[0]*e1[0] + dN2[0]*e1[1] + dN3[0]*e1[2];
	V1[1] = dN1[1]*e1[0] + dN2[1]*e1[1] + dN3[1]*e1[2];
	V1[2] = dN1[2]*e1[0] + dN2[2]*e1[1] + dN3[2]*e1[2];

	V2[0] = dN1[0]*e2[0] + dN2[0]*e2[1] + dN3[0]*e2[2];
	V2[1] = dN1[1]*e2[0] + dN2[1]*e2[1] + dN3[1]*e2[2];
	V2[2] = dN1[2]*e2[0] + dN2[2]*e2[1] + dN3[2]*e2[2];

	a11 = e1[0]*V1[0] + e1[1]*V1[1] + e1[2]*V1[2];
	a12 = e1[0]*V2[0] + e1[1]*V2[1] + e1[2]*V2[2];
	a21 = e2[0]*V1[0] + e2[1]*V1[1] + e2[2]*V1[2];
	a22 = e2[0]*V2[0] + e2[1]*V2[1] + e2[2]*V2[2];

    // Compute the scalar values 
    kbar = 0.5 * (a11 + a22);
    kg = a11*a22 - a12*a21;
    out_point.setKgKbar(kg,kbar);

	out_point.setNormal(N1);
	out_point.setMaxMinVec(e1,e2);

    if( verbose == 1 ) {
        FILE *out;
        out = fopen("GaussMap.dat","a");
        out_point.dump(out);
        fclose(out);
    }

    return 0;
}

int 
MCDiscreteOperator::CalculateFit(const Vertex &in_vertex)
{
    R3Pt X;
    R2Pt U;

    // Create the mesh subset
    m_Param.Create(in_vertex,m_iRings);

    return 0;
}

void 
MCDiscreteOperator::dump(FILE *out)
{
    if( out != NULL ) {
        fprintf(out,"DiscreteOperator: %d\n", m_DiscreteType );
    }
}
