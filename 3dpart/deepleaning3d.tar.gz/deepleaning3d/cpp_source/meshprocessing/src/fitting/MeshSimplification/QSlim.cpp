/*
 *  QSlim.cpp
 *  MeshTools
 *
 *  Created by Cindy Grimm on 6/14/10.
 *  Copyright 2010 Washington University in St. Louis. All rights reserved.
 *
 */

#include <fitting/MeshSimplification_QSlim.H>
#include <utils/Mesh_Intersect.H>
//#include <fitting/FITTools_Least_squares.H>
#include <limits.h>

const bool bVerbose = false;
/** QSlim sometimes collapes faces wrong - this fixes that */
bool MeshSimplification::CheckMesh( PMeshLite &mesh, const bool in_bPatchBigHolesWithVertex, const int in_iMaxHoleToPatch )
{
    Array<Vertex> avDel;
    Array<Face> afDel;
    Array<Edge> aeSplit, aeCheck;
    bool bBoundary = false, bRet = true;
    
    TRACE("Check Mesh: Before vs %d Euler %d fs %d\n", mesh.NumVertices(), mesh.NumVertices() - mesh.NumEdges() + mesh.NumFaces(), mesh.NumFaces() );
    int iBoundaryVsFound = 0, iDelVs = 0, iDelFs = 0, iSplitEs = 0, iBadLocs = 0;
    bool bWhileNotNice = true;
    int iCount = 10;
    while ( bWhileNotNice == true && iCount-- >= 0 ) {
        bWhileNotNice = false;
        iBoundaryVsFound = 0;
        avDel.need(0);
        afDel.need(0);
        aeCheck.need(0);
        aeSplit.need(0);
        ForMeshVertex( mesh.Mesh(), v ) {
            if ( mesh.Degree(v) == 0 ) {
                avDel += v;
                bRet = false;
            } else if ( mesh.IsBoundary(v) ) {
                iBoundaryVsFound++;
                bBoundary = true;
                bRet = false;
                
                if ( !mesh.Mesh().isNice(v) ) {
                    ForVertexEdge( mesh.Mesh(), v, e ) {
                        if ( mesh.IsBoundary(e) ) {
                            afDel += mesh.EdgeFace1( e );
                            afDel += mesh.EdgeFace1( e );
                        }
                    }EndFor;
                    if ( bVerbose ) cout << "Not nice\n";
                } else {
                    ForVertexEdge( mesh.Mesh(), v, e ) {
                        if ( ! mesh.IsBoundary(e) ) {
                            aeCheck += e;
                        }
                    }EndFor;
                }
                if ( mesh.VertexFaces(v).num() == 1 ) {
                    afDel += mesh.VertexFaces(v)[0];
                }
                if ( bVerbose ) {
                    cout << "V " << v->IndexId() << " ";
                    ForVertexEdge( mesh.Mesh(), v, e ) {
                        if ( mesh.IsBoundary( e ) ) {
                            cout << "b" << mesh.EdgeOppositeVertex( e, v )->IndexId() << " ";
                        } else {
                            cout << mesh.EdgeOppositeVertex( e, v )->IndexId() << " ";
                        }
                    }EndFor;
                    cout << "\n";
                    ForVertexFace( mesh.Mesh(), v, f ) {
                        cout << " f " << f->IndexId() << " ";
                        ForFaceVertex( mesh.Mesh(), f, vv ) {
                            cout << vv->IndexId() << " ";
                        }EndFor;
                        cout << "\n";
                    }EndFor;                
                }
            } else if ( mesh.Degree(v) == 2 ) {
                ForVertexFace( mesh.Mesh(), v, f ) {
                    afDel += f;
                }EndFor;                
            } else if ( !mesh.Mesh().isNice(v) ) {
                cerr << "Warning: Not nice vertex\n";
                ForVertexFace( mesh.Mesh(), v, f ) {
                    afDel += f;
                }EndFor;
                /*
                UTILSDotArray dots;
                dots.Add( v->GetLoc(), UTILSColor::RED );
                ForVertexVertex( mesh.Mesh(), v, vv ) {
                    dots.Add( vv->GetLoc(), UTILSColor::GREEN );
                }EndFor;
                dots.Write( WINDataHome("test/badv.txt") );
                 */
            }
            const R3Pt &pt = v->GetLoc();
            for ( int j = 0; j < 3; j++ ) {
                if ( isnan( pt[j] ) || isinf( pt[j] ) ) {
                    R3Pt ptFix( pt );
                    ptFix[j] = 0.0;
                    int iFoundNeigh = 0;
                    ForVertexVertex( mesh.Mesh(), v, vv ) {
                        if (! ( isnan( vv->GetLoc()[j] ) || isinf( vv->GetLoc()[j]) ) ) {
                            iFoundNeigh++;
                            ptFix[j] += vv->GetLoc()[j];
                        }
                    }EndFor;
                    if ( iFoundNeigh < 2 ) {
                        bWhileNotNice = true;
                        cout << "Bad vertex values " << v->IndexId() << " " << pt << "\n";
                    } else {
                        ptFix[j] /= (double) iFoundNeigh;
                        v->SetLoc( ptFix );
                    }
                    iBadLocs++;
                }
            }
        }EndFor;
        for ( int iV = 0; iV < avDel.num(); iV++ ) {
            if ( mesh.Valid( avDel[iV] ) ) {
                iDelVs++;
                mesh.RemoveVertex( avDel[iV] );
            }
        }
        for ( int iF = 0; iF < afDel.num(); iF++ ) {
            if ( afDel[iF] && mesh.Valid( afDel[iF] ) ) {
                iDelFs++;
                bWhileNotNice = true;
                mesh.RemoveFace( afDel[iF] );
            }
        }
        for ( int iE = 0; iE < aeCheck.num(); iE++ ) {
            if ( mesh.Valid( aeCheck[iE] ) ) {
                if ( mesh.IsBoundary( mesh.EdgeVertex1( aeCheck[iE] ) ) && mesh.IsBoundary( mesh.EdgeVertex2( aeCheck[iE] ) ) ) {
                    if ( !aeSplit.contains( aeCheck[iE] ) ) {
                        aeSplit += aeCheck[iE];
                        bWhileNotNice = true;
                        iSplitEs++;
                        bRet = false;
                    }
                }
            }
        }
        for ( int iE = 0; iE < aeSplit.num(); iE++ ) {
            //Vertex v = mesh.AddVertex( Lerp( mesh.EdgeVertex1( aeCheck[iE] )->GetLoc(), mesh.EdgeVertex2( aeCheck[iE] )->GetLoc(), 0.5 ) );
            mesh.Mesh().splitEdge( aeSplit[iE]);
        }
        
        if ( bWhileNotNice == true ) {
            mesh.Renumber();
        }
    }
    TRACE("Found %d boundary vertices, %d vertices with no faces, %d bad faces, split %d edges, %d bad locations\n", iBoundaryVsFound, iDelVs, iDelFs, iSplitEs, iBadLocs );
    if ( bBoundary ) {
        mesh.PatchHoles(in_bPatchBigHolesWithVertex, in_iMaxHoleToPatch);
    }
    if (avDel.num() )
        mesh.Renumber();
    
    PMeshLite meshCopy = mesh;
    meshCopy.GetOneComponent( mesh );
    mesh.Renumber();
    
    if ( meshCopy.NumVertices() != mesh.NumVertices() ) {
        bRet = false;
    }
    
    TRACE("Check mesh: after vs %d Euler %d\n", mesh.NumVertices(), mesh.NumVertices() - mesh.NumEdges() + mesh.NumFaces() );

    return bRet;
}

void MeshSimplification::QSlim( const char *in_strOrigData, 
                                const char *in_strOrigMesh, 
                                const char *in_strOutputMesh, 
                                const bool in_bPatchBigHoles,
                                const double in_dPercAvg, const double in_dPercMax, const int in_iMaxBadPts  )
{
    PMeshLite meshTemp, meshData;
    
    /*
     FITTools_LS oLS(3, 2, 1, true );
    Array< std::pair<int,double> > ai(1);
    ai[0] = std::pair<int,double>(0,1.0);
    oLS.Desired_sparse( 0, ai );
    ai[0] = std::pair<int,double>(1,1.0);
    oLS.Desired_sparse( 1, ai );
    ai[0] = std::pair<int,double>(0,0.5);
    ai += std::pair<int,double>(1,0.5);
    oLS.Desired_sparse( 2, ai );
    oLS.Rhs_sparse( 0, 0 ) = 1.0;
    oLS.Rhs_sparse( 1, 0 ) = 2.0;
    oLS.Rhs_sparse( 2, 0 ) = 3.0;
    VERIFY( oLS.Solve_sparse() );
    cout << oLS.Solution_sparse(0,0) << " "  << oLS.Solution_sparse(1,0) << "\n";
    
    oLS.Resize( 3, 2, 1, false );
    oLS.Desired_clapack( 0, 0 ) = 1.0;
    oLS.Desired_clapack( 1, 1 ) = 1.0;
    oLS.Desired_clapack( 2, 0 ) = 0.5;
    oLS.Desired_clapack( 2, 1 ) = 0.5;
    oLS.Rhs_clapack( 0, 0 ) = 1.0;
    oLS.Rhs_clapack( 1, 0 ) = 2.0;
    oLS.Rhs_clapack( 2, 0 ) = 3.0;
    VERIFY( oLS.Solve_clapack() );
    cout << oLS.Solution_clapack(0,0) << " "  << oLS.Solution_clapack(1,0) << "\n";
     */

    cout << "Reading in original data points " << in_strOrigData << "\n";
    meshData.Read( in_strOrigData );
    const int iNProject = meshData.NumVertices();
    
    cout << "Reading in mesh to simplify " << in_strOrigMesh << "\n";
    meshTemp.Read( in_strOrigMesh );
        
    cout << "Converting any >3 sided faces to triangles\n";
    meshTemp.MakeTriangular();    

    cout << "Fixing any minor mesh topology errors\n";
    if ( !CheckMesh( meshTemp, in_bPatchBigHoles ) ) { CheckMesh( meshTemp, in_bPatchBigHoles ); }

		char tmpdirtmpl[PATH_MAX];
		char *tmpdir;

		sprintf(tmpdirtmpl, "%s/qslim_XXXXXX", g_strDataHome);
		tmpdir = mkdtemp(tmpdirtmpl);

    const string strSMFIn =  tmpdir + string("/QSlimIn.smf"); //( g_strDataHome + string("test/QSlimIn.smf") );
    const string strSMFOut = tmpdir + string("/QSlimOut.iv"); // ( g_strDataHome + string("test/QSlimOut.iv") );
		// cout << "temporary files (in/out): " << strSMFIn << ", " << strSMFOut << "\n";
		
    meshTemp.Write( strSMFIn.c_str() );
    
    R3Pt ptCenter, ptScale;
    ptCenter = meshTemp.GetCenter( ptScale);
    const double dAvgAllowed = in_dPercAvg * (ptScale[0] + ptScale[1] + ptScale[2]) / 3.0;
    const double dMaxAllowed = in_dPercMax * (ptScale[0] + ptScale[1] + ptScale[2]) / 3.0;
    
    cout << "Mesh bounding box: " << ptScale << "  Avg error allowed: " << dAvgAllowed << " Max error allowed: " << dMaxAllowed << " at most " << in_iMaxBadPts << " points\n";
    
    double dAvg = 0.0, dMax = 0.0, dAvgOrig = 0.0;
    int iCountMax = 0;
    string strCmd;
    char strFaces[20];
    int iLower = 1000, iUpper = meshTemp.NumFaces(), iTry = 0, iBadOrig = -1;
    
    bool bDone = false;
    //Array< Array< std::pair<int,double> > > aaiFVs( in_bDoReproject ? iNProject : 0 );
    //Array< R3Vec > avecErr( in_bDoReproject ? iNProject : 0 );
    //boost::dynamic_bitset<> abVertexUsed( in_bDoReproject ? meshTemp.NumVertices() : 0 );
    //Array<int> aiMapVs( in_bDoReproject ? meshTemp.NumVertices() : 0 );
    Face f;
    Array<double> adBary;
    while ( bDone == false ) {
        iTry = (int) ( (iLower + iUpper) / 2.0 );

        if ( iUpper - iLower <= (int) ( 0.05 * (iUpper) ) )
            break;
        
        // Shouldn't really need this, unless the mesh is super simple
        if ( iTry == iUpper ) iTry = iUpper - 100;
        if ( meshTemp.NumVertices() != meshData.NumVertices() && iBadOrig == -1 ) {
            iTry = iUpper;
        } else {
        
            sprintf( strFaces, "%d", iTry );
            strCmd = string("qslim -t ") + strFaces + string(" -M iv -o ") + strSMFOut + " " + strSMFIn;
            cout << "Running " << strCmd << "\n";
            system( strCmd.c_str() );
            
            meshTemp.Read( strSMFOut.c_str() );
            if ( !CheckMesh( meshTemp, in_bPatchBigHoles ) ) { CheckMesh( meshTemp, in_bPatchBigHoles ); }
        }        
        GMeshIntersect meshIntersect( meshTemp.Mesh() );
        dAvg = 0.0;
        dMax = 0.0;
        iCountMax = 0;
        cout << "Checking dist...\n";
        
        int iRow = 0;
        //abVertexUsed.resize( meshTemp.NumVertices(), false );
        ForMeshVertex( meshData.Mesh(), v ) {
            const R3Pt pt = meshIntersect.Closest( v->GetLoc(), f, adBary );
            const double dLen = Length( pt - v->GetLoc() );
            dAvg += dLen;
            if ( dLen > dMaxAllowed ) {
                iCountMax++;
            }
            dMax = WINmax( dMax, dLen );
            
            /*
            if ( in_bDoReproject ) {
                aaiFVs[iRow].need(0);
                int iI = 0;
                ForFaceVertex( meshTemp.Mesh(), f, vInF ) {
                    aaiFVs[iRow] += std::pair<int,double>( vInF->IndexId(), adBary[iI] );
                    abVertexUsed.set( vInF->IndexId() );
                    iI++;
                }EndFor;
                for ( int j = 0; j < 3; j++ ) {
                    avecErr[iRow][j] = v->GetLoc()[j] - pt[j];
                }
            }
             */
            if ( iRow % 10000 == 0 ) {
                cout << ".";
                cout.flush();
            }
            iRow++;
        }EndFor;
        ASSERT( iRow == meshData.NumVertices() );
        
        /*
        if ( in_bDoReproject ) {
            oLS.Resize( meshData.NumVertices(), abVertexUsed.count(), 3, true );
            
            int iColumn = 0;
            for ( int iI = 0; iI < meshTemp.NumVertices(); iI++ ) {
                if ( abVertexUsed[iI] ) {
                    aiMapVs[ iI ] = iColumn;
                    iColumn++;
                } else {
                    aiMapVs[ iI ] = -1;
                }
            }
            for ( int i = 0; i < aaiFVs.num(); i++ ) {
                for ( int j = 0; j < 3; j++ ) {
                    aaiFVs[i][j].first = aiMapVs[ aaiFVs[i][j].first ];
                }
                oLS.Desired_sparse( i, aaiFVs[i] );
                for ( int j = 0; j < 3; j++ ) {
                    oLS.Rhs_sparse( i, j ) = avecErr[i][j];
                    ASSERT( Length( avecErr[i] ) < dMaxAllowed );
                }
            }

            VERIFY( oLS.Solve_sparse() );
            ForMeshVertex( meshTemp.Mesh(), v ) {
                if ( aiMapVs[ v->IndexId() ] != -1 ) {
                    v->SetLoc( v->GetLoc() + R3Vec( oLS.Solution_sparse( aiMapVs[ v->IndexId() ], 0 ), oLS.Solution_sparse( aiMapVs[ v->IndexId() ], 1 ), oLS.Solution_sparse( aiMapVs[ v->IndexId() ], 2 ) ) );
                    cout << v->GetLoc() << "\n";
                }
            } EndFor;
        }
         */
        
        dAvg = dAvg / (double) meshData.NumVertices();
        
        cout << "Upper/lower " << iUpper << " " << iLower << " Try " << iTry << " avg " << dAvg << " of " << dAvgAllowed <<
        " max " << dMax << " of " << dMaxAllowed << " " << iCountMax << " bad orig " << iBadOrig << " avg orig " << dAvgOrig << "\n";
        
        if ( iBadOrig == -1 ) {
            iBadOrig = iCountMax;
            dAvgOrig = dAvg;
            cout << "Original number of bad points: " << iCountMax << " Original average error " << dAvgOrig << "\n";
        } else if ( (dAvg - dAvgOrig) >= dAvgAllowed || (iCountMax - iBadOrig) >= in_iMaxBadPts ) {
            iLower = iTry;
        } else {
            iUpper = iTry;
            meshTemp.Write( strSMFOut.c_str() );
            meshTemp.Write( in_strOutputMesh );
        }
    }
}

void QSlimTarget( const char *in_strOrigData, 
                  PMeshLite &in_meshOrig,
                  const char *in_strOutputMesh, 
                  const bool in_bPatchBigHoles,
                  const int in_iNFaces )
{
    PMeshLite meshData, meshReduced;

    cout << "Reading in original data points " << in_strOrigData << "\n";
    meshData.Read( in_strOrigData );
    const int iNProject = meshData.NumVertices();
    
    
    if ( in_iNFaces >= in_meshOrig.NumFaces() ) {
        cout << "Target faces bigger than number of faces in mesh; not simplifying\n";
    }
    
    cout << "Converting any >3 sided faces to triangles\n";
    in_meshOrig.MakeTriangular();    
    
    cout << "Fixing any minor mesh topology errors\n";
    int iCountFix = 0;
    while ( iCountFix < 5 && !MeshSimplification::CheckMesh( in_meshOrig, in_bPatchBigHoles ) ) { 
        iCountFix++; 
    }
    if ( iCountFix == 5 ) {
        cout << "Input mesh is not topologically correct; bailing\n";
        return;
    }
    

		char tmpdirtmpl[PATH_MAX];
		char *tmpdir;

		sprintf(tmpdirtmpl, "%s/qslim_XXXXXX", g_strDataHome);
		tmpdir = mkdtemp(tmpdirtmpl);

    const string strSMFIn =  tmpdir + string("/QSlimIn.smf"); //( g_strDataHome + string("test/QSlimIn.smf") );
    const string strSMFOut = tmpdir + string("/QSlimOut.iv"); // ( g_strDataHome + string("test/QSlimOut.iv") );
		//cout << "temporary files (in/out):" << strSMFIn << ", " << strSMFOut << "\n";
    in_meshOrig.Write( strSMFIn.c_str() );
    
    R3Pt ptCenter, ptScale;
    ptCenter = in_meshOrig.GetCenter( ptScale);
    const double dBBox = (ptScale[0] + ptScale[1] + ptScale[2]) / 3.0;

    string strCmd;
    char strFaces[20];
    
    bool bIsOk = false;
    int iTryLow = in_iNFaces, iTryHigh = in_meshOrig.NumFaces(), iTry = in_iNFaces;
    while ( bIsOk == false ) {
        sprintf( strFaces, "%d", iTry );
        strCmd = string("qslim -t ") + strFaces + string(" -M iv -o ") + strSMFOut + " " + strSMFIn;
        cout << "Running " << strCmd << "\n";
        system( strCmd.c_str() );
                
        meshReduced.Read( strSMFOut.c_str() );
        int iCount = 0;
        while ( iCount < 5 && !MeshSimplification::CheckMesh( meshReduced, in_bPatchBigHoles ) ) { iCount++; }
        if ( iCount == 5 ) {
            cout << "Error: Mesh has unfixable topology errors; trying smaller reduction ";
            iTryLow = iTry;
            iTry = (int) ( 0.5 * (iTryLow + iTryHigh) );
            cout << iTryLow << " " << iTry << " " << iTryHigh << "\n";
            if ( iTryHigh - iTryLow < 10 ) {
                iTry = iTryHigh;
                if ( iTryHigh == in_meshOrig.NumFaces() ) {
                    cout << "Never found valid reduction\n";
                    bIsOk = true;
                }
            }
        } else {
            if ( iTry == in_iNFaces || (iTryHigh - iTryLow) < 10 ) {
                bIsOk = true;
            } else {
                iTryHigh = iTry;
                iTry = (int) ( 0.5 * (iTryLow + iTryHigh) );
                cout << " Low " << iTryLow << " try " << iTry << " high " << iTryHigh << " nfaces " << in_meshOrig.NumFaces() << "\n";
            }
        }
    }
    
    meshReduced.Write( in_strOutputMesh );
    cout << "Done writing mesh " << in_strOutputMesh << "\n";

    double dAvg = 0.0, dMax = 0.0;    
    Face f;
    Array<double> adBary;

    GMeshIntersect meshIntersect( meshReduced.Mesh() );

    cout << "Checking dist...\n";
    
    ForMeshVertex( meshData.Mesh(), v ) {
        const R3Pt pt = meshIntersect.Closest( v->GetLoc(), f, adBary );
        const double dLen = Length( pt - v->GetLoc() );
        dAvg += dLen;
        dMax = WINmax( dMax, dLen );
    }EndFor;
    
    dAvg = dAvg / (double) meshData.NumVertices();
        
    cout << " Average error (perc bbox) " << dAvg / dBBox;
    cout << " max " << dMax / dBBox << "\n";
}

void MeshSimplification::QSlimTargetFaces( const char *in_strOrigData, 
                                           const char *in_strOrigMesh, 
                                           const char *in_strOutputMesh, 
                                           const bool in_bPatchBigHoles,
                                           const int in_iNFaces )
{
    cout << "Reading starting mesh " << in_strOrigMesh << "\n";
    PMeshLite meshTemp;
    meshTemp.Read( in_strOrigMesh );
    QSlimTarget( in_strOrigData, meshTemp, in_strOutputMesh, in_bPatchBigHoles, in_iNFaces );
}

void MeshSimplification::QSlimTargetPercentage( const char *in_strOrigData, 
                                                const char *in_strOrigMesh, 
                                                const char *in_strOutputMesh, 
                                                const bool in_bPatchBigHoles,
                                                const double in_dPerc )
{
    cout << "Reading starting mesh " << in_strOrigMesh << "\n";
    PMeshLite meshTemp;
    meshTemp.Read( in_strOrigMesh );
    
    QSlimTarget( in_strOrigData, meshTemp, in_strOutputMesh, in_bPatchBigHoles, (int) ( meshTemp.NumFaces() * in_dPerc ) );
}

