#include "StdAfx.h"
#include <fitting/Fit_LocalNeighbor.H>
#include <utils/Utils_Barys.H>

#ifdef _DEBUG
#define _MY_STATICS 
#else
#define _MY_STATICS static
#endif

/** See if we've done this neighborhood before.
 *  Looks for both orientations
 */
WINbool FITLocalNeighbor::Data::IsSameNeighborhood( const Array<int> &in_ai ) const
{
    if ( in_ai.num() != m_aiNeigh.num() )
        return FALSE;

    // Find starting point
    const int iIndex = in_ai.index( m_aiNeigh[0] );
    WINbool bTried = TRUE;
    for ( int j = 1; j < in_ai.num(); j++ ) {
        if ( in_ai.wrap(j + iIndex) != m_aiNeigh[j] ) {
            bTried = FALSE;
            break;
        }
    }
    // If match forward..
    if ( bTried == TRUE )
        return TRUE;

    // Try reverse order..
    bTried = TRUE;
    for ( FORINT j = 1; j < in_ai.num(); j++ ) {
        if ( in_ai.wrap( iIndex - j ) != m_aiNeigh[j] ) {
            bTried = FALSE;
            break;
        }
    }
    return bTried;
}

/** Barycentric coordinates using cotan formula */
void FITLocalNeighbor::Data::LaplacianWeights( const R2Pt &in_pt, Array<double> &out_adWeights ) const
{
    out_adWeights.need( m_polyPlane.Num_pts() );

    double dSum = 0.0;
    for ( int i = 0; i < m_polyPlane.Num_pts(); i++ ) {
        const R2Pt &ptEnd = m_polyPlane[ i ];
        const R2Pt &ptPrev = m_polyPlane.PtWrap( i-1 );
        const R2Pt &ptNext = m_polyPlane.PtWrap( i+1 );

        // Cotan formula
        const double dAngAlpha = acos( Dot( UnitSafe( in_pt - ptPrev ), UnitSafe( ptEnd - ptPrev ) ) );
        const double dAngBeta = acos( Dot( UnitSafe( in_pt - ptNext ), UnitSafe( ptEnd - ptNext ) ) );

        const double dTanAlpha = tan( dAngAlpha );
        const double dTanBeta = tan( dAngBeta );

        if ( !RNIsZero( dTanAlpha ) && ! RNIsZero( dTanBeta ) ) {
            out_adWeights[ i ] = -( 1.0 / dTanAlpha + 1.0 / dTanBeta );// * Length( in_pt - ptEnd );
        } else {
            out_adWeights[ i ] = 0.0;
        }

        dSum += out_adWeights[ i ];
    }

    ASSERT( !RNIsZero(dSum) );
    for ( FORINT i = 0; i < out_adWeights.num(); i++ ) {
        out_adWeights[i] /= (dSum);
    }
}

/* Barycentric coordinates in Floater's mean-value coordinates */
void FITLocalNeighbor::Data::FloaterWeights( const R2Pt &in_pt, Array<double> &out_adWeights ) const
{
    out_adWeights.need( m_polyPlane.Num_pts() );

    for ( int i = 0; i < out_adWeights.num(); i++ )
        out_adWeights[i] = 0.0;

    // Figure out which triangle the point lies in
    R2Polygon tri(3);
    const double dW = 1.0 / (double) m_polyPlane.Num_pts();
    R3Pt ptBest;
    for ( FORINT i = 0; i < m_polyPlane.Num_pts(); i++ ) {
        tri[0] = m_polyPlane[i];
        WINbool bFound = FALSE;
        double dBest = 1e30;
	    int iBest = 0;
        for (int iK = 0; iK < m_polyPlane.Num_pts() - 1; iK++ ) {
            tri[1] = m_polyPlane.PtWrap(i + iK+1);
            tri[2] = m_polyPlane.PtWrap(i + iK+2);

            const R3Pt ptBary = UTILSBarys::BaryCoords( tri, in_pt );
            if ( ptBary[0] > - 1e-13 && ptBary[1] > - 1e-13 && ptBary[2] > -1e-13 ) {
                bFound = TRUE;

                out_adWeights[i] += ptBary[0] * dW;
                out_adWeights.wrap(i + iK+1) += ptBary[1] * dW;
                out_adWeights.wrap(i + iK+2) += ptBary[2] * dW;
                break;
            } else {
                const double dBarySum = fabs( ptBary[0] ) + fabs( ptBary[1] ) + fabs( ptBary[2] );
                if ( dBarySum < dBest ) {
                    ptBest = ptBary;
                    dBest = dBarySum;
		            iBest = iK;
                }
            }
        }
        if ( bFound == FALSE ) {
            out_adWeights[i] += ptBest[0] * dW;
            out_adWeights.wrap(i + iBest+1) += ptBest[1] * dW;
            out_adWeights.wrap(i + iBest+2) += ptBest[2] * dW;
        }

    }
}


void FITLocalNeighbor::Data::BaryCoords( const BaryType &in_type, const R2Pt &in_pt, Array<double> &out_adWeights ) const
{
    switch( in_type ) {
    case LAPLACIAN : LaplacianWeights( in_pt, out_adWeights ); break;
    case FLOATER : FloaterWeights( in_pt, out_adWeights ); break;
    default : ASSERT(FALSE);
    }
}

/************************************ Validation metrics ****************/

/* 
 * Reproject points with normal and sort radially
 */
WINbool FITLocalNeighbor::Data::IsSameOrder() const
{
   // Check neighborhood is as predicted by normal
    R3Matrix matToXYZ;
    R3Matrix::MatrixVecToVec( matToXYZ, m_vecNorm, R3Vec(0,1,0) );
    const R4Matrix matToOrigin = (R4Matrix) matToXYZ * R4Matrix::Translation( R3Pt(0,0,0) - Pt() );

    _MY_STATICS Array< std::pair<int,double> > s_aiSort( m_aiNeigh.num() );
    _MY_STATICS Array<int> aiNeigh( m_aiNeigh.num() );
    s_aiSort.need( m_aiNeigh.num() );
    aiNeigh.need( m_aiNeigh.num() );
    for ( int i = 0; i < m_aiNeigh.num(); i++ ) {
        const R3Pt ptProj = matToOrigin * LNPt(i);

        s_aiSort[i].first = m_aiNeigh[i];
        s_aiSort[i].second = atan2( ptProj[2], ptProj[0] ) + M_PI;
    } 
    qsort( &s_aiSort[0], s_aiSort.num(), sizeof( std::pair<int,double> ), SortAng );

    for ( FORINT i = 0; i < m_aiNeigh.num(); i++ )
        aiNeigh[i] = s_aiSort[i].first;

    return IsSameNeighborhood( aiNeigh );
}

/* Check that the current normal produces the same orientation.
 * The polygon does not cross itself
 * There are no points within the polygon
 */
WINbool FITLocalNeighbor::Data::IsValid( WINbool &out_bHasInside ) const
{
    if ( IsSameOrder() == FALSE )
        return FALSE;

    // Loop through closest points (skipping neighborhood points)
    // Project point onto tangent plane
    // See if inside by a certain percentage
    if ( GetModelType() != BOUNDARY ) {
        for ( int i = 0; i < SMNum(); i++ ) {
            if ( m_abMe[ i ] ) // Point is in my neighborhood
                continue;

            if ( SMDist(i) > m_dMaxDist ) // Don't check past furthest point in LN
                break;

            const R2Pt &ptProj = SMProjPt(i);
            if ( m_polyPlane.Inside_winding( ptProj ) ) {
                const R2Pt ptBdry = m_polyPlane.ProjectBoundary( ptProj );
                const double dPerc = Length( ptBdry - ptProj ) / Length( ptProj - R2Pt(0,0) );
                if ( dPerc > m_cdInsidePoly ) {
                    //ShowPoly( in_aiClosest );
                    out_bHasInside = TRUE; // Point projects inside
                    return FALSE;
                }
            }
        }
    } else {
        // Check each wedge for inclusion
        _MY_STATICS R2Polygon polyWedge(3);
        polyWedge[0] = R2Pt(0,0);

        // Check the wedges for point inclusion
        for ( int j = 0; j < m_adAngle.num(); j++ ) {
            // Only check edges that are boundary ones
            if ( m_adAngleDiff[j] > m_cdBoundaryAngle )
                continue;

            polyWedge[1] = m_polyPlane[j];
            polyWedge[2] = m_polyPlane.PtWrap(j+1);
            for ( int i = 0; i < SMNum(); i++ ) {
                if ( m_abMe[ i ] ) // Point is in my neighborhood
                    continue;

                if ( SMDist(i) > m_dMaxDist ) // Don't check past furthest point in LN
                    break;

                const R2Pt &ptProj = SMProjPt(i);
                const R3Pt ptBary = UTILSBarys::BaryCoords( polyWedge, ptProj);
                if ( ptBary[0] < 0.0 || ptBary[0] > 1.0 || ptBary[1] < 0.0 || ptBary[1] > 1.0  || ptBary[2] < 0.0 || ptBary[2] > 1.0)
                    continue;

                const R2Pt ptBdry = polyWedge.ProjectBoundary( ptProj );
                const double dPerc = Length( ptBdry - ptProj ) / Length( ptProj - R2Pt(0,0) );
                if ( dPerc > m_cdInsidePoly ) {
                    //ShowPoly( in_aiClosest );
                    out_bHasInside = TRUE; // Point projects inside
                    return FALSE;
                }
            }
        }
        // Check the wedge edges for the boundary for points past the wedge
        for ( FORINT j = 0; j < m_adAngle.num(); j++ ) {
            // Only check edges that are boundary ones
            if ( m_adAngleDiff[j] < m_cdBoundaryAngle )
                continue;

            // The two edges formed by the point and the two endpoints of the wedge
            const R2Vec vecEdge1 = m_polyPlane.PtWrap( j+1 ) - R2Pt(0,0);
            const R2Vec vecNorm1 = UnitSafe( R2Vec( vecEdge1[1], -vecEdge1[0] ) );
            const R2Vec vecEdge2 = m_polyPlane[j] - R2Pt(0,0);
            const R2Vec vecNorm2 = UnitSafe( R2Vec( -vecEdge2[1], vecEdge2[0] ) );

            // Check all points in LN
            for ( int i = 0; i < SMNum(); i++ ) {
                if ( m_abMe[i] )
                    continue;

                // On outside of line 1
                const R2Vec vecToPt = SMProjPt(i) - R2Pt(0,0);
                if ( Dot( vecNorm1, vecToPt ) > 0.0 ) {
                    const double dLen = Length( vecEdge1 );
                    const double dS = Dot( vecToPt, vecEdge1 ) / pow( dLen, 2 );
                    //ShowNeigh( in_sn.m_aiClosest );
                    //ShowPoly( in_sn.m_aiClosest );
                    if ( dS >= 0.0 && dS <= 1.0 ) {
                        out_bHasInside = TRUE;
                        return FALSE;
                    }
                }
                // On outside of line 2
                if ( Dot( vecNorm2, vecToPt ) > 0.0 ) {
                    const double dLen = Length( vecEdge2 );
                    const double dS = Dot( vecToPt, vecEdge2 ) / pow( dLen, 2 );
                    //ShowNeigh( in_sn.m_aiClosest );
                    //ShowPoly( in_sn.m_aiClosest );
                    if ( dS >= 0.0 && dS <= 1.0 ) {
                        out_bHasInside = TRUE;
                        return FALSE;
                    }
                }
            }
        }
    }

    // See if polygon crosses self
    double dS = 0.0, dT = 0.0;
    R2Pt ptOut;
    for ( int i = 0; i < m_polyPlane.Num_pts(); i++ ) {
        if ( GetModelType() == BOUNDARY && m_adAngleDiff[i] > m_cdBoundaryAngle )
            continue;

        const R2Line_seg seg = m_polyPlane.Edge(i);
        for ( int j = i+1; j < m_polyPlane.Num_pts(); j++ ) {
            if ( GetModelType() == BOUNDARY && m_adAngleDiff[j] > m_cdBoundaryAngle )
                continue;

            const R2Line_seg seg2 = m_polyPlane.Edge(j);
            const WINbool bInter = seg.Intersect( seg2, ptOut, dS, dT );
            if ( RNIsZero( dT, 1e-12 ) || RNIsZero( dS, 1e-12 ) )
                continue;

            if ( bInter == TRUE ) {
                //ShowNeigh( in_aiClosest );
                //ShowPoly( in_sn.m_aiClosest );
                return FALSE;
            }
        }
    }

    // Additional check for points inside polygon made by including pt in polygon, 
    // inserted at wedge index
    if ( GetModelType() == BOUNDARY ) {
        // Center point is not in the neighbors
        if ( m_polyPlane.Inside_winding( R2Pt(0,0) ) == FALSE ) {
            _MY_STATICS R2Polygon poly;
            for ( int iE = 0; iE < m_polyPlane.Num_pts(); iE++ ) {
                // Find all boundary wedges
                if ( m_adAngleDiff[iE] < m_cdBoundaryAngle )
                    continue;


                //TRACE("In polygon check %f\n", AngleDiff( m_adAngle[iE], m_adAngle.wrap(iE+1) ) );
                //ShowNeigh( in_sn.m_aiClosest );
               // ShowPoly( in_sn.m_aiClosest );

                // Make a polygon by inserting pt into wedge
                poly = m_polyPlane;
                poly.Insert( R2Pt(0,0), (iE+1)%m_polyPlane.Num_pts() );
                //UTILSDotArray dots;
                //dots.AddPolygon( poly.Pts(), UTILSColor::GREY );
                //dots.Write( WINDataHome("test/polyBdry.txt") );

                // Look for point inside
                for ( int i = 0; i < SMNum(); i++ ) {
                    if ( m_abMe[ i ] )
                        continue;

                    if ( SMDist(i) > m_dMaxDist )
                        break;

                    const R2Pt &ptProj = SMProjPt(i);
                    if ( poly.Inside_winding( ptProj ) ) {
                        const R2Pt ptBdry = m_polyPlane.ProjectBoundary( ptProj );
                        const double dPerc = Length( ptBdry - ptProj ) / Length( ptProj - R2Pt(0,0) );
                        if ( dPerc > m_cdInsidePoly ) {
                            //TRACE("Bad\n");
                            //ShowPoly( in_aiClosest );
                            out_bHasInside = TRUE;
                            return FALSE;
                        }
                    }
                }
            }
        }
    }

    return TRUE;
}

/************************************ Evaluation metrics ****************////

// Look for convex boundaries
double FITLocalNeighbor::Data::IsConvex() const
{
    double dBadConvex = 0.0;
    for ( int i = 0; i < m_polyPlane.Num_pts(); i++ ) {
        const R2Vec vecPrev = UnitSafe( m_polyPlane[i] - m_polyPlane.PtWrap(i-1) );
        const R2Vec vecNext = UnitSafe( m_polyPlane.PtWrap(i+1) - m_polyPlane[i] );
        const double dDot = Dot(vecPrev, vecNext );
        // oriented out or in?
        const double dCross = vecNext[1] * vecPrev[0] - vecNext[0] * vecPrev[1];
        const double dAng = acos( dDot );

        // bigger than pi - figure out how much so
        if ( dCross < 0.0 ) {
            dBadConvex += pow( dAng / M_PI, 2.0 );
        }
    }

    return dBadConvex / (double) m_polyPlane.Num_pts();
}

// See how much angle looks like 2 pi / n
double FITLocalNeighbor::Data::IsEvenAngle() const
{
    const double dAngEven = 2.0 * M_PI / (double) m_adAngle.num();
    double dAngleErr = 0.0;
    for ( int i = 0; i < m_adAngle.num(); i++ ) {
        // zero when angle is correct, 1 when really small, 1 when twice as big
        const double dErrNormalized = ( m_adAngleDiff[i] - dAngEven ) / dAngEven;
        // Discount small variations
        const double dErrAdd = pow( dErrNormalized, 2 );
        dAngleErr += dErrAdd;
    }

    return dAngleErr / (double) m_adAngle.num();
}

// See how much my distance varies from my two neighbors
double FITLocalNeighbor::Data::IsEvenDist() const
{
    const R2Pt ptCenter = m_polyPlane.Centroid();

    double dSumErr = 0.0;
    double dPerc = 0.0;
    for ( int i = 0; i < m_adDist.num(); i ++ ) {
        // Interpolate between left and right points
        const double &dAngLeft = m_adAngleDiff.wrap(i-1);
        const double &dAngRight = m_adAngleDiff[i];
        if ( RNIsZero (dAngLeft + dAngRight ) ) 
            dPerc = 0.5;
        else
            dPerc = dAngLeft / (dAngLeft + dAngRight);

        // Interpolated length
        const double dLen = (1.0 - dPerc) * m_adDist.wrap(i-1) + dPerc * m_adDist.wrap(i+1);
        // Get length difference
        const double dDiff = fabs( dLen - m_adDist[i] );
        // Get (local) estimate of length
        const double dAvg = m_cdPercSelfDist * m_adDist[i] + (1.0 - m_cdPercSelfDist ) * ( m_adDist.wrap(i-1) + m_adDist.wrap(i+1) ) * 0.5;
        // Percentage of Length difference
        dSumErr += pow( dDiff / dAvg, 2.0 );
    }
    dSumErr /= (double) m_adDist.num();

    const double dCenter = Length( ptCenter - R2Pt(0,0) ) / m_dMaxDist;

    return m_cdPercCenterDist * dCenter + (1.0 - m_cdPercCenterDist) * dSumErr;
}


/************************************ unused evaluation metrics ****************/

// Look for points that are within a percentage of the boundary
// Basically looking to see if we've "missed" a point
double FITLocalNeighbor::Data::IsComplete( ) const
{
    double dComplete = 0.0;
    for ( int i = 0; i < SMNum(); i++ ) {
        // Skip points in LN
        if ( m_abMe[i] ) 
            continue;

        // Find which two LN points this one lies between
        const double &dAng = SMProjAngle(i);
        const double &dDist = SMProjLen(i);

        int iAng = 0;
        if ( dAng < m_adAngle[0] || dAng >= m_adAngle.last() ) {
            iAng = m_adAngle.num() - 1;
        } else {
            for ( int j = 0; j < m_adAngle.num() - 1; j++ ) {
                if ( dAng >= m_adAngle[j] && dAng < m_adAngle[j+1] ) {
                    iAng = j;
                    break;
                }
            }
        }

        // Neighboring points
        const double dAngLeft = m_adAngleDiff[iAng];
        const double dAngRight = m_adAngleDiff.wrap(iAng+1);

        const double dDistWeight = ( dAngLeft ) / (dAngLeft + dAngRight);
        const double dDistIdeal = (1.0 - dDistWeight) * m_adDist[iAng] + dDistWeight * m_adDist.wrap(iAng+1);
    
        // See if I'm within a percentage of that distance
        const double dRatio = dDist / dDistIdeal;
        if ( dRatio < 1.1 ) {
            // If so, weight by how close and even the angles are
            const double dLenAdd = (1.1 - dRatio);

            // Goes from 0 to 0.5
            const double dAngPerc = dAngLeft / ( dAngLeft + dAngRight );
            const double dAngAdd = (dAngPerc < 0.5) ? dAngPerc : 1.0 - dAngPerc;

            dComplete += dAngAdd * dLenAdd;
        }
    }

    return dComplete;
}


/// Measure how close barycentric coordinates are to 1/n
double FITLocalNeighbor::Data::IsCentered( const BaryType &in_type ) const
{
    _MY_STATICS Array<double> s_adWeights( m_polyPlane.Num_pts() );

    const double dCenter = 1.0 / (double) m_polyPlane.Num_pts();
    // Get bary coords
    BaryCoords( in_type, R2Pt(0,0), s_adWeights );

    double dCentered = 0.0, dAvgDist = 0.0;;
    R2Pt ptPred(0,0);
    // Weight by what the wedge size is
    for ( int i = 0; i < s_adWeights.num(); i++ ) {
        const double dErr = fabs( s_adWeights[i] - dCenter ) / dCenter;
        dCentered += dErr;
        ptPred[0] += s_adWeights[i] * m_polyPlane[i][0];
        ptPred[1] += s_adWeights[i] * m_polyPlane[i][1];
        dAvgDist += m_adDist[i];
    }
    dAvgDist /= (double) m_adDist.num();

    // How well the coords predict the center point (0,0)
    const double dErrPred = Length( ptPred - R2Pt(0,0) ) / dAvgDist;

    dCentered /= (double) s_adWeights.num();

    return m_cdPercCenterDist * dCentered + (1.0 - m_cdPercCenterDist) * dErrPred;
}

// Don't fit to a particular angle, but instead, look for angles that 
// don't vary too much from the 2 pi / n angle
double FITLocalNeighbor::Data::IsGoodAngle() const
{
    const double dAngEven = 2.0 * M_PI / (double) m_adAngle.num();
    const double dAngMin = 0.1 * dAngEven;
    const double dAngMax = 1.5 * dAngEven;

    double dAngleErr = 0.0;
    for ( int i = 0; i < m_adAngle.num(); i++ ) {
        const double &dAngDiff = m_adAngleDiff[i];

        if ( dAngDiff < dAngMin ) {
            dAngleErr += 1.0 - dAngDiff / dAngMin;
        } else if ( dAngDiff > dAngMax ) {
            dAngleErr += dAngMax / dAngDiff;
        }
    }

    return dAngleErr / (double) m_adAngle.num();
}


