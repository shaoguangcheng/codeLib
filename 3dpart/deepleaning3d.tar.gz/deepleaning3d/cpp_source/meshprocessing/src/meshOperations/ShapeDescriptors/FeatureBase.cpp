/*
 *  FeatureBase.cpp
 *  FeatureFinder
 *
 *  Created by Cindy Grimm on 10/26/10.
 *  Copyright 2010 Washington University in St. Louis. All rights reserved.
 *
 */


#include <meshOperations/SF_FeatureBase.H>
#include <meshOperations/SF_FeatureMeshPointInfo.H>

void FeatureBase::Clear()
{
    for ( int i = 0; i < m_aopPerMeshInfo.size(); i++ ) {
        delete m_aopPerMeshInfo[i];
    }
    m_aopPerMeshInfo.resize(0);
}

void FeatureBase::Add( const int in_iN )
{
    Clear();
    m_aopPerMeshInfo.resize( in_iN );
    for ( int i = 0; i < m_aopPerMeshInfo.size(); i++ ) {
        switch ( m_type ) {
            case POINT : 
                m_aopPerMeshInfo[i] = new FeatureMeshPointInfo;
                break;
            default :
                cout << "Feature type not yet implemented\n";
                break;
        }
    }
}

void FeatureBase::Set( const FeatureType &in_type, const std::string &in_str, const int in_iNMeshes ) 
{ 
    m_strName = in_str;

    if ( m_type != in_type || m_aopPerMeshInfo.size() != in_iNMeshes ) {
        m_type = in_type; 
        Add( in_iNMeshes );
    }
}

FeatureBase::~FeatureBase() 
{
    Clear();
}

void FeatureMeshInfo::Write( ofstream &out ) const
{
    out << m_bComplete << "\n";
}

void FeatureMeshInfo::Read( ifstream &in ) 
{
    in >> m_bComplete;
}

void FeatureBase::Write( ofstream &out ) const
{
    out << "Type ";
    switch ( m_type ) {
        case POINT :
            out << "point ";
            break;
        case LINE :
            out << "line ";
            break;
        case REGION :
            out << "region ";
            break;
        case AXIS :
            out << "axis ";
            break;
        default :
            ASSERT(FALSE);
            cout << "Not recognized\n";
    }
    out << m_strName << " " << m_aopPerMeshInfo.size() << "\n";
    for ( int i = 0; i < m_aopPerMeshInfo.size(); i++ ) {
        m_aopPerMeshInfo[i]->Write( out );
    }
    out << "End\n";
}

void FeatureBase::Read( ifstream &in )
{
    string str;
    in >> str;
    ASSERT( !str.compare("Type") );
    in >> str;
    if ( !str.compare("point") ) {
        m_type = POINT;
    } else if ( !str.compare("line") ) {
        m_type = LINE;
    } else if ( !str.compare("region") ) {
        m_type = REGION;
    } else if ( !str.compare("axis") ) {
        m_type = AXIS;
    } else { 
        cout << "Type " << str << " not recognized\n";
        ASSERT(FALSE);
    }
    in >> m_strName;
    
    int iN = 0;
    in >> iN;
    Add( iN );
    
    for ( int i = 0; i < m_aopPerMeshInfo.size(); i++ ) {
        m_aopPerMeshInfo[i]->Read( in );
    }
    
    in >> str;
    ASSERT( !str.compare("End") );
}

void Write( const Array<FeatureBase *> &in_aop, ofstream &out )
{
    out << in_aop.num() << "\n";
    for ( int i = 0; i < in_aop.num(); i++ ) {
        in_aop[i]->Write(out);
    }
}

void Write( const Array<FeatureBase *> &in_aop, const std::string &in_str )
{
    ofstream out( in_str.c_str(), ios::out );
    Write( in_aop, out );
    out.close();
}

void Read( Array<FeatureBase *> &out_aop, ifstream &in )
{
    for ( int i = 0; i < out_aop.num(); i++ ) {
        delete out_aop[i];
    }
    out_aop.need(0);
    if ( !in.good() ) return;
    
    int iN = 0;
    in >> iN;
    
    out_aop.need(iN);
    for ( int i = 0; i < out_aop.num(); i++ ) {
        out_aop[i] = new FeatureBase;
        out_aop[i]->Read(in);
    }
}

void Read( Array<FeatureBase *> &out_aop, const std::string &in_str )
{
    ifstream in(in_str.c_str(), ios::in);
    
    if ( in.good() ) {
        Read( out_aop, in);
    } else {
        cerr << "Reading feature base: file not good " << in_str << "\n";
    }
    
    in.close();
}
