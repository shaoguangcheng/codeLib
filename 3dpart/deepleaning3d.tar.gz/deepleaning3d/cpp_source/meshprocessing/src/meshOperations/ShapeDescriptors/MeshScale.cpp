/*
 *  MeshScale.cpp
 *  FeatureFinder
 *
 *  Created by Cindy Grimm on 10/6/09.
 *  Copyright 2009 Washington University in St. Louis. All rights reserved.
 *
 */

#include <meshOperations/SD_FileNames.H>
#include <meshOperations/SD_MeshScale.H>

#include <fitting/FITTools_Least_squares.H>


R4Matrix Features::ScaleMesh(PMeshLite& inMesh) {
	//This method rotates a mesh aong its eigenvetors  , translates it about the origin  and scales it between 0 and 1
    
	const R3Pt origin(0.0,0.0,0.0);
	R3Pt center,scale;
	center = inMesh.GetCenter(scale);
    
    const R4Matrix matTrans = R4Matrix::Translation( R3Pt(0,0,0) - center );
    
    const double dScale = 1.0 / WINmax( scale[0], WINmax( scale[1], scale[2] ) );
    const R4Matrix matScale = R4Matrix::Scaling( dScale, dScale, dScale, 1.0 );
    const double dBigger = 1.3;
    R3Matrix matRot( R3Matrix::Identity() );
    
    if ( scale[0] > dBigger * WINmax( scale[1], scale[2] ) ) {
        if ( scale[1] > dBigger * scale[2] ) {
            matRot = R3Matrix::Rotation( 2, M_PI / 2.0 );
            cout << " axis X, Y\n";
        } else if ( scale[2] > dBigger * scale[1] ) {
            matRot = R3Matrix::Rotation( 1, M_PI / 2.0 ) * R3Matrix::Rotation( 2, M_PI / 2.0 );
            cout << " axis X, Z\n";
        } else {
            matRot = R3Matrix::Rotation( 2, M_PI / 2.0 );
            cout << " axis X, neither\n";
        }
    } else if ( scale[2] > dBigger * WINmax( scale[1], scale[0] ) ) {
        if ( scale[0] > dBigger * scale[1] ) {
            matRot = R3Matrix::Rotation( 0, M_PI / 2.0 );
            cout << " axis Z, X\n";
        } else if ( scale[1] > dBigger * scale[0] ) {
            matRot = R3Matrix::Rotation( 1, M_PI / 2.0 ) * R3Matrix::Rotation( 0, M_PI / 2.0 );
            cout << " axis Z, Y\n";
        } else {
            matRot = R3Matrix::Rotation( 0, M_PI / 2.0 );
            cout << " axis Z, neither\n";
        }
    } else if ( scale[1] > dBigger * WINmax( scale[0], scale[2] ) ) {
        if ( scale[0] > dBigger * scale[2] ) {
            cout << " axis Y, X\n";
        } else if ( scale[2] > dBigger * scale[0] ) {
            matRot = R3Matrix::Rotation( 1, M_PI / 2.0 );
            cout << " axis Y, Z\n";
        } else {
            cout << " axis Y, neither\n";
        }
    }
    
    const R4Matrix matTransform = (R4Matrix) matRot * matScale * matTrans;
    inMesh.Transform( matTransform );

	center = inMesh.GetCenter(scale);

    const R4Matrix matTransRecenter = R4Matrix::Translation( R3Pt(0,0,0) - center );
    
    const double dReScale = 1.0 / WINmax( scale[0], WINmax( scale[1], scale[2] ) );
    const R4Matrix matReScale = R4Matrix::Scaling( dReScale, dReScale, dReScale, 1.0 );
    
    inMesh.Transform( matReScale * matTransRecenter );
    const R4Matrix matTransformAgain = matReScale * matTransRecenter * matTransform;
    
    return matTransformAgain;
    
}//end of scaleMesh

using namespace Features::DataSetNames;
using namespace Features::IntermediateStorageNames;

void Features::ScaleMeshAll( const bool in_bRedoAll )
{
    PMeshLite mesh;
    ofstream outMatrix;
    ifstream inMesh;
        
    for ( int i = 0; i < NumDataSets( ); i++ ) {
        for ( int j = 0; j < NumMeshes( (DataSet) i ); j++ ) {
            const string strMesh = g_strSDDataHome + MeshName( (DataSet) i, j );
            const string strScaledMeshName = FullPathName( (DataSet) i, j, normalizedMesh );
            const string strScaledMatrixName = FullPathName( (DataSet) i, j, normalizedMatrix );
            const string strHandFixRotMatrixName = FullPathName( (DataSet) i, j, normalizedMatrix_HandFix );

            R3Matrix matHandFixRot( R3Matrix::Identity() );
            if ( Exists( (DataSet) i, j, normalizedMatrix_HandFix ) ) {                
                cout << " Hand fix matrix exists\n";
                ifstream in( strHandFixRotMatrixName.c_str(), ios::in );
                in >> matHandFixRot;
                in.close();
            }

            const bool bNormalizedMesh = Exists( (DataSet) i, j, normalizedMesh );
            const bool bNormalizedMatrix = Exists( (DataSet) i, j, normalizedMatrix );
            inMesh.open( strMesh.c_str(), ios::in );

            if ( inMesh.good() && ( in_bRedoAll || !bNormalizedMesh || !bNormalizedMatrix ) ) {
                mesh.Read( strMesh.c_str() );
                cout << "Scaling " << strMesh << " ";
                                
                if ( bNormalizedMatrix ) {
                    // Use existing matrix if we have one
                    ifstream inMatrix( strScaledMatrixName.c_str(), ios::in );
                    R4Matrix mat;
                    inMatrix >> mat;
                    mesh.Transform( mat );
                    inMatrix.close();
                } else {
                    const R4Matrix mat = (R4Matrix) matHandFixRot * ScaleMesh( mesh );
                    
                    outMatrix.open( strScaledMatrixName.c_str(), ios::out );
                    outMatrix << mat << "\n";
                    outMatrix.close();
                }
                mesh.Write( strScaledMeshName.c_str() );
            } else if ( !inMesh.good() ) {
                cout << "Mesh " << strMesh << " doesn't exist\n";
            } else if ( bNormalizedMesh ) {
                cout << "Already exists " << strMesh << "\n";
            }
            
            inMesh.close();
            inMesh.clear();
        }
    }
}

