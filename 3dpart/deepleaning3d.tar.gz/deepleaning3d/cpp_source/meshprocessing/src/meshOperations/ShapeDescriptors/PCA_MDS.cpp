/*
 *  PCA_MDS.cpp
 *  FeatureFinder
 *
 *  Created by Cindy Grimm on 7/14/10.
 *  Copyright 2010 Washington University in St. Louis. All rights reserved.
 *
 */
//do not commit this file
#include <fitting/FITTools_Least_squares.H>
#include <fitting/FITTools_FitLine.H>
#include <fitting/FITTools_SVD.H>
#include <stats/descriptive/DescriptiveStats.H>
#include <meshOperations/SD_FileNames.H>
#include <meshOperations/SD_Curvature.H>
#include <meshOperations/SD_PCA_MDS.H>
#include <meshOperations/SD_Linearize.H>

using namespace Features::SignatureNames;
using namespace Features::DataSetNames;
using namespace Features::IntermediateStorageNames;



/* Split into two vertex data structures, one with the eigen, one with the avg sd */
static void Split( const Features::VertexData &in_data, 
                   Features::VertexData &out_dataMDS, Features::VertexData &out_dataPCA )
{
    out_dataMDS.SetNVertices( in_data.NumVertices() );
    out_dataMDS.SetRadiusAndDimension( in_data.GetRadius(), 2 );
    out_dataMDS.UseKLComparitor();
    
    out_dataPCA.SetNVertices( in_data.NumVertices() );
    out_dataPCA.SetRadiusAndDimension( in_data.GetRadius(), 1 );
    out_dataPCA.UseL2Comparitor();
    
    for ( int i = 0; i < in_data.NumVertices(); i++ ) {
        for ( int iR = 0; iR < in_data.NumRings(); iR++ ) {
            out_dataMDS.SetSignature( i, iR, 0, in_data.GetSignature( i, iR, 0 ) );
            out_dataMDS.SetSignature( i, iR, 1, in_data.GetSignature( i, iR, 1 ) );
            out_dataPCA.SetSignature( i, iR, 0, in_data.GetSignature( i, iR, 2 ) );
        }
    }   
}
/* Recombine the eigen and mds */
static void Combine( const Features::VertexData &in_dataMDS, const Features::VertexData &in_dataPCA,
                        Features::VertexData &out_data )
{
    out_data.SetNVertices( in_dataMDS.NumVertices() );
    out_data.SetRadiusAndDimension( in_dataMDS.GetRadius(), 2 );
    out_data.UseL2Comparitor();
    
    for ( int i = 0; i < in_dataMDS.NumVertices(); i++ ) {
        for ( int iR = 0; iR < in_dataMDS.NumRings(); iR++ ) {
            out_data.SetSignature( i, iR, 0, in_dataMDS.GetSignature( i, iR, 0 ) );
            out_data.SetSignature( i, iR, 1, in_dataPCA.GetSignature( i, iR, 0 ) );
        }
    }   
}

/* Using either the mean or the gaussian curvature, check
 * metric i - metric j  vs crv i - crv j
 *   if they're pointing in the opposite direction, flip all the signs 
 */
static bool AlignPCAWithCurvature( const Features::VertexData &in_data, const Array<double> &in_adCrv )
{
    if ( in_adCrv.num() != in_data.NumVertices() ) {
        cerr << "AlignPCAWithCurvature: No curvature\n";
        return false;
    }
    
    int iCountFlip = 0, iCountNoFlip = 0;
    const int iSkip = WINmax( 1, (int) (in_data.NumVertices() / 1000) );
    for (int i = 0; i < in_data.NumVertices(); i += iSkip ) {
        for (int j = i+1; j < in_data.NumVertices(); j+= iSkip ) {
            const double dDiffcrv = in_adCrv[i] - in_adCrv[j];
            const double dDiffsig = in_data.GetSignature(i,0) - in_data.GetSignature(j,0);
            
            if ( dDiffcrv * dDiffsig < 0 ) {
                iCountFlip++;
            } else {
                iCountFlip--;
            }
        }
    }

    if ( iCountFlip > iCountNoFlip ) {
        return true;
    }
    return false;
}

/* Add the values into the list (cummulative) */
static void AddStats( const Features::VertexData &in_data, const int in_iDim, Array< double > &io_adValues )
{
    for ( int i = 0; i < in_data.NumVertices(); i++ ) {
        io_adValues += in_data.GetSignature(i, in_iDim);
    }
}


static void ProjectEigenvecs( const Features::VertexData &in_data, const std::vector<double> &in_adMean, const std::vector< std::vector<double> > &in_aadEigenVecs,
                             Features::VertexData &out_data )
{
    const int iVectorLen = out_data.NumRings() * out_data.Dimension();
    ASSERT( in_adMean.size() == iVectorLen );
    for ( int i = 0; i < in_data.NumVertices(); i++ ) {
        for ( int j = 0; j < iVectorLen; j++ ) {
            double dSum = 0.0;
            for ( int k = 0; k < in_aadEigenVecs[j].size(); k++ ) {
                dSum += (in_data.GetSignature(i, k) - in_adMean[k]) * in_aadEigenVecs[j][k];
            }
            out_data.SetSignature(i, j, dSum);
        }
    }
}



void Features::CalcPCA( const Features::VertexData &in_data, const Array<double> &in_adCrv,
                        Features::VertexData &out_data, const string &in_strFileEigenVecs )
{
    out_data.SetRadiusAndDimension( in_data.GetRadius(), in_data.Dimension() );
    out_data.SetNVertices( in_data.NumVertices() );
    out_data.UseL2Comparitor();

	const int iNV = in_data.NumVertices();
    const int iVectorLen = in_data.NumRings() * in_data.Dimension();
    
	// Mean values out of points signatures;	    
    std::vector<double> adMean(iVectorLen);
    for ( int i = 0; i < iVectorLen; i++ ) {
        adMean[i] = 0.0;
    }
    
    for ( FORINT i = 0; i < iNV; i++ ) {
        for ( int j = 0; j < iVectorLen; j++ ) {
            adMean[j] += in_data.GetSignature(i,j);
        }
    }
    for ( FORINT i = 0; i < iVectorLen; i++ ) {
        adMean[i] = adMean[i] / (double) iNV;
        ASSERT( !isnan( adMean[i] ) && _finite( adMean[i] ) );
    }
    
	FITToolsSVDLapack <double> matrixSigPts( iNV, iVectorLen, false, true);
        
	// Fill in matrix, 
    for ( FORINT i = 0; i < iNV; i++ ) {
        for ( int j = 0; j < iVectorLen; j++ ) {
            //center the data by substracting the mean
			matrixSigPts.A(i,j) = in_data.GetSignature(i,j) - adMean[j];
		}
	}
    
	VERIFY( matrixSigPts.Solve() );
    
    std::vector< std::vector<double> > aadEigenVecs( iVectorLen );
    for ( FORINT i = 0; i < iVectorLen; i++ ) {
        aadEigenVecs[i].resize( iVectorLen );
        for ( int j = 0; j < iVectorLen; j++ ) {
            aadEigenVecs[i][j] = matrixSigPts.Vt(j,i);
        }
    }
    ProjectEigenvecs( in_data, adMean, aadEigenVecs, out_data );
    
    /* Flip entire coordinate system if needed */
    if ( AlignPCAWithCurvature( out_data, in_adCrv ) ) {
        out_data.FlipSigns();
        for ( int i = 0; i < iVectorLen; i++ ) {
            for ( int j = 0; j < iVectorLen; j++ ) {
                aadEigenVecs[i][j] = -aadEigenVecs[i][j];
            }
        }
    }
    Array<double> adValues( out_data.NumVertices() );
    std::vector< Features::LinearizeParams> aParams;
    
    for ( FORINT i = 0; i < out_data.NumRings() * out_data.Dimension(); i++ ) {
        adValues.need(0);
        AddStats( out_data, i, adValues );
        SetLinearizeParams( adValues, aParams, LinearizeParams::s_adBreaks );
        Linearize( out_data, i, aParams, LinearizeParams::s_adBreaks, matrixSigPts.Sigma(i) / matrixSigPts.Sigma(0) );
    }
    
    
    if ( !in_strFileEigenVecs.compare( "none" ) )
        return;
    
    ofstream out( in_strFileEigenVecs.c_str(), ios::out );
    out.precision(24);
    out << iVectorLen << "\n";
    for ( FORINT i = 0; i < iVectorLen; i++ ) {
        for ( int j = 0; j < iVectorLen; j++ ) {
            out << ( aadEigenVecs[i][j] ) << " ";
        }
        out << "\n";
    }
    out << "EigenValues\n";
    for ( FORINT i = 0; i < iVectorLen; i++ ) {
        out << matrixSigPts.Sigma(i) << " ";
    }
    out << "\n";
    out.close();   
}

/*
 * Take the n representative avd/sd vectors and compute a basis using MDS.
 * Build a distance matrix using K-L divergence metric
 * Take SVD of distance matrix
 */
static double CalcSquareMDSVecs( std::vector< std::vector<double> > &io_aadAvgSD,
                                 const int in_iNKeep,
                                 std::vector< std::vector<double> > &out_adVecs,
                                 Array<double> &out_adEigenValues,
                                 const bool in_bCull = false ) 
{    
    std::vector< std::vector<double> > aadDists( io_aadAvgSD.size() );
    
    /* Build the distance matrix, keeping distance values in aadDist */
	for (int i = 0; i < io_aadAvgSD.size(); ++i) {
        aadDists[i].resize( io_aadAvgSD.size() );
        for ( int j = 0; j < i; j++ ) {
            aadDists[i][j] = aadDists[j][i];
        }
        aadDists[i][i] = 0.0;
        for (FORINT j = i+1; j < io_aadAvgSD.size(); ++j) {	
            aadDists[i][j] = Features::VertexData::CompareKL( io_aadAvgSD[i], io_aadAvgSD[j] );
        }
    }
    
    /* Remove any extra vectors (this happens when merging data across data sets ) 
     * Always take out the row/column that has the smallest distance total,
     * ie, the vector that looks the most like the others */
    Array<double> adMin( io_aadAvgSD.size() );
    while ( io_aadAvgSD.size() > in_iNKeep * 5 ) {  
        adMin.need( aadDists.size() );
        for (int i = 0; i < aadDists.size(); ++i) {
            adMin[i] = 1e30;
            for ( int j = 0; j < aadDists[i].size(); j++ ) {
                if ( i != j ) {
                    adMin[i] = WINmin( adMin[i], aadDists[i][j] );
                }
            }
        }
        const int iRemove = adMin.min_i( adMin );
        aadDists.erase( aadDists.begin() + iRemove, aadDists.begin() + iRemove + 1 );
        io_aadAvgSD.erase(  io_aadAvgSD.begin() + iRemove,  io_aadAvgSD.begin() + iRemove + 1 );
        for ( FORINT i = 0; i < aadDists.size(); i++ ) {
            aadDists[i].erase( aadDists[i].begin() + iRemove, aadDists[i].begin() + iRemove + 1 );
        }
    }
            
    /* Actually do the SVD */
	FITToolsSVDLapack <float> matrixMDS( io_aadAvgSD.size(), io_aadAvgSD.size(), TRUE, FALSE);

    /* Take out the mean */
    double dAvg = 0.0;
	for (FORINT i = 0; i < io_aadAvgSD.size(); ++i) {
        for (int j = 0; j < io_aadAvgSD.size(); ++j) {	
			matrixMDS.A(i,j) = aadDists[i][j];
            dAvg += aadDists[i][j];
        }
    }

    dAvg /= (double) ( io_aadAvgSD.size() * io_aadAvgSD.size()  );
    
	for (FORINT i = 0; i < io_aadAvgSD.size(); ++i){
        for (int j = 0; j < io_aadAvgSD.size(); ++j) {	
			matrixMDS.A(i,j) = (float) ( matrixMDS.A(i,j) - dAvg );            
		}//in for	
	}//out for
    
    // n X n matrix w/eigenvecs
    VERIFY( matrixMDS.Solve( ) );
    
    // Pull out the eigen vecs and the eigen values
    out_adVecs.resize( in_iNKeep );
    for ( FORINT i = 0; i < in_iNKeep; i++ ) {
        out_adVecs[i].resize( io_aadAvgSD.size() );
        for ( int j = 0; j < io_aadAvgSD.size(); j++ ) {
            out_adVecs[i][j] = matrixMDS.U(j,i);
        }
    }
    out_adEigenValues.need( io_aadAvgSD.size() );
    for ( FORINT i = 0; i < out_adEigenValues.num(); i++ ) {
        out_adEigenValues[i] = matrixMDS.Sigma(i);
    }
    
    return dAvg;
}

/*
 * Project a new vector.
 * Calculate the n distances to make the distance vector
 * Take the dot product of the distance vector with the eigenvectors of the MDS matrix
 */
static void ProjectSquareMD( const double in_dAvg,
                             const std::vector< std::vector<double> > &in_adVecs,
                             const std::vector< std::vector<double> > &in_aadDists,
                             Features::VertexData &out_data ) 
{
    
    for ( int iV = 0; iV < out_data.NumVertices(); iV++ ) {
        for ( int iR = 0; iR < out_data.NumRings(); iR++ ) {
            double dSum = 0.0;
            for ( int i = 0; i < in_adVecs[iR].size(); i++ ) {
                const double dDist = in_aadDists[iV][i];
                dSum += ( dDist - in_dAvg ) * in_adVecs[iR][i];
            }
            out_data.SetSignature(iV,iR, dSum );
        }
    }
}

void Features::CalcMDS( const Features::VertexData &in_data, const Array<double> &in_adCrv, Features::VertexData &out_data, const string &in_strFileEigenVecs )
{
    out_data.SetRadiusAndDimension( in_data.GetRadius(), 1 );
    out_data.SetNVertices( in_data.NumVertices() );
    out_data.UseL2Comparitor();
    
    ASSERT( in_data.Dimension() % 2 == 0 );
	const int iNV = in_data.NumVertices();
	const int iNVecLen = in_data.NumRings();
    
    std::vector< std::vector<double> > aadAvgSD, aadDists( iNV ), adVecs;
    Array<double> adBest( iNV ), adAvg;
    adBest.fill( 1e30 );

    /* Pick out Radius * 5 point signatures that can be used as the "eigen vectors"
     * Pick out the one that's the furthest from the current selection
     * Put these in aadAvgSD. Save the distances in aadDists.
     */
    while ( aadAvgSD.size() < iNVecLen * 5 ) {
        const int iMaxWorst = adBest.max_i( adBest );
        const double dWorst = adBest[ iMaxWorst ];
        if ( adAvg.num() > iNVecLen ) {
            const double dDiffLast = adAvg[ adAvg.num() - 2 ] - adAvg.last();
            if ( dDiffLast < adAvg.last() * 0.01 && adBest[iMaxWorst] < 0.1 * ( adAvg[0] + adAvg[1] ) ) {
                break;
            }
        }

        aadAvgSD.push_back( in_data.GetSignature( iMaxWorst ) );

        double dAvg = 0.0;
        for ( int i = 0; i < iNV; i++ ) {
            const double dDist = in_data.Compare( i, in_data.GetSignature(iMaxWorst) );
            if ( i == iMaxWorst ) {
                ASSERT( fabs( dDist ) < 1e-6 );
            }
            aadDists[i].push_back( dDist );
            
            adBest[i] = WINmin( dDist, adBest[i] );
            dAvg += adBest[i];
        }
        adAvg += dAvg / (double) iNV;        
        cout << adAvg.last() << " " << dWorst << "  ";
    }
        
    /* Perform multi-dimensional scaling on the Radius * 5 distance matrix.
     * Produces Radius eigen vectors and eigen values. */
    Array<double> adEigenValues;
    const double dAvgAll = CalcSquareMDSVecs( aadAvgSD, iNVecLen, adVecs, adEigenValues );
    /* Now take all of the saved distances for all of the other vectors and project on the new basis */
    ProjectSquareMD( dAvgAll, adVecs, aadDists, out_data );
    if ( AlignPCAWithCurvature( out_data, in_adCrv ) ) {
        out_data.FlipSigns();
    }

    Array<double> adValues( iNV );
    std::vector< Features::LinearizeParams> aParams;

    for ( int i = 0; i < out_data.NumRings(); i++ ) {
        adValues.need(0);
        AddStats( out_data, i, adValues );
        SetLinearizeParams( adValues, aParams, LinearizeParams::s_adBreaks );
        Linearize( out_data, i, aParams, LinearizeParams::s_adBreaks, adEigenValues[i] / adEigenValues[0] );
    }
    
    ofstream out( in_strFileEigenVecs.c_str(), ios::out );
    out.precision(24);
    out << aadAvgSD.size() << " " << aadAvgSD[0].size() << "\n";
    for ( FORINT i = 0; i < aadAvgSD.size(); i++ ) {
        for ( int j = 0; j < aadAvgSD[i].size(); j++ ) {
            out << aadAvgSD[i][j]<<" ";
        }		
        out << "\n";
    }
    out << "EigenValues\n";
    for ( FORINT i = 0; i < adEigenValues.num(); i++ ) {
        out << adEigenValues[i] << " ";
    }
    out << "\n";
    out.close();   
}

//This methods create a Nx N distance matrix where the metric is Kullback-Leibler divergence
static void CalcMDSRaw( const Features::VertexData &in_data, Features::VertexData &out_data, const string &in_strFileEigenVecs )
{
    out_data.SetRadiusAndDimension( in_data.GetRadius(), 1 );
    out_data.SetNVertices( in_data.NumVertices() );
    out_data.UseL2Comparitor();
    
	const int iNV = in_data.NumVertices();
	const int iNR = in_data.NumRings();

    int iSkip = 1;
    int iNVsUse = 1 + (iNV - 1) / iSkip;
    while ( iNVsUse > 2500 ) {
        iSkip *= 2;
        iNVsUse = 1 + (iNV - 1) / iSkip;
    }
    
	Array<float> adSaveOrigVecs( iNVsUse * iNVsUse );
	FITToolsSVDLapack <float> matrixMDS(iNVsUse,iNVsUse,TRUE,FALSE);
    
	adSaveOrigVecs.memfill(0);
    
	double dMin = 1e30, dMax = -1e30;
	for (int i = 0; i < iNVsUse; ++i){
        
		for(int j = 0; j < iNVsUse; ++j){	
            
			const double dDivg = Features::VertexData::CompareKL( in_data.GetSignature( i*iSkip ), in_data.GetSignature( j * iSkip ) );
			dMin = WINmin( dMin, dDivg );
			dMax = WINmax( dMax, dDivg );
            
			ASSERT(dDivg >= 0.0);
			matrixMDS.A(i,j) += (float) dDivg;
			matrixMDS.A(j,i) += (float) dDivg;
			adSaveOrigVecs[ i * iNVsUse + j ] = (float) dDivg;
			adSaveOrigVecs[ j * iNVsUse + i ] = (float) dDivg;
            
		}//in for	
        
	}//out for
	cout << "Min " << dMin << " " << dMax << "  ";
    
	VERIFY( matrixMDS.Solve() );
    
	dMin = 1e30;
	dMax = -1e30;
	for ( FORINT i = 0; i < iNV; i++ ) {
		// Dot product of original vectors with first eigenvector
        for ( int iR = 0; iR < iNR; iR++ ) {
            double dSum = 0.0;
            if ( i % iSkip == 0 ) {
                for ( int j = 0; j < iNVsUse; j++ ){
                    dSum += adSaveOrigVecs[(i/iSkip) * iNVsUse + j] * matrixMDS.U( j,iR );
                }
            } else {
                for ( int j = 0; j < iNVsUse; j++ ){
                    const double dDiv = Features::VertexData::CompareKL( in_data.GetSignature( i ), in_data.GetSignature( j * iSkip ) );
                    dSum += dDiv * matrixMDS.U( j,iR );
                }
            }
            dMin = WINmin( dMin, dSum );
            dMax = WINmax( dMax, dSum );
            out_data.SetSignature( i, iR, dSum );
        }
	}
    
	cout << "Min " << dMin << " " << dMax << "\n";

    ofstream out( in_strFileEigenVecs.c_str(), ios::out );
    out.precision(24);
    out << iNR << " " << iNVsUse << "\n";
    for ( FORINT i = 0; i < iNR; i++ ) {
        for ( int j = 0; j < iNVsUse; j++ ) {
            out << matrixMDS.U(j,i);
        }
    }
    out.close();   
}

static bool AllEigenVecs( const DataSet &in_dataSet, const Signature &in_sig, const bool in_bSphere,
                          const bool in_bUseExistingVecs,
                          const Array< Array< double > > &in_aadCrv )
{
    if ( NumMeshes( in_dataSet ) == 0 ) {
        cerr << "AverageEigenVecs, warning - data set has no meshes: " << DataSetName( in_dataSet ) << "\n";
        return false;
    }

    Features::VertexData avData, avDataMDS, avDataPCA;
    ifstream in;
    int iCount = 0;
    int iSizeVec = 0;
    std::vector<double> adMean;
    for ( int iMesh = 0; iMesh < NumMeshes( in_dataSet ); iMesh++ ) {
        if ( !ExistsSig( in_dataSet, iMesh, sigData, in_sig, in_bSphere ) ) {
            return false;
        }
        
        WINReadBinary( FullSigPathName(in_dataSet, iMesh, sigData, in_sig, in_bSphere).c_str(), in );
        avData.ReadSizeInfoOnly(in);
        in.close();
        iCount += avData.NumVertices();
        if ( iMesh != 0 ) {
            if ( in_sig.first == dist_to_plane && in_sig.second == avg_sd_ring ) {
                ASSERT( iSizeVec == avData.NumRings() );
            } else {
                ASSERT( iSizeVec == avData.NumRings() * avData.Dimension() );
            }
        } else {
            iSizeVec = avData.NumRings() * avData.Dimension();
            if ( in_sig.first == dist_to_plane && in_sig.second == avg_sd_ring ) {
                iSizeVec = avData.NumRings();
            }            
        }
        adMean.resize( iSizeVec, 0.0 );
    }
    
    std::vector< std::vector< double > > aadEigenVecs( iSizeVec );
    Array<double> adEigenValues( iSizeVec );
    if ( in_bUseExistingVecs == false || !ExistsSig( in_dataSet, eigenVecsPCA_MDSAll, in_sig, in_bSphere ) ) {
        FITToolsSVDLapack <float> matAvgEigen( iCount, iSizeVec, false, true);
        
        int iRow = 0;
        for ( FORINT iMesh = 0; iMesh < NumMeshes( in_dataSet ); iMesh++ ) {
            WINReadBinary( FullSigPathName(in_dataSet, iMesh, sigData, in_sig, in_bSphere).c_str(), in );
            avData.ReadBinary(in);
            in.close();
            
            if ( in_sig.first == dist_to_plane && in_sig.second == avg_sd_ring ) {
                Split( avData, avDataMDS, avDataPCA );
                avData = avDataPCA;
            }
            
            for ( int i = 0; i < avData.NumVertices(); i++ ) {
                for ( int j = 0; j < iSizeVec; j++ ) {
                    matAvgEigen.A( iRow, j ) = avData.GetSignature( i, j );
                    adMean[j] += avData.GetSignature( i, j );
                }
                iRow++;
            }
        }
        ASSERT( iRow == iCount );
        
        for ( int i = 0; i < adMean.size(); i++ ) {
            adMean[i] /= (double) iRow;
        }
        for ( FORINT i = 0; i < matAvgEigen.NRows(); i++ ) {
            for ( int j = 0; j < adMean.size(); j++ ) {
                matAvgEigen.A(i,j) = (float) (matAvgEigen.A(i,j) - adMean[j]);
            }
        }   
        VERIFY( matAvgEigen.Solve() );
        
        // Copy vectors over and write out to file
        ofstream out( FullSigPathName( in_dataSet, eigenVecsPCA_MDSAll, in_sig, in_bSphere ).c_str(), ios::out );
        out.precision(24);
        out << iSizeVec << "\n";
        for ( FORINT i = 0; i < iSizeVec; i++ ) {
            aadEigenVecs[i].resize( iSizeVec );
            for ( int j = 0; j < iSizeVec; j++ ) {
                aadEigenVecs[i][j] = matAvgEigen.Vt(j,i);
                out << aadEigenVecs[i][j] << " ";
            }
            out << "\n";
        }
        out << "EigenValues\n";
        for ( FORINT i = 0; i < iSizeVec; i++ ) {
            adEigenValues[i] = matAvgEigen.Sigma(i);
            out << matAvgEigen.Sigma(i) << " ";
        }
        out << "\n";
        out << "Means " << adMean.size() << "\n";
        for ( FORINT i = 0; i < adMean.size(); i++ ) {
            out << adMean[i] << " ";
        }
        out << "\n";
        out.close();   
        matAvgEigen.Resize(1,1 );
        
    } else {
        ifstream in( FullSigPathName( in_dataSet, eigenVecsPCA_MDSAll, in_sig, in_bSphere ).c_str(), ios::in );
        int iCheckSizeVec = iSizeVec;
        
        in >> iCheckSizeVec;
        if ( iCheckSizeVec != iSizeVec ) {
            cerr << "ERR: Re-projecting eigenvectors: Not same size\n";
            return false;
        }
        
        for ( int i = 0; i < iSizeVec; i++ ) {
            aadEigenVecs[i].resize( iSizeVec );
            for ( int j = 0; j < iSizeVec; j++ ) {
                in >> aadEigenVecs[i][j];
            }
        }
        std::string str;
        
        in >> str;
        if ( str.compare("EigenValues") ) {
            cerr << "ERR: Re-projecting eigenvectors, failed to find eigen values\n";
            return false;
        }
        
        for ( FORINT i = 0; i < iSizeVec; i++ ) {
            in >> adEigenValues[i];
        }
        in >> str >> iCheckSizeVec;
        adMean.resize( iCheckSizeVec );
        if ( str.compare("Means") ) {
            cerr << "ERR: Re-projecting eigenvectors, failed to find eigen values\n";
            return false;
        }
        for ( FORINT i = 0; i < adMean.size(); i++ ) {
            in >> adMean[i];
        }
        in.close();   
    }
    
    /* read back in, project */
    Array<Features::VertexData> avOutData( NumMeshes( in_dataSet ) );
    Features::VertexData avDataSave;

    int iCountFlip = 0;
    for ( FORINT iMesh = 0; iMesh < NumMeshes( in_dataSet ); iMesh++ ) {
        WINReadBinary( FullSigPathName(in_dataSet, iMesh, sigData, in_sig, in_bSphere).c_str(), in );
        avData.ReadBinary(in);
        in.close();

        // Copy just the values over that we need
        if ( in_sig.first == dist_to_plane && in_sig.second == avg_sd_ring ) {
            Split( avData, avDataMDS, avDataPCA );
            avData = avDataPCA;
        }
        
        avOutData[iMesh].SetRadiusAndDimension( avData.GetRadius(), avData.Dimension() );
        avOutData[iMesh].SetNVertices( avData.NumVertices() );
        avOutData[iMesh].UseL2Comparitor();
                
        cerr << iMesh << " ";
        ProjectEigenvecs( avData, adMean, aadEigenVecs, avOutData[iMesh] );
        /* Flip entire coordinate system if needed */
        if ( AlignPCAWithCurvature( avOutData[iMesh], in_aadCrv[iMesh] ) ) {
            iCountFlip++;
        }
    }
    cerr << "\n";
    
    if ( iCountFlip > NumMeshes( in_dataSet ) / 2 ) {
        for (int i = 0; i < avOutData.num(); i++ ) {
            avOutData[i].FlipSigns();
        }
    }

    Array< double> adValues( iCount );
    std::vector< Features::LinearizeParams> aParams;
    
    for ( int i = 0; i < iSizeVec; i++ ) {
        adValues.need(0);
        for ( int j = 0; j < avOutData.num(); j++ ) {
            AddStats( avOutData[j], i, adValues );
        }
        Features::SetLinearizeParams( adValues, aParams, Features::LinearizeParams::s_adBreaks );
        for ( FORINT j = 0; j < avOutData.num(); j++ ) {
            Features::Linearize( avOutData[j], i, aParams, Features::LinearizeParams::s_adBreaks, adEigenValues[i] / adEigenValues[0] );
        }
    }
    
    for ( int j = 0; j < avOutData.num(); j++ ) {
        for ( int iV = 0; iV < avOutData[j].NumVertices(); iV++ ) {
            for ( int i = 0; i < avOutData[j].VecLength(); i++ ) {
                ASSERT( avOutData[j].GetSignature(iV,i) >= 0.0 );
                ASSERT( avOutData[j].GetSignature(iV,i) <= 1.0 );
            }
        }
        if ( in_sig.first == dist_to_plane && in_sig.second == avg_sd_ring ) {
            ifstream inData;
            WINReadBinary( FullSigPathName( in_dataSet, j, sigDataPCA_MDSAll, in_sig, in_bSphere ).c_str(), inData );
            avDataMDS.ReadBinary(inData);
            inData.close();
            
            avDataPCA = avOutData[j];
            Combine( avDataMDS, avDataPCA, avOutData[j] );
        }
            
        ofstream outData;
        WINWriteBinary( FullSigPathName( in_dataSet, j, sigDataPCA_MDSAll, in_sig, in_bSphere ).c_str(), outData );
        avOutData[j].WriteBinary(outData);
        outData.close();
    }
    
    return true;
}


static bool AverageMDS( const DataSet &in_dataSet, const Signature &in_sig, const bool in_bSphere,
                        const bool in_bUseExistingVecs,
                        const Array< Array< double > > &in_aadCrv )
{
    double dTemp = 0.0;
    int iVecSize = 0, iNVecs = 0;
    
    if ( NumMeshes( in_dataSet ) == 0 ) {
        cerr << "AverageEigenVecs, warning - data set has no meshes: " << DataSetName( in_dataSet ) << "\n";
        return false;
    }
    
    std::vector<double> adTemp;
    std::vector< std::vector<double> > aadAvgSD, aadDist, adVecs;
    for ( int iMesh = 0; iMesh < NumMeshes( in_dataSet ); iMesh++ ) {
        ifstream in( FullSigPathName( in_dataSet, iMesh, eigenVecsPCA_MDS, in_sig, in_bSphere ).c_str(), ios::in );
        if ( !in.good() ) {
            return false;
        }
        in >> iNVecs >> iVecSize;
        adTemp.resize( iVecSize );
        for ( int i = 0; i < iNVecs; i++ ) {
            for ( int j = 0; j < iVecSize; j++ ) {
                in >> dTemp;
                adTemp[j] = dTemp;
            }
            aadAvgSD.push_back( adTemp );
        }
        
        in.close();
    }

    // Keep all of the vecs
    Array<double> adEigenValues;
    const double dAvg = CalcSquareMDSVecs( aadAvgSD, aadAvgSD.size(), adVecs, adEigenValues, false );
    Features::VertexData avData, avDataPCA, avDataMDS;
    Array< Features::VertexData > aavDataOut(NumMeshes( in_dataSet ) );

    int iCount = 0, iCountFlip = 0;
    
    for ( FORINT iMesh = 0; iMesh < NumMeshes( in_dataSet ); iMesh++ ) {
        ifstream in( FullSigPathName( in_dataSet, iMesh, sigData, in_sig, in_bSphere ).c_str(), ios::in | ios::binary );
        if ( !in.good() ) {
            return false;
        }
        
        avData.ReadBinary(in);
        in.close();
        
        if ( in_sig.first == dist_to_plane ) {
            Split( avData, avDataMDS, avDataPCA );
            avData = avDataMDS;
        }
        
        aadDist.resize( avData.NumVertices() );
        for ( int iV = 0; iV < avData.NumVertices(); iV++ ) {
            aadDist[iV].resize( aadAvgSD.size() );
            for ( int i = 0; i < aadAvgSD.size(); i++ ) {
                aadDist[iV][i] = Features::VertexData::CompareKL( aadAvgSD[i], avData.GetSignature(iV) );
            }
        }

        aavDataOut[iMesh].SetRadiusAndDimension( avData.GetRadius(), 1 );
        aavDataOut[iMesh].UseL2Comparitor();
        aavDataOut[iMesh].SetNVertices( avData.NumVertices() );
        iCount += avData.NumVertices();
        
        // Project against first 5 vecs
        cerr << iMesh << " ";
        ProjectSquareMD( dAvg, adVecs, aadDist, aavDataOut[iMesh] );        

        /* Flip entire coordinate system if needed */
        if ( AlignPCAWithCurvature( aavDataOut[iMesh], in_aadCrv[iMesh] ) ) {
            iCountFlip++;
        }
    }
    
    cerr << "\n";
    
    if ( iCountFlip > NumMeshes( in_dataSet ) / 2 ) {
        for (int i = 0; i < aavDataOut.num(); i++ ) {
            aavDataOut[i].FlipSigns();
        }
    }
    
    Array<double> adValues( iCount );
    std::vector< Features::LinearizeParams> aParams;

    for ( int i = 0; i < avData.NumRings(); i++ ) {
        adValues.need(0);
        for ( int j = 0; j < aavDataOut.num(); j++ ) {
            AddStats( aavDataOut[j], i, adValues );
        }
        Features::SetLinearizeParams( adValues, aParams, Features::LinearizeParams::s_adBreaks );
        for ( FORINT j = 0; j < aavDataOut.num(); j++ ) {
            Features::Linearize( aavDataOut[j], i, aParams, Features::LinearizeParams::s_adBreaks, adEigenValues[i] / adEigenValues[0] );
        }
    }
    for ( int j = 0; j < aavDataOut.num(); j++ ) {
        for ( int iV = 0; iV < aavDataOut[j].NumVertices(); iV++ ) {
            for ( int i = 0; i < aavDataOut[j].VecLength(); i++ ) {
                ASSERT( aavDataOut[j].GetSignature(iV,i) >= 0.0 );
                ASSERT( aavDataOut[j].GetSignature(iV,i) <= 1.0 );
            }
        }
        
        ofstream outData;
        WINWriteBinary( FullSigPathName( in_dataSet, j, sigDataPCA_MDSAll, in_sig, in_bSphere ).c_str(), outData );
        aavDataOut[j].WriteBinary(outData);
        outData.close();
    }
    
    ofstream out( FullSigPathName( in_dataSet, eigenVecsPCA_MDSAll, in_sig, in_bSphere ).c_str(), ios::out );
    out.precision(24);
    out << iNVecs << " " << iVecSize << "\n";
    for ( FORINT i = 0; i < iNVecs; i++ ) {
        for ( int j = 0; j < iVecSize; j++ ) {
            out << adVecs[i][j] << " ";
        }
        out << "\n";
    }
    out << "EigenValues\n";
    for ( FORINT i = 0; i < iNVecs; i++ ) {
        out << adEigenValues[i] << " ";
    }
    out << "\n";
    out.close();   
    return true;
}

static void SetEigenValuesKeep( const double in_dCutoff, const bool in_bSphere, const Signature in_sig )
{
	int iSigStart = 0;
	int iSigEnd = 0;
	if (in_sig.first == numMetricTypes){
		iSigStart = 0;
		iSigEnd = NumSignatureTypes();
	} else {
		iSigStart = GetSigIndex( in_sig );
		iSigEnd = iSigStart+1;
	}
    
    cout << " Set eigenvalues keep " << in_dCutoff << "\n";
        
    int iVecLen = 0;
    int iVecNum = 0;
    double dVal = 0.0;
    string str;
    Array<double> adValues;
    for ( int iD = 0; iD < NumDataSets( ); iD++ ) {
        const DataSet dataSet = ( Features::DataSetNames::DataSet ) iD;
        
		for ( int iSig = iSigStart; iSig < iSigEnd; iSig++ ) {          
            const Signature sig = GetSignature( iSig );
            
            if ( !ExistsSig( dataSet, eigenVecsPCA_MDSAll, sig, true ) ) {
                cout << "Eigen vec file for sig " << FullSigPathName( dataSet, eigenVecsPCA_MDSAll, sig, in_bSphere ) << " not found\n";
                continue;
            }
            cout <<  FullSigPathName( dataSet, eigenVecsPCA_MDSAll, sig, in_bSphere );
            ifstream in( FullSigPathName( dataSet, eigenVecsPCA_MDSAll, sig, in_bSphere ).c_str(), ios::in );			
            
			in >> iVecNum;
			if(sig.second == avg_sd_ring && sig.first != dist_to_plane)
				in >> iVecLen;
			else				
				iVecLen = iVecNum;

            adValues.need( iVecLen );
            for (int i = 0; i < iVecLen * iVecNum; i++ ) {
                in >> dVal;
            }            
            in >> str;
            ASSERT( !str.compare("EigenValues") );
            int iCutoff = iVecLen;
            for ( FORINT i = 0; i < iVecLen; i++ ) {
                in >> adValues[i];
                
                if ( adValues[i] / adValues[0] < in_dCutoff ) {
                    iCutoff = i;
                    break;
                }
            }            
            in.close();
            WriteKeepDimension( dataSet, sig, in_bSphere, iCutoff );
            cout << ShortSignatureName(sig) << " " << iCutoff << "\n";
            
        }
    }
}
                     
                             
void Features::CalcAllPCA_MDS( const double in_dCutoff, const bool in_bRedoAll, const bool in_bUseExistingVecs, const bool in_bSphere, const SignatureNames::Signature in_sig )
{
    Features::VertexData vDataSig, vDataPCAMDS, vDataTempPCA, vDataTempMDS;
    std::vector<double> adMean;
    std::vector< std::vector<double> > aadEigenVecs;
    
    Array<double> adEigenValueAvg;
    
    Array< Array<double> > aadMeanCrv, aadGaussCrv;

	int iSigStart = 0;
	int iSigEnd = 0;
	if (in_sig.first == numMetricTypes){
		iSigStart = 0;
		iSigEnd = NumSignatureTypes();
	} else {
		iSigStart = GetSigIndex( in_sig );
		iSigEnd = iSigStart+1;
	}
    
    for ( int i = 0; i < NumDataSets( ); i++ ) {
        const DataSet dataSet = ( DataSetNames::DataSet ) i;
        
        aadMeanCrv.need( NumMeshes(dataSet) );
        aadGaussCrv.need( NumMeshes(dataSet) );
        for ( int j = 0; j < NumMeshes( dataSet ); j++ ) {
            if ( Exists( dataSet, j, curvature ) ) {
                ReadGaussMean( FullPathName( dataSet, j, curvature ), aadGaussCrv[j], aadMeanCrv[j] );
            } else {
                aadMeanCrv[j].need(0);
                aadGaussCrv[j].need(0);
            }
			for ( int iSig = iSigStart; iSig < iSigEnd; iSig++ ) {
                const Features::SignatureNames::Signature sig = Features::SignatureNames::GetSignature( iSig );
                
                if ( !ExistsSig( dataSet, j, sigData, sig, in_bSphere ) ) {
                    cout << " Doing PCA: Signature " << FullSigPathName( dataSet, j, sigData, sig, in_bSphere ) << " does not exist\n";
                    continue;
                }
                if ( ExistsSig( dataSet, j, sigDataPCA_MDS, sig, in_bSphere ) && !in_bRedoAll ) {
                    cout << " Signature PCA/MDS " << FullSigPathName( dataSet, j, sigDataPCA_MDS, sig, in_bSphere ) << " exists\n";
                    continue;
                }
                
                cout << "Calculating signature PCA/MDS " << FullSigPathName( dataSet, j, sigDataPCA_MDS, sig, in_bSphere ) << "\n";
                ifstream in;
                WINReadBinary( FullSigPathName( dataSet, j, sigData, sig, in_bSphere ).c_str(), in );
                vDataSig.ReadBinary( in );
                in.close();

                if ( Features::SignatureNames::UseKLComparison(sig) ) {
                    if ( sig.first == dist_to_plane ) {
                        Split( vDataSig, vDataTempMDS, vDataTempPCA );
                        vDataSig = vDataTempPCA;
                        // Don't save eigen vecs
                        CalcPCA( vDataSig, IsGauss(sig) ? aadGaussCrv[j] : aadMeanCrv[j], vDataTempPCA, "none" );
                        vDataSig = vDataTempMDS;
                    }
                    CalcMDS( vDataSig, IsGauss(sig) ? aadGaussCrv[j] : aadMeanCrv[j], vDataPCAMDS, FullSigPathName( dataSet, j, eigenVecsPCA_MDS, sig, in_bSphere ) );
                    
                    if ( sig.first == dist_to_plane ) {
                        vDataTempMDS = vDataPCAMDS;
                        Combine( vDataTempMDS, vDataTempPCA, vDataPCAMDS );
                    }
                } else {
                    CalcPCA( vDataSig, IsGauss(sig) ? aadGaussCrv[j] : aadMeanCrv[j], vDataPCAMDS, FullSigPathName( dataSet, j, eigenVecsPCA_MDS, sig, in_bSphere ) );
                }
                
                ofstream out;
                WINWriteBinary( FullSigPathName( dataSet, j, sigDataPCA_MDS, sig, in_bSphere ).c_str(), out );
                vDataPCAMDS.WriteBinary( out );
                out.close();
            }
        }
        
        /// Now go back and project against averaged vecs
		for ( int iSig = iSigStart; iSig < iSigEnd; iSig++ ) {
            const Features::SignatureNames::Signature sig = Features::SignatureNames::GetSignature( iSig );

            bool bDone = ExistsSig( dataSet, eigenVecsPCA_MDSAll, sig, in_bSphere );
            for ( int iM = 0; iM < NumMeshes( dataSet ); iM++ ) {
                if ( !ExistsSig( dataSet, iM, sigDataPCA_MDSAll, sig, in_bSphere ) ) {
                    bDone = false;
                }
            }

            if ( bDone == true && !in_bRedoAll ) {
                cout << " Already exists " << DataSetName( dataSet ) << " " << SignatureName( sig, in_bSphere ) <<  " PCA ALL\n";
                continue;
            } else {
                cout << " Computing " << DataSetName( dataSet ) << " " << SignatureName( sig, in_bSphere ) <<  " PCA ALL\n ";
            }

            // only average if all of the individual eigen vecs exist
            // make sure to redo all of the eigen vecs
            if ( Features::SignatureNames::UseKLComparison(sig) ) {
                AverageMDS( dataSet, sig, in_bSphere, in_bUseExistingVecs, IsGauss(sig) ? aadGaussCrv : aadMeanCrv );
                if ( sig.first == dist_to_plane ) {
                    AllEigenVecs( dataSet, sig, in_bSphere, in_bUseExistingVecs, IsGauss(sig) ? aadGaussCrv : aadMeanCrv );
                }
            } else {
                AllEigenVecs( dataSet, sig, in_bSphere, in_bUseExistingVecs, IsGauss(sig) ? aadGaussCrv : aadMeanCrv );
            }            
        }
    }
    SetEigenValuesKeep( in_dCutoff, in_bSphere, in_sig );
}
