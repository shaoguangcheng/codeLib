#include <meshOperations/SD_FileNames.H>
#include <meshOperations/SD_MeshScale.H>
#include <meshOperations/SD_SampleRings.H>
#include <meshOperations/SD_Curvature.H>
#include <meshOperations/SD_PCA_MDS.H>
#include <meshOperations/SD_Linearize.H>
#include <meshOperations/SD_SignatureData.H>

using namespace Features;
using namespace Features::SignatureNames;
using namespace Features::DataSetNames;
using namespace Features::IntermediateStorageNames;


char g_strDataHome[] = "./";

extern bool ShowSignature( const Features::DataSetNames::DataSet &in_dataSet, const Features::SignatureNames::Signature &in_sig, const bool in_bSphere, const int in_iDim, const std::string &in_strOutDir );


typedef enum {
    NONE = -1,
    WRITE_ONE_TEXT,
    WRITE_ONE_BINARY,
    WRITE_GROUP_TEXT,
    WRITE_GROUP_BINARY,
    WRITE_GROUP_COLORED_MESHES
} Action;

/* Convert the input text strings into which data sets/filenames to use */
static Features::SignatureNames::Signature 
ProcessArgs( const char *in_strFileName, const char *in_strMetricName, const char *in_strSphereCircle, const char *in_strPercBBox, bool &out_bSphereCirc )
{
    Features::SignatureNames::Signature sigRet( Features::SignatureNames::numMetricTypes, Features::SignatureNames::numRingSamplingTypes );

    /* Read in the text file and add all of the listed meshes to the Features::DataSetNames::fromFile data set */
    if ( !DataSetNames::AddDataSet( std::string( in_strFileName ) ) ) {
        return sigRet;
    }
    sscanf( in_strPercBBox, "%lf", &Features::g_dMaxRadius );

    const std::string strSample( in_strSphereCircle );
    if ( !strSample.compare( "sphere") ) {
        cout << "Using spherical sampling\n";
        out_bSphereCirc = true;
    } else if ( !strSample.compare("circle") ) {
        cout << "Using exponential map/planar sampling\n";
        out_bSphereCirc = false;
    } else {
        cerr << "Sampling type should be sphere or circle\n";
        return sigRet;
    }
    
    sigRet = SignatureNames::GetSignature( std::string( in_strMetricName ) );

    return sigRet;
}

static bool WriteOneText( const Features::VertexData &in_avData, const std::string &in_strFName, const int in_iMaxVecLen )
{
    ofstream out( in_strFName.c_str(), ios::out );
    if ( !out.good() ) {
        return false;
    }
    
    out.precision(10);
    const int iKeep = in_iMaxVecLen == -1 ? in_avData.VecLength() : WINmin( in_avData.VecLength(), in_iMaxVecLen );
    for ( int i = 0; i < in_avData.NumVertices(); i++ ) {
        for ( int j = 0; j < iKeep-1; j++ ) {
            out << in_avData.GetSignature(i)[j] << ",";
        }
        out << in_avData.GetSignature(i)[iKeep-1] << "\n";
    }
    out.close();
    
    cout << "Dimension of data: " << in_avData.NumVertices() << " " << iKeep << "\n";
    return true;
}

static bool WriteOneBinary( const Features::VertexData &in_avData, const std::string &in_strFName, const int in_iMaxVecLen )
{
    ofstream out( in_strFName.c_str(), ios::out | ios::binary );
    if ( !out.good() ) {
        return false;
    }
    
    out.precision(10);
    const int iKeep = in_iMaxVecLen == -1 ? in_avData.VecLength() : WINmin( in_avData.VecLength(), in_iMaxVecLen );
    Array<double> adMax( in_avData.VecLength() );
    adMax.fill(0.0);
    
    for ( int i = 0; i < in_avData.NumVertices(); i++ ) {
        out.write( (const char *) &in_avData.GetSignature(i)[0], sizeof(double) * iKeep );
        for ( int j = 0; j < adMax.num(); j++ ) {
            adMax[j] = WINmax( adMax[j], in_avData.GetSignature(i,j) );
        }
    }
    out.close();
    
    cout << "Dimension of data: " << in_avData.NumVertices() << " " << iKeep << " max\n  ";
    for ( int j = 0; j < adMax.num(); j++ ) {
        cout << adMax[j] << " " ;
    }
    cout << "\n";
    return true;
}

static bool WriteOne( const char *in_strPCAAllDataName, const char *in_strFileNameOut, const int in_iMaxVecLen, const bool in_bDoText )
{
    Features::VertexData avData;
    avData.ReadBinary( std::string( in_strPCAAllDataName ) );
    
    if ( avData.NumVertices() == 0 ) {
        return false;
    }
    
    if ( in_bDoText ) {
        if ( !WriteOneText( avData, std::string( in_strFileNameOut ), in_iMaxVecLen ) ) {
            return false;
        }
    } else {
        if ( !WriteOneBinary( avData, std::string( in_strFileNameOut ), in_iMaxVecLen ) ) {
            return false;
        }
    }
    
    return true;
}

static void WriteVLocs( const char *in_strFileNameOut, const int in_iMesh )
{
    PMeshLite mesh;
    
    mesh.Read( Features::IntermediateStorageNames::FullPathName( Features::DataSetNames::fromFile, in_iMesh, Features::IntermediateStorageNames::normalizedMesh ).c_str() );
    const std::string fnameMeshVsLocs = std::string( in_strFileNameOut ) + Features::DataSetNames::MeshNameNoDir( Features::DataSetNames::fromFile, in_iMesh ) + std::string( "_vLocs.txt" );
    
    ofstream out( fnameMeshVsLocs.c_str(), ios::out );
    ForMeshOrderedVertex( mesh.Mesh(), v ) {
        out << v->GetLoc()[0] << " ";
        out << v->GetLoc()[1] << " ";
        out << v->GetLoc()[2] << "\n";
    }EndFor;
    out.close();
    
}

static void WriteVArea( const char *in_strFileNameOut, const int in_iMesh )
{
    PMeshLite mesh;
    
    mesh.Read( Features::IntermediateStorageNames::FullPathName( Features::DataSetNames::fromFile, in_iMesh, Features::IntermediateStorageNames::normalizedMesh ).c_str() );
    const std::string fnameMeshVsArea = std::string( in_strFileNameOut ) + Features::DataSetNames::MeshNameNoDir( Features::DataSetNames::fromFile, in_iMesh ) + std::string( "_vArea.txt" );
    
    ofstream out( fnameMeshVsArea.c_str(), ios::out );
    
    out.precision(10);
    
    Array<double> adArea;
    const double dSum = mesh.GetVertexAreas( adArea );
    ForMeshOrderedVertex( mesh.Mesh(), v ) {
        out << adArea[ v->IndexId() ] / dSum << " ";
    }EndFor;
    out << "\n";
    
    out.close();    
}


static bool WriteGroup( const Features::SignatureNames::Signature &in_sig, const bool in_bSphere, const char *in_strFileNameOut, const int in_iMaxVecLen, const bool in_bDoText )
{
    Features::VertexData avData;
    
    const Features::DataSetNames::DataSet dataSet = Features::DataSetNames::fromFile;
    
    const int iNumMeshes = Features::DataSetNames::NumMeshes( dataSet );
    
    bool bIsOk = true;
    const std::string strMetric = Features::SignatureNames::SignatureName( in_sig, in_bSphere );
    std::string strStorage = Features::IntermediateStorageNames::StorageName( Features::IntermediateStorageNames::sigDataPCA_MDSAll );
    strStorage.erase( 0, 18 );
    strStorage.erase( strStorage.find_last_of(".") );

    const std::string strTextBinary( in_bDoText ? "text_" : "binary_" );
    const std::string strMasterFile = std::string( in_strFileNameOut ) + std::string("ReadMatlab_") + strTextBinary + strMetric + strStorage + std::string(".m");
    ofstream out( strMasterFile.c_str(), ios::out );
    
    if ( !out.good() ) {
        cerr << "Directory " << in_strFileNameOut << " not good\n";
        return false;
    }
    
    out << "numMeshes = " << iNumMeshes << ";\n";
    for ( int iMesh = 0; iMesh < iNumMeshes; iMesh++ ) {
        
        const std::string strSD = Features::IntermediateStorageNames::FullSigPathName( dataSet, iMesh, Features::IntermediateStorageNames::sigDataPCA_MDSAll, in_sig, in_bSphere );
        if ( Features::IntermediateStorageNames::ExistsSig( dataSet, iMesh, Features::IntermediateStorageNames::sigDataPCA_MDSAll, in_sig, in_bSphere ) ) {
            cout << "Reading vertex data " << iMesh << " " << strSD << "\n";
            
            avData.ReadBinary( strSD );

            if ( avData.NumVertices() == 0 ) {
                bIsOk = false; 
            } else {
                const std::string fnameText = std::string( in_strFileNameOut ) + Features::DataSetNames::MeshNameNoDir( dataSet, iMesh ) + strMetric + strStorage + std::string( ".txt" );
                const std::string fnameBinary = std::string( in_strFileNameOut ) + Features::DataSetNames::MeshNameNoDir( dataSet, iMesh ) + strMetric + strStorage + std::string( ".bin" );
                if ( in_bDoText ) {
                    if ( !WriteOneText( avData, fnameText, in_iMaxVecLen ) ) {
                        bIsOk = false;
                    }
                    out << "mat" << iMesh << " = " << " dlmread( '" << fnameText << "' );\n";
                } else {
                    if ( !WriteOneBinary( avData, fnameBinary, in_iMaxVecLen ) ) {
                        bIsOk = false;
                    }
                    const int iKeep = in_iMaxVecLen == -1 ? avData.VecLength() : WINmin( avData.VecLength(), in_iMaxVecLen );
                    out << "fid = fopen( '" << fnameBinary << "' );\n";
                    out << "mat" << iMesh << " = fread(fid, [" << iKeep << ", " << avData.NumVertices() << "], 'double')';\n";
                    out << "fclose(fid);\n";
                }
            }
            WriteVLocs( in_strFileNameOut, iMesh );
            WriteVArea( in_strFileNameOut, iMesh );
            
            const std::string fnameMeshVsLocs = std::string( in_strFileNameOut ) + Features::DataSetNames::MeshNameNoDir( dataSet, iMesh ) + std::string( "_vLocs.txt" );
            const std::string fnameMeshVsArea = std::string( in_strFileNameOut ) + Features::DataSetNames::MeshNameNoDir( dataSet, iMesh ) + std::string( "_vArea.txt" );
            out << "vLocs" << iMesh << " = " << " dlmread( '" << fnameMeshVsLocs << "' );\n";
            out << "vArea" << iMesh << " = " << " dlmread( '" << fnameMeshVsArea << "' );\n";
        } else { 
            bIsOk = false;
            cerr << "Vertex data file " << strSD << " not found\n";
        }        
    }
    return true;
}

static bool WriteGroupMeshes( const Features::SignatureNames::Signature &in_sig, const bool in_bSphere, const char *in_strFileNameOut, const int in_iDim )
{
    Features::VertexData avData;
    
    const Features::DataSetNames::DataSet dataSet = Features::DataSetNames::fromFile;
    
    return ShowSignature( dataSet, in_sig, in_bSphere, in_iDim, std::string( in_strFileNameOut ) );
}


// Default command:
//  Listofnames.txt metric sphere/circle PercentageEigenValues 
int	main( int argc,	char **	argv )
{
    bool bIsOk = false;
    bool bSphere = true;
    
    Action action = NONE;
    if ( argc > 1 ) {
        if ( !strcmp( "wt", argv[1] ) ) {
            action = WRITE_ONE_TEXT;
        } 
        if ( !strcmp( "wb", argv[1] ) ) {
            action = WRITE_ONE_BINARY;
        } 
        if ( !strcmp( "wgt", argv[1] ) ) {
            action = WRITE_GROUP_TEXT;
        } 
        if ( !strcmp( "wgb", argv[1] ) ) {
            action = WRITE_GROUP_BINARY;
        } 
        if ( !strcmp( "wgm", argv[1] ) ) {
            action = WRITE_GROUP_COLORED_MESHES;
        } 
    }
    
    switch ( action ) {
        case WRITE_ONE_TEXT :
            if ( argc != 5 ) {
                cerr << "Wrong number of arguments to write an ascii text file\n";
            } else {
                cout << "Writing text file " << argv[3] << "\n";
                bIsOk = WriteOne( argv[2], argv[3], atoi( argv[4] ), true );
            }
            break;
        case WRITE_ONE_BINARY :
            if ( argc != 5 ) {
                cerr << "Wrong number of arguments to write abinary file\n";
            } else {
                cout << "Writing binary file " << argv[3] << "\n";
                bIsOk = WriteOne( argv[2], argv[3], atoi( argv[4] ), false );
            }
            break;
        case WRITE_GROUP_TEXT :
            if ( argc != 8 ) {
                cerr << "Wrong number of arguments to write a group of ascii text files\n";
            } else {
                const Features::SignatureNames::Signature sig = ProcessArgs( argv[2], argv[3], argv[4], argv[5], bSphere );
                if ( sig.first != Features::SignatureNames::numMetricTypes ) {
                    bIsOk = WriteGroup( sig, bSphere, argv[6], atoi( argv[7] ), true );
                }
            }
            break;
        case WRITE_GROUP_BINARY :
            if ( argc != 8 ) {
                cerr << "Wrong number of arguments to write a group of binary files\n";
            } else {
                const Features::SignatureNames::Signature sig = ProcessArgs( argv[2], argv[3], argv[4], argv[5], bSphere );
                if ( sig.first != Features::SignatureNames::numMetricTypes ) {
                    bIsOk = WriteGroup( sig, bSphere, argv[6], atoi( argv[7] ), false );
                }
            }
            break;
        case WRITE_GROUP_COLORED_MESHES :
            if ( argc != 8 ) {
                cerr << "Wrong number of arguments to write a group of colored meshes\n";
            } else {
                const Features::SignatureNames::Signature sig = ProcessArgs( argv[2], argv[3], argv[4], argv[5], bSphere );
                if ( sig.first != Features::SignatureNames::numMetricTypes ) {
                    bIsOk = WriteGroupMeshes( sig, bSphere, argv[6], atoi( argv[7] ) );
                }
            }
            break;
        default :
            cerr << "Unrecognized option\n";
            bIsOk = false;
    }
            
    if ( bIsOk == false ) {	
        cout << "\n\nOptions are wt, wb, wgt, wgb, wgm:\n";
        cout << "  wt signatureFileIn SignatureFileOut maxSDLen\n";
        cout << "    - Write an ascii text file with the signature data.\n";
        cout << "       signatureFileIn: Full path name of filename to read in (*PCA_MDSAll*.bin or *PCA_MDS*.bin)\n";
        cout << "       signatureFileOut: Full path name of output text file\n";
        cout << "       maxSDLen: Number of dimensions to keep; -1 keeps all\n\n";
        cout << " /Users/cindygrimm/graphics/cmg/bin/OSX/Release/S wb signatureFileIn SignatureFileOut maxSDLen\n";
        cout << "    - Same as above, but write out file in binary\n\n";
        cout << "  wgt Filename.txt metric sphere PercBBox DirNameOut maxSDLen\n";
        cout << "    - Write out an ascii text file for each data set in Filename.txt for the given metric and feature radius size\n";
        cout << "       Filename.txt: A text file with information on the meshes to use.\n";
        cerr << "          format is: First line is the absolute path name to the directory containing the data\n";
        cout << "                     Second line is the directory name containing the individual directories\n";
        cout << "                     Subsequent lines are the mesh directories (usually meshname/meshname.ply)\n";
        cout << "          Make sure the directory absolutepath + directory + AllData exists\n";
        cout << "       metric: Shape descriptor name, one of: \n";
        SignatureNames::PrintNames( cout, false );
        cout << "       sphere/circle: Should be one of sphere or circle. Default is sphere\n";
        cout << "       PercEigen: A floating point value in the range 0 to 1. What percentage of the first eigen value to cut off at. Default is 0.1. To keep all eigenvalues, set to 1\n";
        cout << "       PercBBox: A floating point value in the range 0 to 0.1 or so. What to set the feature size to, as a percentage of the bounding box. Default is 0.0375.\n";
        cout << "       DirNameOut: Full path name of directory to write files to\n";
        cout << "       maxSDLen: Number of dimensions to keep; -1 keeps all\n\n";
        cout << "  wgb Filename.txt metric sphere PercBBox DirNameOut maxSDLen\n";
        cout << "    - Same as above, but write out file in binary\n\n";
        cout << "  wgm Filename.txt metric sphere PercBBox DirNameOut maxSDLen\n";
        cout << "    - Same input as above, but write out a colored mesh for each file. Meshes can be read and viewed with MeshViewer_Lite\n";
        cout << "       maxSDLen in this case is the dimension to write out\n\n";
    }
    
    return 0;
}//main


