/*
 *  main.cpp
 *  MeshProcessing
 *
 *  Created by Cindy Grimm on 6/14/10.
 *  Copyright 2010 Washington University in St. Louis. All rights reserved.
 *
 */

#ifdef WIN32
char g_strDataHome[] = "c://graphics/cmg/data/";
#else
char g_strDataHome[] = "/tmp";
#endif

#include <fitting/MeshSimplification_QSlim.H>
#include <utils/Utils_IcosahedralSampler.H>
#include <utils/Utils_Dots.H>
#include "AddNoise.h"
#include "Smooth.h"

extern void obj2ply(const char *in_str, const char *in_strOut, bool bFlipVOrder );

void Bats( const char * in_strBatNameDir, const char * in_strParams, const char *in_strOutParams )
{
    ifstream in( in_strParams, ios::in );
    ofstream out( in_strOutParams, ios::out );
    
    if ( !in.good() ) {
        cerr << "File " << in_strParams << " not found\n";
        return;
    } else if ( !out.good() ) {
        cerr << "Unable to write to file " << in_strOutParams << "\n";
        return;
    }
    
    string strName;
    int iLevels = 0;
    int iNFaces = 0;
    int iQS = 0;
    double dPerc, dTemp1, dTemp2;
    
    PMeshLite mesh;
    R3Pt ptCenter, ptScale;
    out.precision( 12 );
    while ( !in.eof() ) {
        in >> strName >> iLevels >> dPerc >> iQS >> dTemp1 >> dTemp2;
        out << strName << " " << iLevels << " " << dPerc << " " << iQS << " ";
        mesh.Read( ( string(in_strBatNameDir) + strName + string(".ply") ).c_str() );
        ptCenter = mesh.GetCenter(ptScale);
        const double dBBox = WINmax( ptScale[0], WINmax(ptScale[1], ptScale[2]) );
        out << dBBox * 0.000001 << " " << dBBox * 0.2 << "\n";
        out.flush();
    }
    out.close();
}

/*
void PDBMolecule( const string &in_strPDBFile, const string &in_strMesh, const int in_iSampling, const double in_dRadius )
{
    ifstream in( in_strPDBFile.c_str(), ios::in );
    
    if (!in.good() ) {
        cerr << "Error opening file " << in_strPDBFile << "\n";
        return;
    }
    
    std::vector< R3Pt > aptAtoms, aptBackbone, aptSrf;
    string str, str1, str2, str3;
    int iN1, iN2;
    double d1, d2, d3;
    char strLine[1025];
    
    double dMinDist = 1e30;
    while (!in.eof() ) {
        in >> str;
        if ( !str.compare(0, 4, "ATOM") ) {
            in >> iN1 >> str1 >> str2 >> str3 >> iN2 >> d1 >> d2 >> d3;
            ASSERT( in.good() );
            bool bExists = false;
            const R3Pt pt( d1, d2, d3 );
            for ( int i = 0; i < aptAtoms.size(); i++ ) {
                if ( ApproxEqual( aptAtoms[i], pt ) ) {
                    bExists = true; 
                    break;
                } else {
                    dMinDist = WINmin( dMinDist, Length( aptAtoms[i] - pt ) );
                }
            }
            if ( bExists == true ) {
                cout << "Duplicate " << pt << "\n";
            } else {
                aptAtoms.push_back( pt );
            }
        } else if ( !str.compare(0, 6, "HETATM") ) {
            in >> iN1 >> str1 >> str2 >> str3 >> iN2 >> d1 >> d2 >> d3;
            aptBackbone.push_back( R3Pt( d1, d2, d3 ) );
            ASSERT( in.good() );
        } else {
            in.getline( strLine, 1025, '\n');
        }
    } 
    in.close();
    double dAvgDist = 0.0;
    for ( int i = 0; i < aptAtoms.size(); i++ ) {
        double dClosest = 1e30;
        for ( int j = 0; j < aptAtoms.size(); j++ ) {
            if ( i != j )
                dClosest = WINmin( dClosest, Length( aptAtoms[i] - aptAtoms[j] ) );
        }
        dAvgDist += dClosest;
    }
    dAvgDist /= (double) aptAtoms.size();
    cout << "Found " << aptAtoms.size() << " atoms and " << aptBackbone.size() << " backbone atoms, min distance " << dMinDist << " avg dist " << dAvgDist << "\n";
    
    std::vector< pair< R3Pt, R3Vec > > aptnorm;
    Array< R3Vec > avecSamples;
    UTILSIcosahedralSampler icosa;
    icosa.GetSamples( in_iSampling, avecSamples );
    
    cout << "Using " << avecSamples.num() << " sphere samples\n";
    
    UTILSDotArray dots;
    
    int iInside = 0;
    for ( int i = 0; i < aptAtoms.size(); i++ ) {
        bool bFirstNorm = false;
        for ( int j = 0; j < avecSamples.num(); j++ ) {
            bool bIsInside = false;
            const R3Pt pt = aptAtoms[i] + avecSamples[j] * in_dRadius;
            for ( int k = 0; k < aptAtoms.size(); k++ ) {
                if ( i != k ) {
                    if ( Length( aptAtoms[k] - pt ) < in_dRadius ) {
                        bIsInside = true;
                        iInside++;
                        break;
                    }
                }
            }
            if ( bIsInside == false ) {
                if ( bFirstNorm == true ) {
                    dots.Add( pt, avecSamples[j] * in_dRadius, UTILSColor::GREEN );
                    aptnorm.push_back( std::pair< R3Pt, R3Vec >( pt, avecSamples[j] ) );
                } else {
                    dots.Add( pt, UTILSColor::YELLOW );
                    aptSrf.push_back( pt );
                }
                bFirstNorm = true;
            } else {
                //dots.Add( pt, UTILSColor::GREY );
            }
        }
        dots.Add( aptAtoms[i], UTILSColor::RED );
    }
    dots.Write( ( in_strMesh + "_dots.txt" ).c_str() );
    cout << "Inside " << iInside << " of " << aptAtoms.size() * avecSamples.num() << " kept " << aptnorm.size() << " and " << aptSrf.size() << "\n";
    
    ofstream out( ( in_strMesh + "_surface.txt" ).c_str(), ios::out );
    for ( int i = 0; i < aptnorm.size(); i++ ) {
        out << aptnorm[i].first << " " << aptnorm[i].second << "\n";
    }
    out.close();
    
    ofstream outII( ( in_strMesh + "_surfaceII.txt" ).c_str(), ios::out );
    for ( int i = 0; i < aptSrf.size(); i++ ) {
        outII << aptSrf[i] << "\n";
    }
    outII.close();
    
}
 */

static void CheckMesh( const char *in_strIn, const char *in_strOut, const bool in_bTriangulate, const bool in_bPatchBig, const int in_iNMaxPatch )
{
    PMeshLite mesh;
    mesh.Read( in_strIn );
    int count = 0;
    while ( count++ < 3 ) {
        const bool bCheck = MeshSimplification::CheckMesh( mesh, in_bPatchBig, in_iNMaxPatch );
        const bool bTri = mesh.MakeTriangular();
        if ( !bCheck || bTri ) {
            cout << "\nFixed problems, trying again\n";
            mesh.Write( in_strOut );
            mesh.Clear();
            mesh.Read( in_strOut );
        } else {
            break;
        }
    }
    
    mesh.Write( in_strOut );
}

static void EdgeCollapse( const char *in_strIn, const char *in_strOut, const double in_dEdgeSize )
{
    PMeshLite mesh;
    mesh.Read( in_strIn );
    
    int count = 0;
    Array<Edge> aeCollapse;
    cout << "Input mesh " << in_strIn << " edge length " << in_dEdgeSize << "\n";
    while ( count++ < 3 ) {
        double dMin = 1e30, dAvg = 0.0;
        ForMeshEdge( mesh.Mesh(), e ) {
            const double dLen = mesh.GetEdgeLength(e);
            dAvg += dLen;
            dMin = WINmin( dMin, dLen );
            if ( dLen < in_dEdgeSize ) {
                aeCollapse += e;
            }
        }EndFor;
        cout << "Found " << aeCollapse.num() << " edges, min " << dMin << " avg " << dAvg / (double) mesh.NumEdges() << "\n";
        
        if ( aeCollapse.num() == 0 ) {
            break;
        }
        
        for ( int i = 0; i < aeCollapse.num(); i++ ) {
            if ( mesh.Valid( aeCollapse[i] ) && mesh.IsOkToCollapse( aeCollapse[i] ) ) {
                mesh.EdgeCollapse( aeCollapse[i] );
            }
        }
        aeCollapse.need(0);
        mesh.Renumber();
    }
    
    count = 0;
    while ( count++ < 3 ) {
        if ( MeshSimplification::CheckMesh( mesh, false ) )
            break;
    }
    
    mesh.Write( in_strOut );
}

static void AngleFix( const char *in_strIn, const char *in_strOut, const double in_dAngSize )
{
    PMeshLite mesh;
    mesh.Read( in_strIn );
    
    int count = 0;
    Array<Face> afFix;
    Array<Edge> aeFlip;
    
    cout << "Input mesh " << in_strIn << " angle size " << in_dAngSize << "\n";
    R3Polygon poly;
    while ( count++ < 3 ) {
        double dMin = 1e30, dAvg = 0.0;
        double dAngsFound = 0.0;
        ForMeshFace( mesh.Mesh(), f ) {
            mesh.GetFacePolygon(f, poly);
            int iBig = 0;
            double dBig = 0.0;
            bool bReplace = false;
            for ( int i = 0; i < poly.Num_pts(); i++ ) {
                const double dDot = Dot( UnitSafe(poly.PtWrap(i-1) - poly[i]), UnitSafe(poly.PtWrap(i+1) - poly[i]) );
                const double dAng = acos( WINminmax( dDot, -1.0 + RNEpsilon_d, 1.0 - RNEpsilon_d ) );
                
                dAvg += dAng;
                dMin = WINmin( dMin, dAng );
                dAngsFound += 1.0;
                
                if ( dAng > dBig ) {
                    dBig = dAng;
                    iBig = i;
                }
                
                if ( dAng < in_dAngSize ) {
                    bReplace = true;
                }
            }
            if ( bReplace == true ) {
                afFix += f;
                aeFlip += mesh.FaceOppositeEdge( f, mesh.FaceVertices(f)[iBig] );
            }
        }EndFor;
        cout << "Found " << afFix.num() << " faces, min " << dMin << " avg " << dAvg / dAngsFound << "\n";
        
        if ( afFix.num() == 0 ) {
            break;
        }
        
        for ( int i = 0; i < afFix.num(); i++ ) {
            if ( mesh.Valid( aeFlip[i] ) && mesh.IsOkToSwap( aeFlip[i] ) && aeFlip.index( aeFlip[i] ) == i ) {
                mesh.EdgeSwap( aeFlip[i] );
            }
        }
        afFix.need(0);
        aeFlip.need(0);
    }
    
    count = 0;
    while ( count++ < 3 ) {
        if ( MeshSimplification::CheckMesh( mesh, false ) )
            break;
    }
    
    mesh.Write( in_strOut );
}

int main( int argc, char **argv  )
{
    PMeshLite mesh;
    //PDBMolecule( string( "/Users/cindygrimm/Grants/2010/NSFImageLab/1J6Z.pdb" ), string( "/Users/cindygrimm/Dropbox/HRBFImplicit/1J6Z" ), 1, 4.0 );
    //return 0;
    /*
    PMeshLite mesh;
    mesh.Read( WINDataHome("Points/000.580.67.ply") );
    ofstream out( WINDataHome("Points/FromWillow.txt") );
    out.precision(14);
    out << mesh.NumVertices() << "\n";
    ForMeshVertex( mesh.Mesh(), v ) {
        out << v->GetLoc() << "\n";
    }EndFor;
    out.close();
    */
    const char cCommand = (argc > 1 ) ? argv[1][0] : 'x';
    switch (cCommand) {
    case 'B' :
        cout << "Specific to processing bat ears. If you're not running bat ears, this is not a good idea\n";
        cout << "batname inputparams outputparams\n";
        Bats( argv[2], argv[3], argv[4] );
        break;
    case 'q' :        
            cout << "If using qslim, you will need to install the qslim program http://mgarland.org/software/qslim21.html\n";
            if ( argc == 9 ) {
                MeshSimplification::QSlim( argv[2], argv[3], argv[4], argv[5][0] == 't' ? true : false, atof( argv[6] ), atof( argv[7] ), atoi( argv[8] ) );
            } else if ( argc == 8 ) {
                MeshSimplification::QSlim( argv[2], argv[3], argv[4], argv[5][0] == 't' ? true : false, atof( argv[6] ), atof( argv[7] ), 10 );
            } else if ( argc == 7 ) {
                MeshSimplification::QSlim( argv[2], argv[3], argv[4], argv[5][0] == 't' ? true : false, atof( argv[6] ), 0.01, 10 );
            } else if ( argc == 6 ) {
                MeshSimplification::QSlim( argv[2], argv[3], argv[4], argv[5][0] == 't' ? true : false, 0.005, 0.01, 10 );
            } else if ( argc == 5 ) {
                MeshSimplification::QSlim( argv[2], argv[3], argv[4], false, 0.005, 0.05, 10 );
            } else {
                cout << "Not enough arguments to QSlim; quitting\n";
            }
        break;
        case 'Q' :        
            cout << "If using qslim, you will need to install the qslim program http://mgarland.org/software/qslim21.html\n";
            if ( argc >= 7 ) {
                const bool bBigPatch = (argc == 8) ? (argv[7][0] == 't' ? true : false) : true;
                if ( argv[5][0] == 'f' ) {
                    cout << "Target is number of faces\n";
                    MeshSimplification::QSlimTargetFaces( argv[2], argv[3], argv[4], bBigPatch, atoi( argv[6] ) );
                } else if ( argv[5][0] == 'p' ) {
                    cout << "Target is percentage of original mesh\n";
                    const double dPerc = atof( argv[6] );
                    if ( dPerc <= 0.0 || dPerc >= 1.0 ) {
                        cout << "Bad target percentage; should be between 0 and 1 " << dPerc << "\n";
                    } else {
                        MeshSimplification::QSlimTargetPercentage( argv[2], argv[3], argv[4], bBigPatch, atof( argv[6] ) );
                    }
                } else {
									cout << "Need t or f (argv[5][0]=" << argv[5][0] << ")\n";
                }
            } else {
                cout << "Not enough arguments to QSlim; quitting\n";
            }
            break;
        case 'c' :
            if ( argc == 4 ) {
                CheckMesh( argv[2], argv[3], true, false, -1);
            } else if ( argc == 5 ) {
                CheckMesh( argv[2], argv[3], argv[4][0] == 't' ? true : false, false, -1 );
            } else if ( argc == 6 ) {
                CheckMesh( argv[2], argv[3], argv[4][0] == 't' ? true : false, argv[5][0] == 't' ? true : false, -1 );
            } else if ( argc == 7 ) {
                CheckMesh( argv[2], argv[3], argv[4][0] == 't' ? true : false, argv[5][0] == 't' ? true : false, atoi(argv[6]) );
            } else {
                cout << "Wrong number of arguments to CheckMesh: quitting\n";
            }
            break;
        case 'e' :
            if ( argc == 5 ) {
                EdgeCollapse( argv[2], argv[3], atof(argv[4] ) );
            } else if ( argc == 4 ) {
                EdgeCollapse( argv[2], argv[3], 1e-12 );
            } else {
                cout << "Wrong number of arguments to edge collapse: quitting\n";
            }
            break;
        case 'a' :
            if ( argc == 5 ) {
                AngleFix( argv[2], argv[3], atof(argv[4] ) );
            } else if ( argc == 4 ) {
                AngleFix( argv[2], argv[3], 1e-2 );
            } else {
                cout << "Wrong number of arguments to angle fix: quitting\n";
            }
            break;
        case 'n' :
            if ( argc == 5 ) {
                AddNoise( argv[2], argv[3], atof(argv[4] ) );
            } else if ( argc == 4 ) {
                AddNoise( argv[2], argv[3], 1e-1 );
            } else {
                cout << "Wrong number of arguments to add noise: quitting\n";
            }
            break;
        case 's' :
            if ( argc == 6 ) {
                Smooth( argv[2], argv[3], atoi( argv[4] ), atof(argv[5] ) );
            } else if ( argc == 5 ) {
                Smooth( argv[2], argv[3], atoi( argv[4] ), 1.0 );
            } else if ( argc == 4 ) {
                Smooth( argv[2], argv[3], 3, 1.0 );
            } else {
                cout << "Wrong number of arguments to smooth: quitting\n";
            }
            break;
        case 'C' :
            if ( argc != 4 ) {
                cout << "Wrong number of arguments to convert, expected C filein fileout: quitting\n";                
            } else {
                cout << "Converting " << argv[2] << " to " << argv[3] << "\n";
                std::string strIn(argv[2]), strOut(argv[3]);
                std::transform(strIn.begin(), strIn.end(), strIn.begin(), ::toupper);
				std::transform(strOut.begin(), strOut.end(), strOut.begin(), ::toupper);
                if ( strIn.find(".OBJ") != string::npos && strOut.find(".PLY") != string::npos ) {
                    obj2ply( argv[2], argv[3], false );
                } else {
                    mesh.Read( argv[2] );
                    mesh.Write( argv[3] );
                }
            }
            break;
        case 'R' :
            if ( argc != 4 ) {
                cout << "Wrong number of arguments to reverse faces, expected R filein fileout: quitting\n";                
            } else {
                cout << "Reversing faces of " << argv[2] << ", writing to " << argv[3] << "\n";
                std::string strIn(argv[2]), strOut(argv[3]);
                std::transform(strIn.begin(), strIn.end(), strIn.begin(), ::toupper);
				std::transform(strOut.begin(), strOut.end(), strOut.begin(), ::toupper);
                mesh.Read( argv[2], true );
                mesh.Write( argv[3] );
            }
            break;
            
        default :
        cout << "Command not recognized\n\n";
        cout << "Parameter options\n";
        cout << "QSlim binary search\n";
        cout << "q filenameData filenameInitialMesh filenameOutputMesh t/f avgPerc maxPerc maxCount\n";
        cout << "  t/f is whether or not to triangulate big holes, default true\n";
        cout << "  avgPerc/maxPerc are percentage of bounding box, default 0.005, 0.01, and 10\n\n";
            
        cout << "QSlim target faces\n";
        cout << "Q filenameData filenameInitialMesh filenameOutputMesh f/p NFaces/percentage t/f\n";
        cout << "  f/p: f is target number of faces, p is target percentage of original mesh\n";
        cout << "  NFaces/percentage: NFaces if f, percentage if p\n";
        cout << "  t/f is whether or not to triangulate big holes, default true\n\n";
            
        cout << "Check mesh, fixing small topological/manifold mesh problems\n";
        cout << "c filenameIn filenameOut t/f t/f nToPatch \n";
        cout << "  the first t/f is whether or not to ensure a triangulation, default t\n";
        cout << "  the second t/f is whether or not to patch big holes with a vertx, default f\n";
        cout << "  nToPatch is the maximum size hole to patch with a vertex. Default is -1, which will patch all holes\n";
        cout << "  filenameIn and filenameOut can be the same\n\n";
            
        cout << "Collapse any small edges\n";
        cout << "e filenameIn filenameOut minEdgeSize\n";
        cout << "  minEdgeSize is in absolute terms, default 1e-12\n";
        cout << "  filenameIn and filenameOut can be the same\n\n";

        cout << "Try to fix angles that are very small\n";
        cout << "a filenameIn filenameOut minAngleSize\n";
        cout << "  minAngleSize is in radians, default 1e-2\n";
        cout << "  filenameIn and filenameOut can be the same\n\n";
            
        cout << "Add Gaussian noise\n";
        cout << "n filenameIn filenameOut noise\n";
        cout << "  noise is in percentage of bounding box\n";
        cout << "  filenameIn and filenameOut can be the same\n\n";
            
        cout << "Smooth. Applies Laplacian smoothing using Desbrun's cotan weights. Does volume preservation\n";
        cout << "   In general, more loops with percMove smaller will result in better volume preservation\n";
        cout << "s filenameIn filenameOut loops percMove\n";
        cout << "  Loops is number of times to apply smoothing (default 3)\n";
        cout << "  percMove is the percentage to move to centroid, range 0-1 (default 1.0) \n";
        cout << "  filenameIn and filenameOut can be the same\n\n";
            
        cout << "Convert/save as different mesh type\n";
        cout << "C filenamein filenameout\n";
        cout << "  input types: off, ply, iv, obj, m (ours), bm (ours binary)\n";
        cout << "  output types: off, ply, iv, m, bm\n\n";
            
        cout << "Reverse the orientation of the faces\n";
        cout << "R filenamein filenameout\n";
        cout << "  input types: off, ply, iv, m (ours), bm (ours binary)\n";
        cout << "  output types: off, ply, iv, m, bm\n\n";
            
        break;
    }
    
    return 0;
}

///Library/Frameworks/Intel_MKL.framework/Versions/Current/lib/32
