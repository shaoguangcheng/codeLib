#ifdef WIN32
#include <FL/gl.h>
#include <GL/glu.h>
#else
# if defined(powerpc) || defined(__APPLE__)
#   include <OpenGL/gl.h>
#   include <OpenGL/glu.h>
# else
#   include <GL/gl.h>
#   include <GL/glu.h>
# endif
#endif

#include "MeshViewer.h"
#include "UserInterface.h"
#include <meshOperations/SD_FileNames.H>
#include <meshOperations/SD_SampleRings.H>

using namespace Features;
using namespace Features::SignatureNames;
using namespace Features::DataSetNames;
using namespace Features::IntermediateStorageNames;


char g_strDataHome[] = "./";



int	main( int argc,	char **	argv )
{
	bool bIsOk = false, bDataSetIsOk = false, bSignatureIsOk = false;
    std::string strFile;
    SignatureNames::Signature sig;
    bool bSphere = true;
    
    if ( argc < 2 ) {
        bIsOk = false;
    }
    if ( argc > 1 ) {
        strFile = std::string( argv[1] );
        if ( DataSetNames::AddDataSet( strFile ) ) {
            cout << "Reading data set " << strFile << "\n";
            bDataSetIsOk = true;
            bIsOk = true;
        }
    }
     
    if ( bIsOk == true && argc > 2 ) {
        sig = SignatureNames::GetSignature( std::string( argv[2] ) );
        if ( bIsOk == true && sig.first != SignatureNames::numMetricTypes ) {
            cout << "Reading shape descriptor " << SignatureNames::ShortSignatureName( sig ) << "\n";
            bIsOk = true;
            bSignatureIsOk = true;
        } else {
            bIsOk = false;
            cerr << "Unknown shape descriptor type " << argv[2] << ". Options are:\n";
            SignatureNames::PrintNames( cout );
            cout.flush();
        }
    }
    if ( bIsOk == true && argc > 3 ) {
        const std::string strSample( argv[3] );
        if ( !strSample.compare( "sphere") ) {
            cout << "Using spherical sampling\n";
            bSphere = true;
        } else if ( !strSample.compare("circle") ) {
            cout << "Using exponential map/planar sampling\n";
            bSphere = false;
        } else {
            bIsOk = false;
            cerr << "Sampling type should be sphere or circle\n";
        }
    }
    if ( bIsOk == true && argc > 4 ) {
        sscanf( argv[4], "%lf", &Features::g_dMaxRadius );
        if ( Features::g_dMaxRadius <= 0.0 || Features::g_dMaxRadius > 0.75 ) {
            cerr << "Percentage of bounding box should be in range 0 to 0.75\n";
            bIsOk = false;
        }
        cout << "Bounding box percentage: " << Features::g_dMaxRadius << "\n";
    }    
    
    if ( bIsOk == false ) {
        cout << "\n\nOptional arguments are: Filename.txt metric sphere/circle PercBBox \n";
        cout << " Filename.txt: A text file with information on the meshes to use.\n";
        cerr << "  format is: First line is the absolute path name to the directory containing the data\n";
        cout << "             Second line is the directory name containing the individual directories\n";
        cout << "             Subsequent lines are the mesh directories (usually meshname/meshname.ply)\n";
        cout << "  Make sure the directory absolutepath + directory + AllData exists\n";
        cout << " metric: Shape descriptor name, one of: \n";
        SignatureNames::PrintNames( cout, false );
        cout << " sphere/circle: Should be one of sphere or circle. Default is sphere\n";
        cout << " PercBBox: A floating point value in the range 0 to 0.1 or so. What to set the feature size to, as a percentage of the bounding box. Default is 0.0375.\n";
    }
        
	UserInterface *window =	new	UserInterface( );
	window->m_meshViewer->SetUI( window	);
	window->m_mainWindow->show();
    
    if ( bDataSetIsOk == true ) {        
        window->m_meshViewer->ReadDataSet( Features::DataSetNames::fromFile );
        window->m_strDataSet->value( Features::DataSetNames::DataSetName( Features::DataSetNames::fromFile ).c_str() );
    }
    if ( bSignatureIsOk == true ) {
        window->m_meshViewer->ReadSignature( sig );
    }
    if ( bIsOk == true ) {
        if ( bSphere ) {
            window->m_bSphere->value(1);
            window->m_bCircle->value(0);
        } else {
            window->m_bSphere->value(0);
            window->m_bCircle->value(1);
        }
    }
	return Fl::run();
    
}//main

