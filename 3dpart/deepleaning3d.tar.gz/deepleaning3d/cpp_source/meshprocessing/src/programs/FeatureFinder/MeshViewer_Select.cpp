/*
 *  MeshViewer_Select.cpp
 *  FeatureFinder
 *
 *  Created by Cindy Grimm on 6/8/11.
 *  Copyright 2011 Washington University in St. Louis. All rights reserved.
 *
 */


#include "MeshViewer.h"
#include "UserInterface.h"

const bool s_bTrace = false;

bool MeshViewer::SetIdsForMesh()
{   
    static int s_iLastMesh = -1;
    
    const int iWhichMesh = m_opUI->m_iWhichMesh->value();
    if ( iWhichMesh < 0 || iWhichMesh >= m_aopDataSets.num() || s_iLastMesh == iWhichMesh ) {
        return false;
    }

    if ( s_bTrace ) { cout << "Setting ids for " << iWhichMesh << "\n"; }
    
    const PMeshLite &mesh = m_aopDataSets[iWhichMesh]->Mesh();
    
    // Delete old lists
    if (  m_uiImageIdDisplayList != 0 )
        glDeleteLists( m_uiImageIdDisplayList, 1 );
    
    // Make new ones
    m_uiImageIdDisplayList = glGenLists( 1 );
    
    // Or make the new id list
    glNewList( m_uiImageIdDisplayList, GL_COMPILE_AND_EXECUTE );
    
    const double dScl = m_opUI->m_sldZoom->value();
    glScaled( dScl, dScl, dScl );

	R3PointTC<GLubyte> rgbId;
    ForMeshFace( mesh.Mesh(), f ) {
        rgbId = IdToColor( f->Id() );
        glColor4ub( rgbId[0], rgbId[1], rgbId[2], 255 );
        
        glBegin(GL_POLYGON);
        
        ForFaceVertex( m_mesh.Mesh(), f, v ) {
            const R3Pt &p = v->GetLoc();
            
            glVertex3d( p[0], p[1], p[2] );
        } EndFor;
        glEnd();
    }EndFor;
    
    glEndList();    
    
    s_iLastMesh = iWhichMesh;
    return true;
}


void MeshViewer::GenerateIdDisplayList()
{
	// Disable lighting, blending, etc
	glPushAttrib( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ENABLE_BIT );
    
    glDepthMask(GL_TRUE);
    glDepthFunc(GL_LESS);
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_NORMALIZE);
    glDisable(GL_BLEND);
    glDisable(GL_ALPHA_TEST);
    glDisable(GL_COLOR_MATERIAL);
    glEnable(GL_CULL_FACE);
    glShadeModel(GL_FLAT);
    glDisable(GL_LIGHTING);                // GL_LIGHTING_BIT
    
    glCallList( m_uiImageIdDisplayList );
    
	glPopAttrib();
}

///
void MeshViewer::SetImageIDs()
{
    m_iptImageIdSize[0] = GetCamera().Width();
    m_iptImageIdSize[1] = GetCamera().Height();
    
    glClearColor( 0.0f, 0.0f, 0.0f, 1.0f );
    
    glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
    
    GetCamera().SetOpenGLCamera();
    
    if ( s_bTrace )  cout << "Generate id list\n";
    GenerateIdDisplayList();
    
    const int iN = m_iptImageIdSize[0] * m_iptImageIdSize[1] * 4;
    m_aiImageIds.need( iN );
    
    if ( s_bTrace )  cout << "Reading buffer: glError ";
    m_aiImageIds.fill( 0 );
    
    ::glReadBuffer( GL_BACK );
    ::glReadPixels( 0, 0, m_iptImageIdSize[0], m_iptImageIdSize[1], GL_RGBA, GL_UNSIGNED_BYTE, (GLvoid *) &m_aiImageIds[0] );
    if ( s_bTrace )  cout << glGetError() << "\n";
    
    if ( s_bTrace ) {
        const int iWhichMesh = m_opUI->m_iWhichMesh->value();
        if ( iWhichMesh < 0 || iWhichMesh >= m_aopDataSets.num() ) {
        
            const PMeshLite &mesh = m_aopDataSets[iWhichMesh]->Mesh();
            for ( int iX = 0; iX < m_iptImageIdSize[0]; iX++ ) {
                for ( int iY = 0; iY < m_iptImageIdSize[1]; iY++ ) {
                    const int iPix = 4 * (iY * m_iptImageIdSize[0] + iX);
                    const int iD = ColorToId( m_aiImageIds[ iPix ], m_aiImageIds[ iPix + 1 ], m_aiImageIds[ iPix + 2 ] );
                    ASSERT ( iD < mesh.NumFaces() + 1 );
                }
            }
        }
    }
    
    if ( s_bTrace )  cout << "Done SetImageIds()\n";
    
    m_bCameraChanged = false;
}

///
int MeshViewer::GetMeshId( const R2Pt &in_ptCamera ) 
{
    const int iPixX = WINminmax( (int) ( m_iptImageIdSize[0] * 0.5 * ( in_ptCamera[0] + 1.0 ) ), 0, m_iptImageIdSize[0] - 1 );
    const int iPixY = WINminmax( (int) (m_iptImageIdSize[1] * 0.5 * ( in_ptCamera[1] + 1.0 ) ), 0, m_iptImageIdSize[1] - 1 );
    
    const int iPix = 4 * (iPixY * m_iptImageIdSize[0] + iPixX);
    
    if ( m_aiImageIds.num() )
        return ColorToId( m_aiImageIds[ iPix ], m_aiImageIds[ iPix + 1 ], m_aiImageIds[ iPix + 2 ] );
    
    return -1;
}

Face MeshViewer::SelectMeshId( const R2Pt &in_ptCamera )
{
    const bool bMeshChanged = SetIdsForMesh();
    
    if ( bMeshChanged || m_bCameraChanged ) {
        SetImageIDs();
    }
    
    if ( s_bTrace ) cout << "Start select\n";
	const int iId = GetMeshId( in_ptCamera );
    if ( s_bTrace ) cout << "Id " << iId << "\n";
    
	if ( iId == 0 ) {
        if ( s_bTrace ) cout << "No face\n";
		return NULL;
	}
    
    const int iWhichMesh = m_opUI->m_iWhichMesh->value();
    if ( iWhichMesh >= 0 && iWhichMesh < m_aopDataSets.num() ) {
        const PMeshLite &mesh = m_aopDataSets[iWhichMesh]->Mesh();
        if ( iId <= mesh.NumFaces() ) {
            return mesh.FaceFromId( iId );
        }
    }
    return NULL;
}


