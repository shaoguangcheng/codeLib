/*
 *  MeshViewer_Features.cpp
 *  FeatureFinder
 *
 *  Created by Cindy Grimm on 10/26/10.
 *  Copyright 2010 Washington University in St. Louis. All rights reserved.
 *
 */


#include "MeshViewer.h"
#include "UserInterface.h"
#include <utils/Utils_Barys.H>

using namespace Features::DataSetNames;
using namespace Features::IntermediateStorageNames;
using namespace Features::SignatureNames;


void MeshViewer::NewFeature( const int in_iType, const char *in_strName )
{
    m_aopFeatures += new FeatureBase;
    m_aopFeatures.last()->Set( (FeatureBase::FeatureType) (in_iType), string( in_strName ), NumMeshes( m_dataSet ) );
    m_opUI->m_iWhichFeature->maximum( m_aopFeatures.num() );
    m_opUI->m_iWhichFeature->value( m_aopFeatures.num() - 1 );
}

void MeshViewer::UpdateFeature( const int in_iType, const char *in_strName )
{
    const int iWhich = (int) m_opUI->m_iWhichFeature->value();
    
    if ( m_aopFeatures.num() > iWhich && iWhich >= 0 ) {        
        m_aopFeatures.last()->Set( (FeatureBase::FeatureType) (in_iType), string( in_strName ), NumMeshes( m_dataSet ) );
    }
}

void MeshViewer::PickPoint()
{
    if ( m_opUI->m_bShowOne->value() == false ) {
        return;
    }

    const int iWhich = (int) m_opUI->m_iWhichFeature->value();
    
    if ( iWhich >= m_aopFeatures.num() || iWhich < 0 ) {        
        return;
    }    
    
    const int iWhichMesh = m_opUI->m_iWhichMesh->value();
    if ( iWhichMesh < 0 || iWhichMesh >= m_aopDataSets.num() ) {
        return;
    }

    const PMeshLite &mesh = m_aopDataSets[iWhichMesh]->Mesh();
    
    const Face fFace = SelectMeshId( m_ptLast );
    if ( fFace ) {
        const double dScl = m_opUI->m_sldZoom->value();
        const R3Matrix matScl = R3Matrix::Scaling( dScl, dScl, dScl );
        
        const Array<Vertex> avF = mesh.FaceVertices(fFace);
        R2Polygon poly(3);
        for ( int i = 0; i < 3; i++ ) {
            poly[i] = m_IBar.CameraPt( matScl * avF[i]->GetLoc() );
        }
        const R3Pt ptBary = UTILSBarys::BaryCoords(poly, m_ptLast );
        m_aopFeatures[iWhich]->SetPoint( iWhichMesh, mesh, fFace, ptBary );
    }
}

const char *MeshViewer::FeatureName( const int in_i ) const
{
    const int iWhich = (int) m_opUI->m_iWhichFeature->value();
    if ( iWhich >= m_aopFeatures.num() || iWhich < 0 ) {        
        return "none";
    }    
    return m_aopFeatures[iWhich]->FeatureName().c_str();
}

int MeshViewer::FeatureType( const int in_i ) const
{
    const int iWhich = (int) m_opUI->m_iWhichFeature->value();
    if ( iWhich >= m_aopFeatures.num() || iWhich < 0 ) {        
        return 0;
    }    
    return (int) m_aopFeatures[iWhich]->GetFeatureType();
}

void MeshViewer::WriteFeatures( ) const
{
    ::Write( m_aopFeatures, FullPathName( m_dataSet, features ) );
}

void MeshViewer::ReadFeatures( ) 
{
    ReadFeatureFile( FullPathName( m_dataSet, features ) );
}






