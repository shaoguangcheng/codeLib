#include <utils/Rn_Defs.H>
#include <utils/Mesh_GMesh.H>
#include <utils/Mesh_Intersect.H>

static
WINbool Project_box( R3Pt &io_p, const R3Vec &in_vTo, WINbool in_bUseVec )
{
    static Array<R3Polygon> s_apolys(6);
    const float fZero = -1e-4f, fOne = 1.0f + 1e-4f;

    static double s_adPoly[6][4][3] = 
    { { {fZero, fZero, 0}, {fZero, fOne, 0}, {fOne, fOne, 0}, {fOne, fZero, 0} },
      { {fZero, fZero, 1}, {fOne, fZero, 1}, {fOne, fOne, 1}, {fZero, fOne, 1} },
      { {fZero, 0, fZero}, {fZero, 0, fOne}, {fOne, 0, fOne}, {fOne, 0, fZero} },
      { {fZero, 1, fZero}, {fZero, 1, fOne}, {fOne, 1, fOne}, {fOne, 1, fZero} },
      { {0, fZero, fZero}, {0, fZero, fOne}, {0, fOne, fOne}, {0, fOne, fZero} },
      { {1, fZero, fZero}, {1, fZero, fOne}, {1, fOne, fOne}, {1, fOne, fZero} } };
    static WINbool s_bInitd = FALSE;

    if ( s_bInitd == FALSE ) {
        for (int i = 0; i < 6; i++) {
            s_apolys[i] = R3Polygon(4);
            for (int j = 0; j < 4; j++)
                for (int k = 0; k < 3; k++)
                    s_apolys[i][j][k] = s_adPoly[i][j][k];
        }

        s_bInitd = TRUE;
    }

    if ( io_p[0] >= 0 && io_p[0] <= 1.0 &&
         io_p[1] >= 0 && io_p[1] <= 1.0 &&
         io_p[2] >= 0 && io_p[2] <= 1.0 ) {
        return TRUE;
    }

    R3Pt pIntersect, pOut;    
    double dMinDist = 1e30;
    WINbool bRet = FALSE;
    if ( in_bUseVec ) {
        R3Vec vec = UnitSafe(in_vTo) * (Length( io_p - R3Pt(0,0,0) ) * 4);
        R3Line_seg seg( io_p + vec, io_p - vec);

        for ( int i = 0; i < 6; i++) {
            if ( s_apolys[i].IntersectSegment( seg, pIntersect ) ) {
                const double dDist = LengthSq( pIntersect - io_p );
                bRet = TRUE;
                if ( dDist < dMinDist ) {
                    dMinDist = dDist;
                    pOut = pIntersect;
                }
            }
        }
    } else {
        bRet = TRUE;
        double dDist = 0;
        R3Pt ptPlane, ptTri;
        Array<double> adBary;
        for ( int i = 0; i < 6; i++) {
            s_apolys[i].ProjectTri( io_p, dDist, ptPlane, ptTri, adBary );
            if ( dDist < dMinDist ) {
                dMinDist = dDist;
                pOut = ptTri;
            }
        }

    }
    if ( bRet ) {
        io_p = pOut;
    }
    // Deal with round-off errors
    for (int k = 0; k < 3; k++) {
        io_p[k] = WINminmax(io_p[k], 0.0, 1.0);
    }
    return bRet;
}

GMeshIntersect::GMeshIntersect( const GMesh &in_mesh ) 
: m_mesh( in_mesh ), 
  m_bInitd(FALSE),
  m_oPsp(40)
{
}

void GMeshIntersect::SetSpatialStructures()
{
    if (m_bInitd == TRUE ) 
        return;

	R3Pt ptMin(1e30, 1e30, 1e30);
	R3Pt ptMax(-1e30, -1e30, -1e30);

    m_meshTrans.clear();
	ForMeshVertex( m_mesh, v ) {
		const R3Pt &p = v->GetLoc();
		for (int j = 0; j < 3; j++) {
			ptMin[j] = WINmin(ptMin[j], (double) p[j]);
			ptMax[j] = WINmax(ptMax[j], (double) p[j]);
		}
        Vertex nv = m_meshTrans.createVertexI( m_mesh.vertexid(v) );
        m_meshTrans.setPoint( nv, p );
	} EndFor;

	R3Pt ptCenter, ptScale;
	for (int j = 0; j < 3; j++) {
		ptScale[j] = ptMax[j] - ptMin[j];
        ptCenter[j] = (RNIsZero(ptScale[j]) ? 0.0 : (0.5 * (ptMax[j] + ptMin[j])) );
	}

    const double dScale = 0.9 / ( WINmax( ptScale[0], WINmax( ptScale[1], ptScale[2] ) ) );
    
    m_frameTrans = 
        R4Matrix::Translation( R3Vec(0.5, 0.5, 0.5) ) *
        R4Matrix::Scaling( dScale, dScale, dScale, 1.0 ) * 
        R4Matrix::Translation( R3Pt(0,0,0) - ptCenter );
    m_frameTransi = 
        R4Matrix::Translation( ptCenter - R3Pt(0,0,0) ) *
        R4Matrix::Scaling( 1.0 / dScale, 1.0 / dScale, 1.0 / dScale, 1.0 ) * 
        R4Matrix::Translation( R3Vec(-0.5, -0.5, -0.5) );

    Array<Vertex>   av(3), avTri(3);

    // Add faces m_meshTrans, splitting n > 3 faces
    ForMeshFace( m_mesh, fOrig ) {
        m_mesh.vertices( fOrig, av );

        if ( av.num() == 3 ) {
            for ( int iV = 0; iV < av.num(); iV++ )
                avTri[iV] = m_meshTrans.idvertex( m_mesh.vertexid( av[iV] ) );

            Face f = m_meshTrans.createFace( avTri );
            m_oTriMap.enter( f, fOrig );
            m_oSideMap.enter( f, 0 );
        } else {
            avTri[0] = m_meshTrans.createVertex();
            R3Polygon poly;
            m_mesh.polygon( fOrig, poly );
            m_meshTrans.setPoint( avTri[0], poly.Centroid() );
            for ( int iV = 0; iV < poly.Num_pts(); iV++ ) {
                avTri[1] = m_meshTrans.idvertex( m_mesh.vertexid( av[iV] ) );
                avTri[2] = m_meshTrans.idvertex( m_mesh.vertexid( av.wrap(iV+1) ) );
                Face f = m_meshTrans.createFace( avTri );
                m_oTriMap.enter( f, fOrig );
                m_oSideMap.enter( f, iV );
            }
        }
    } EndFor;

    m_meshTrans.transform(m_frameTrans);
    m_apoly.need( m_meshTrans.numFaces() );

    int iCount = 0;
    ForMeshFace(m_meshTrans, f) {
        m_meshTrans.polygon(f, m_apoly[iCount]);
#ifdef DEBUG
        for ( int i = 0; i < m_apoly[iCount].Num_pts(); i++ ) {
            for ( int j = 0; j < 3; j++ ) {
                /*
                if ( isnan( m_apoly[iCount][i][j] || isinf( m_apoly[iCount][i][j] ) ) {
                    ForFaceVertex( m_meshTrans, f, v ) {
                        cout << v->IndexId() << " " << v->GetLoc();
                    }EndFor;
                    cout << "\n";
                    ForFaceVertex( m_mesh, m_mesh.idface( m_meshTrans.faceid(f) ), v ) {
                        cout << v->IndexId() << " " << v->GetLoc();
                    }EndFor;
                }
                 */
                ASSERT( m_apoly[iCount][i][j] >= 0.0 && m_apoly[iCount][i][j] <= 1.0 );
            }
        }
#endif
        m_oPsp.enter( m_apoly[iCount] );
        m_oMpf.enter( &m_apoly[iCount], f );
        iCount++;
    } EndFor;

    m_meshTrans.transform(m_frameTransi);

    m_bInitd = TRUE;
}

void GMeshIntersect::ClearSpatialStructures()
{
    if ( m_bInitd == TRUE ) {
        m_oPsp.clear();
        m_oMpf.clear();
        m_oTriMap.clear();
        m_oSideMap.clear();
        m_meshTrans.clear();

        m_meshTrans.clear();
        m_apoly.clearcompletely();
        m_bInitd = FALSE;

    }
}


WINbool 
GMeshIntersect::IntersectRay( const R3Pt      & in_pt, 
                              const R3Vec     & in_vec, 
                              Array<Face >    & out_afaces, 
                              Array< Array<double> > & out_aadBarys,
                              Array<R3Pt> &out_apts ) 
{
    out_afaces.clearcompletely();
    out_aadBarys.clearcompletely();
    out_apts.clearcompletely();

    SetSpatialStructures();

    const R3Vec vec = UnitSafe(in_vec);
    R3Pt p1(in_pt);
    R3Pt p2 = m_frameTrans * ( in_pt + vec );
    p1 = m_frameTrans * p1;

    const R3Vec vecAddUnit = UnitSafe(p2 - p1);

    // Quick check to see if we hit the bounding box
    if ( Project_box( p1, vecAddUnit, TRUE ) == FALSE ) return FALSE;
    p2 = p1 + vecAddUnit * 2.0;

    Project_box( p2, -vecAddUnit, TRUE );

    const R3Vec vec2 = vecAddUnit * 0.01;
    const R3Vec vecAdd =  vecAddUnit * 0.00001;

    const R3Pt pLeft = p1;
    const R3Pt pRight = p2;
    R3Pt pMid = p1 + vec2 * 10.0;

    R3Pt pFound, ptPlane, ptTri;
    double dDist;
    Array<double> adBary; 

    const R3Polygon *spoly;
    int iCount = 0;
    Array<int> aiSide;
    while ( m_oPsp.firstAlongSegment( p1, p2, spoly, pFound) && iCount < 10) {
        Face f = m_oMpf.get( spoly );

        spoly->ProjectTri( pFound, dDist, ptPlane, ptTri, adBary );
        if ( !(ApproxEqual( ptTri, pFound, 1e-4 ) ) ) {
            cerr << "Warning, bad tri intersection " << f->IndexId() << " tri " << ptTri << " found " << pFound << "\n";
        }

        Face oFace = m_oTriMap.get( f );
        const int iSide = m_oSideMap.get( f );

        int iIndx = out_afaces.index( oFace );
        if ( iIndx == -1 || aiSide[iIndx] != iSide ) {
            Array<double> adBarys( m_mesh.numVertices( oFace ) );
            out_afaces += oFace;

            if ( adBarys.num() == 3 ) {
                adBarys = adBary;
            } else {
                const double dSum = adBary[0] / (double) adBarys.num();
                for ( int i = 0; i < adBarys.num(); i++ )
                    adBarys[i] = dSum;

                for (FORINT i = 1; i < 3; i++)
                    adBarys.wrap( iSide + i - 1 ) += adBary[i];
            }
            out_aadBarys += adBarys;
            aiSide += iSide;
            out_apts += m_frameTransi * pFound;
            p1 = pFound + vecAdd;
            const R3Vec v = spoly->Normal();
            if ( fabs( Dot( v, vecAddUnit ) ) < 0.01 )
                p1 = pFound + vec2;
        } else {
            if ( Length( ptTri - out_apts.last() ) > 0.001 ) {
                const R3Vec v = spoly->Normal();
                cerr << "Double poly normals " << iCount << " " << Dot(v, vecAddUnit) << "\n";
                for (int iJ = 0; iJ < out_apts.num(); iJ++)
                    cerr << out_apts[iJ][0] << " " << out_apts[iJ][1] << " " << out_apts[iJ][2] << "\n";
                cerr << "ptTri " <<  ptTri[0] << " " << ptTri[1] << " " << ptTri[2] << "\n\n";
            } else {
                out_apts.last() = Lerp( out_apts.last(), ptTri, 0.5 );
            }
            p1 = p1 + vec2;
            iCount++;
        }
        for (int k = 0; k < 3; k++)
            p1[k] = WINminmax(p1[k], 0.0, 1.0);

    }
    //ASSERT( iCount < 10 );

    return (out_afaces.num() ? TRUE : FALSE);
}

Vertex GMeshIntersect::ClosestVertex( const R3Pt    & in_pt )
{
    Face f;
    Array<double> adBary;
    
    Closest( in_pt, f, adBary );
    int iIndex = 0;
    Vertex vClosest = NULL;
    double dClosest = 1e30;
    ForFaceVertex( Mesh(), f, v ) {
        if ( fabs( adBary[iIndex] ) < dClosest ) {
            dClosest = fabs( adBary[iIndex] );
            vClosest = v;
        }
        iIndex++;
    }EndFor;
    return vClosest;
}
    
R3Pt GMeshIntersect::Closest( const R3Pt    & in_pt, 
                              Face          & out_face, 
                              Array<double> & out_bary)
{
    static R3Vec s_vecDummy(0,1,0);

    SetSpatialStructures();

    Array<double> adBary;
    R3Pt ptTrans = m_frameTrans * in_pt;
    if ( ptTrans[0] < 0.0 || ptTrans[0] >= 1.0 ||
         ptTrans[1] < 0.0 || ptTrans[1] >= 1.0 ||
         ptTrans[2] < 0.0 || ptTrans[2] >= 1.0 ) {
        Project_box( ptTrans, s_vecDummy, FALSE );
    }

    R3Pt ptTri, ptPlane;
    double dDist;

    SpatialSearch ss( m_oPsp, ptTrans );
    Univ oUniv = ss.next();
    if ( oUniv == NULL ) {
        out_face = NULL;
        out_bary.need(0);
    } else {
        const R3Polygon * spoly = (const R3Polygon *) oUniv;
        Face f = m_oMpf.get( spoly );

        spoly->ProjectTri( ptTrans, dDist, ptPlane, ptTri, adBary );

        out_face = m_oTriMap.get( f );
        const int iSide = m_oSideMap.get( f );

        out_bary.need( m_mesh.numVertices( out_face ) );
        
        
        if ( out_bary.num() == 3 ) {
            for (int i = 0; i < 3; i++) {
                out_bary[i] = adBary[i];
            }
        } else {
            const double dSum = adBary[0] / (double) out_bary.num();
            for ( int i = 0; i < out_bary.num(); i++ )
                out_bary[i] = dSum;

            for (FORINT i = 1; i < 3; i++)
                out_bary.wrap( iSide + i - 1 ) += adBary[i];
        }
    }
    return m_frameTransi * ptTri;
}

R3Pt GMeshIntersect::ClosestInFace( const R3Pt     & in_pt, 
                                    const Face       in_face, 
                                    Array<double>  & out_bary) const
{
    R3Polygon poly;
    m_mesh.polygon( in_face, poly );

    R3Pt ptTri, ptPlane;
    double dDist;

    poly.ProjectTri( in_pt, dDist, ptPlane, ptTri, out_bary );

    return ptTri;
}


R3Pt GMeshIntersect::Closest(const R3Pt &in_pt, WINbool &out_bIsBoundary )
{
    Face           oFace;
    Array<double>  adBary;

    R3Pt out_pt = Closest( in_pt, oFace, adBary );

    out_bIsBoundary = FALSE; 
    if ( oFace == NULL ) {
        return out_pt;
    }

    if ( !m_mesh.isBoundary( oFace ) )
        return out_pt;

    Array<Vertex > aopVs;
    m_mesh.vertices( oFace, aopVs );

    int iLeft = -1, iRight = -1;
    for (int i = 0; i < adBary.num(); i++) {
        if ( ! RNIsZero( adBary[i] ) ) {
            if ( iLeft == -1 )
                iLeft = i;
            else if ( iRight == -1 )
                iRight = i;
            else {
                out_bIsBoundary = FALSE;
                return out_pt;
            }
        }
    }
    if ( iRight == -1 )
        out_bIsBoundary = m_mesh.isBoundary( aopVs[iLeft] ) ? TRUE : FALSE;
    else {
        if (m_mesh.isBoundary( aopVs[iRight] ) && m_mesh.isBoundary( aopVs[iLeft] ))
            out_bIsBoundary = TRUE;
    }
    return out_pt;
}

R3Pt GMeshIntersect::Closest(const R3Pt &in_pt )
{
    Face           oFace;
    Array<double>  adBary;

    return Closest( in_pt, oFace, adBary );
}

R3Pt    
GMeshIntersect::ClosestOnBoundary( const R3Pt &in_pt, Edge &out_edge, R2Pt &out_blend ) 
{
    double dMin = 1e30;
    double dBlend = 0, dDist = 0;

    out_edge = NULL;
    R3Pt ptOut(0,0,0), ptClosest(0,0,0);
    ForMeshEdge(m_mesh, e) {
        if ( !m_mesh.isBoundary(e) )
            continue;

        const R3Pt &p1 = m_mesh.vertex1(e)->GetLoc();
        const R3Pt &p2 = m_mesh.vertex2(e)->GetLoc();
        const R3Line_seg seg( p1, p2 );
        seg.FindPtOnSeg( in_pt, ptClosest, dBlend, dDist );

        if ( dDist < dMin ) {
            out_edge = e;
            out_blend = R2Pt( dBlend, 1.0 - dBlend );
            ptOut = ptClosest;
            dMin = dDist;
        }

    }EndFor;

    return ptOut;
}



WINbool 
GMeshIntersect::IntersectRay( const R3Pt  & in_pt, 
                              const R3Vec & in_vec, 
                              Array<R3Pt> & out_pts )
{
    Array<Face>        aopFs;
    Array< Array<double> > aadBarys;

    return IntersectRay( in_pt, in_vec, aopFs, aadBarys, out_pts );
}

WINbool 
GMeshIntersect::IntersectRay( const R3Pt      & in_pt, 
                              const R3Vec     & in_vec, 
                              Array<Face >    & out_faces, 
                              Array< Array<double> > & out_barys ) 
{
    Array<R3Pt> apt;

    return IntersectRay( in_pt, in_vec, out_faces, out_barys, apt );
}

GMeshIntersect::~GMeshIntersect()
{
    ClearSpatialStructures();
}
