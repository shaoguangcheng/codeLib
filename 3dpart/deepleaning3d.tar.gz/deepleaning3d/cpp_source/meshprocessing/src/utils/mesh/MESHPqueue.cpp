// This may look like C code, but it is really -*- C++ -*-
// Copyright (c) 1992 Hugues H. Hoppe; All rights reserved.

#include <utils/Mesh_Hh.H>

#include <utils/Mesh_Pqueue.H>


//*** BPqueue

BPqueue::BPqueue(int size)
: isize(size?size:1), inum(0), ar(new Node[isize]) { }

BPqueue::~BPqueue() { delete[] ar; }

void BPqueue::clear() { inum=0; }

inline void BPqueue::nswitch(int n1, int n2)
{
    swap(&ar[n1],&ar[n2]);
}

void BPqueue::adjust(int n, int up, int down) // copied to BHPqueue!
{
    const double cp=ar[n].pri;
    int nn=0;                   // dummy initialization
    for (;;nswitch(n,nn),n=nn) {
        if (up) {
            nn=(n-1)/2;
            if (n && cp<ar[nn].pri) continue;
        }
        if (!down) break;
        int ln=n*2+1;           // left child
        if (ln>=inum) break;    // no children
        double lp=ar[ln].pri;
        int rn=n*2+2;           // right child
        if (rn>=inum) {         // no right child
            if (lp<cp) { nn=ln; continue; }
            break;
        }
        double rp=ar[rn].pri;
        if (lp<cp && lp<rp) { nn=ln; continue; }
        if (rp<cp) { nn=rn; continue; }
        break;
    }
}

void BPqueue::enter(Univ e, double pri) // copied to BHPqueue!
{
    enterUnsorted(e,pri);
    adjust(inum-1,1,0);
}

void BPqueue::sort()            // copied to BHPqueue!
{
    for (int i = (inum-2)/2; i >= 0; i--) { 
        adjust(i,0,1); 
    }
}

Univ BPqueue::removemin()       // adapted to BHPqueue!
{
    MESHassertx(inum);
    Univ e=ar[0].e;
    if (inum>1) nswitch(0,inum-1);
    if (--inum>1) adjust(0,0,1);
    return e;
}

// valid for BHPqueue also
void BPqueue::resize(int newsize)
{
    MESHassertx(newsize>=inum);
    Node* nar=new Node[isize=newsize];
    ForIndex(i,inum) { nar[i]=ar[i]; } EndFor;
    delete[] ar;
    ar=nar;
}

//*** BHPqueue

BHPqueue::BHPqueue(int size) : BPqueue(size) { }

BHPqueue::~BHPqueue() { }

void BHPqueue::clear()
{
    BPqueue::clear();
    m.clear();
}

inline void BHPqueue::nswitch(int n1, int n2)
{
    BPqueue::nswitch(n1,n2);
    MESHassertx(m.replace(ar[n1].e,n1)==n2);
    MESHassertx(m.replace(ar[n2].e,n2)==n1);
}

void BHPqueue::adjust(int n, int up, int down) // copied from BPqueue
{
    const double cp=ar[n].pri;
    int nn=0;                   // dummy initialization
    for (;;nswitch(n,nn),n=nn) {
        if (up) {
            nn=(n-1)/2;
            if (n && cp<ar[nn].pri) continue;
        }
        if (!down) break;
        int ln=n*2+1;           // left child
        if (ln>=inum) break;    // no children
        double lp=ar[ln].pri;
        int rn=n*2+2;           // right child
        if (rn>=inum) {         // no right child
            if (lp<cp) { nn=ln; continue; }
            break;
        }
        double rp=ar[rn].pri;
        if (lp<cp && lp<rp) { nn=ln; continue; }
        if (rp<cp) { nn=rn; continue; }
        break;
    }
}

void BHPqueue::enter(Univ e, double pri) // copied from BPqueue!
{
    enterUnsorted(e,pri);
    adjust(inum-1,1,0);
}

void BHPqueue::sort()           // copied from BPqueue
{
    for (int i = (inum-2)/2; i >= 0; i--) { 
        adjust(i,0,1); 
    }
}

Univ BHPqueue::removemin()      // adapted from BPqueue
{
    MESHassertx(inum);
    Univ e=ar[0].e;
    if (inum>1) nswitch(0,inum-1);
    if (--inum>1) adjust(0,0,1);
    (void)m.remove(e);          // may return index 0
    return e;
}

inline int BHPqueue::find(Univ e) const
{
    int present, i=m.retrieve(e,present);
    return present?i:-1;
}

double BHPqueue::retrieve(Univ e) const
{
    int i=find(e);
    return i>=0?ar[i].pri:-1;
}

int BHPqueue::contains(Univ e) const
{
    // return find(e)>=0;
    return m.contains(e);
}

double BHPqueue::remove(Univ e)
{
    int i=find(e);
    if (i<0) return -1;
    double ppri=ar[i].pri;
    if (inum-1!=i) nswitch(inum-1,i);
    if (i<--inum) adjust(i,1,1);
    (void)m.remove(e);          // may return index 0
    if (inum<isize*.4 && isize>100) resize(isize/2);
    return ppri;
}

double BHPqueue::update(Univ e, double pri)
{
    MESHassertx(pri>=0);
    int i=find(e);
    if (i<0) return -1;
    double oldpri=ar[i].pri;
    ar[i].pri=pri;
    adjust(i,1,1);
    return oldpri;
}

double BHPqueue::enterupdate(Univ e, double pri)
{
    if (m.contains(e)) return update(e,pri);
    return enter(e,pri),-1;
}

