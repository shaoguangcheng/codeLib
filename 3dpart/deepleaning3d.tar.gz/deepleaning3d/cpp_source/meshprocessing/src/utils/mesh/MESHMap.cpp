// This may look like C code, but it is really -*- C++ -*-
// Copyright (c) 1992 Hugues H. Hoppe; All rights reserved.

#include <utils/Mesh_Hh.H>

#include <utils/Mesh_Map.H>

#include <utils/Mesh_Set.H>

#include <utils/Mesh_Random.H>


ALLOCATEPOOL(BMap);
ALLOCATEPOOL(BMap::Node);

const BMap BMap::EMPTY;

BMap::BMap() : b(0), isize(0), inum(0), fbuckn(0) { }

void BMap::clear()
{
	for (int i=0;i<isize;i++) {
		for (Node* n=b[i];n;) {
			Node* last=n->n;
			delete n,n=last;
		}
	}
	delete[] b,b=0;
	isize=0; inum=0; fbuckn=0;
}

BMap::~BMap()
{
	if (b) clear();
}

void BMap::specialslowenter(Univ k, Univ v)
{
	enter(k,v);
}

void BMap::resize(int newsize)
{
	BMap hn;
	typedef BMap::Node* pNode;
	hn.b=new pNode[hn.isize=newsize];
	for (int i=0;i<newsize;i++) hn.b[i]=0;
	for (BMapIter mi(*this);mi;mi.next())
		hn.quickenter(mi.key(),mi.value());
	hn.inum=inum;
	clear();
	// want to simulate *this=*hn;
	b=hn.b; isize=hn.isize; inum=hn.inum; fbuckn=0;
	// pretend hn has no data so destructor does nothing
	hn.b=0; hn.isize=0; hn.inum=0;
}

Univ BMap::remove(Univ k)
{
	if (!b) return 0;
	Node* n; Node* last;
	int buckn=hashk(k);
	for (last=0,n=b[buckn];n;last=n,n=n->n)
		if (n->k==k) break;
	if (!n) return 0;
	Univ e=n->v;
	removeaux(buckn,n,last);
	return e;
}

void BMap::removeaux(int buckn, Node* n, Node* last)
{
	MESHassertx(n);
	if (last) {
		last->n=n->n;
	} else {
		b[buckn]=n->n;
	}
	delete n;
	if (--inum<=isize/2 && isize>5) resize((isize-3)/5+1);
	if (!inum) clear();
}

void BMap::OK() const
{
	Set<Univ> set;
	For (BMapIter mi(*this);mi;mi.next()) {
		MESHassertx(set.add(mi.key()));
	} EndFor;
	MESHassertx(set.num()==inum);
	MESHassertx((b?1:0)==(isize?1:0));
	MESHassertx((b?1:0)==(inum?1:0));
     int i = 0;
	for (i=0;i<isize;i++) if (b[i]) break;
	MESHassertx(fbuckn>=0 && fbuckn<=i);
}

//*** BMapIter

// update h.fbuckn if necessary
inline void BMapIter::findrealfbuckn()
{
	register BMap* vthat=(BMap*)&h;	// virtual const
	register int& thatfbuckn=vthat->fbuckn;
	register int ofbuckn=thatfbuckn;
	bn=ofbuckn-1; n=0;
	advance();
	if (bn>ofbuckn) thatfbuckn=bn;
}

void BMapIter::advancewrap()
{
	advance();
	if (n) return;
	MESHassertx(h.inum);
	bn=h.fbuckn-1;
	advance();
	MESHassertx(n);
}

BMapIter::BMapIter(const BMap& hh)
: h(hh)
{
	findrealfbuckn();
}

BMapIter::BMapIter(const BMap& hh, MeshRandom& r)
: h(hh)
{
	findrealfbuckn();
	if (!h.b) return;
	bn=h.fbuckn+r.getint()%(h.isize-h.fbuckn);
	int ne=0;
	for (n=h.b[bn];n;n=n->n) ne++;
	int nskip=r.getint()%(20+ne);
	if (!(n=h.b[bn])) advancewrap();
	for (int i=0;i<nskip;i++) {
		if (!(n=n->n)) advancewrap();
	}
}

