#include <utils/Mesh_GMesh.H>

char g_strDataHome[] = "./";

int
main( int argc, char ** argv )
{
  GMesh mesh;
  return 0;
}
