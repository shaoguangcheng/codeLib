/*
 *  FadBad.cpp
 *  FADBAD
 *
 *  Created by Cindy Grimm on 5/1/08.
 *  Copyright 2008 Wustl. All rights reserved.
 *
 */

#if defined(__APPLE__) || defined(linux)
#include <Boost/pool/pool.hpp>
#include <string.h>
#else
#include <Boost/pool.hpp>
#endif
#include <vector>

#include <cassert>
#define ASSERT(f) assert(f)

#include <FAD/fadMem.h>
#include <FAD/badiff.h>
#include <FAD/fadiff.h>



static std::vector< boost::pool<> * > s_aopPools;

static boost::pool<> *PoolSize( const size_t in_iSize )
{
    if ( s_aopPools.size() <= in_iSize ) {
        const size_t iOldSize = s_aopPools.size();
        for ( size_t i = iOldSize; i < in_iSize + 1; i++ )
            s_aopPools.push_back(NULL);
    }
    
    if ( s_aopPools[in_iSize] == NULL ) {
        s_aopPools[in_iSize] = new boost::pool<>(in_iSize);
    }
    
    return s_aopPools[in_iSize];
}

#undef newArray
#undef deleteArray


// bottom out
template<>
void FTypeName<double>::deleteArray(  )
{
    const int iSizeTotal = sizeof(double) * m_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( m_adDerivs ) {
        opPool->free( static_cast<void *> (m_adDerivs) );
        m_iSize = 0;
        m_adDerivs = NULL;
    }
}

// bottom out
template<>
void FTypeName< F<double> >::deleteArray(  )
{
    const int iSizeTotal = sizeof(F<double>) * m_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( m_adDerivs ) {
        opPool->free( static_cast<void *> (m_adDerivs) );
        m_iSize = 0;
        m_adDerivs = NULL;
    }
}

// bottom out
template<>
void FTypeName<F< F< double > > >::deleteArray(  )
{
    const int iSizeTotal = sizeof(F< F< double > >) * m_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( m_adDerivs ) {
        opPool->free( static_cast<void *> (m_adDerivs) );
        m_iSize = 0;
        m_adDerivs = NULL;
    }
}

// Make sure to delete sub derivatives
template<class T>
void FTypeName<T>::deleteArray(  )
{
    const int iSizeTotal = sizeof(T) * m_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( m_adDerivs ) {
        for ( size_t i = 0; i < m_iSize; i++ )
            m_adDerivs[i].deleteArray( );
        
        opPool->free( static_cast<void *> (m_adDerivs) );
        m_iSize = 0;
        m_adDerivs = NULL;
    }
}

template<>
void FTypeName< double >::newArray( const size_t in_iSize )
{
    const int iSizeTotal = sizeof( double ) * in_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( in_iSize == m_iSize )
        return;
    
    if ( m_adDerivs != NULL )
        deleteArray(  );
    
    if ( in_iSize <= 0 ) {
        m_iSize = 0;
        m_adDerivs = NULL;
    } else {
        m_iSize = in_iSize;
        m_adDerivs = static_cast< double * > ( opPool->malloc() );
        ASSERT ( m_adDerivs != NULL );
        
#ifdef DEBUG
	memset( m_adDerivs, 0, iSizeTotal );
#endif
    }
}

template<>
void FTypeName< F<double> >::newArray( const size_t in_iSize )
{
    const int iSizeTotal = sizeof( F<double> ) * in_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( in_iSize == m_iSize )
        return;
    
    if ( m_adDerivs != NULL )
        deleteArray(  );
    
    if ( in_iSize <= 0 ) {
        m_iSize = 0;
        m_adDerivs = NULL;
    } else {
        m_iSize = in_iSize;
        m_adDerivs = static_cast< F<double> * > ( opPool->malloc() );
        ASSERT ( m_adDerivs != NULL );
        
#ifdef DEBUG
        memset( m_adDerivs, 0, iSizeTotal );
#endif
    }
}

template<>
void FTypeName< F< F<double> > >::newArray( const size_t in_iSize )
{
    const int iSizeTotal = sizeof( F< F<double> > ) * in_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( in_iSize == m_iSize )
        return;
    
    if ( m_adDerivs != NULL )
        deleteArray(  );
    
    if ( in_iSize <= 0 ) {
        m_iSize = 0;
        m_adDerivs = NULL;
    } else {
        m_iSize = in_iSize;
        m_adDerivs = static_cast< F< F<double> > * > ( opPool->malloc() );
        ASSERT ( m_adDerivs != NULL );
        
#ifdef DEBUG
        memset( m_adDerivs, 0, iSizeTotal );
#endif
    }
}

template<class T>
void FTypeName<T>::newArray( const size_t in_iSize )
{
    const int iSizeTotal = sizeof(T) * in_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( in_iSize == m_iSize )
        return;
    
    if ( m_adDerivs != NULL )
        deleteArray(  );
    
    if ( in_iSize <= 0 ) {
        m_iSize = 0;
        m_adDerivs = NULL;
    } else {
        m_iSize = in_iSize;
        m_adDerivs = static_cast< T * > ( opPool->malloc() );
        ASSERT ( m_adDerivs != NULL );
        
#ifdef DEBUG
        memset( m_adDerivs, 0, iSizeTotal );
#endif
    }
}


template<class T>
void* FTypeName<T>::operator new (size_t size)
{
    boost::pool<> *opPool = PoolSize( sizeof( FTypeName<T> ) );
    
    return opPool->malloc();
}

template<>
void FTypeName< double >::operator delete (void *p)
{
    boost::pool<> *opPool = PoolSize( sizeof( FTypeName< double > ) );
    
    opPool->free( static_cast<void *>( p ) );
}

template<>
void FTypeName< F<double> >::operator delete (void *p)
{
    boost::pool<> *opPool = PoolSize( sizeof( FTypeName< F<double> > ) );
    
    opPool->free( static_cast<void *>( p ) );
}

template<>
void FTypeName< F< F<double> > >::operator delete (void *p)
{
    boost::pool<> *opPool = PoolSize( sizeof( FTypeName< F< F< double> > > ) );
    
    opPool->free( static_cast<void *>( p ) );
}

template<class T>
void FTypeName<T>::operator delete (void *p)
{
    boost::pool<> *opPool = PoolSize( sizeof( FTypeName<T> ) );
    
    opPool->free( static_cast<void *>( p ) );
}

/*************************/
template<class T>
void BackwardNode<T>::newArray( const size_t in_iSize )
{
    const int iSizeTotal = sizeof(T) * in_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( in_iSize == m_iSize )
        return;
    
    deleteArray( );
    
    if ( in_iSize <= 0 ) {
        m_iSize = 0;
        m_adDerivs = NULL;
    } else {
        m_iSize = in_iSize;
        m_adDerivs = static_cast< T * > ( opPool->malloc() );
        ASSERT ( m_adDerivs != NULL );
        
#ifdef DEBUG
        memset( m_adDerivs, 0, iSizeTotal );
#endif
    }
}

// Make sure to delete sub derivatives
template<class T>
void BackwardNode<T>::deleteArray()
{
    const int iSizeTotal = sizeof(T) * m_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( m_adDerivs ) {
        for ( size_t i = 0; i < m_iSize; i++ )
            m_adDerivs[i].deleteArray();
        
        opPool->free( static_cast<void *> (m_adDerivs) );
        m_iSize = 0;
        m_adDerivs = NULL;
    }
}

// bottom out
template<>
void BackwardNode<double>::deleteArray()
{
    const int iSizeTotal = sizeof(double) * m_iSize;
    boost::pool<> *opPool = PoolSize( iSizeTotal );
    
    if ( m_adDerivs ) {
        opPool->free( static_cast<void *> (m_adDerivs) );
        m_iSize = 0;
        m_adDerivs = NULL;
    }
}

void FAD_FORCE_COMPILE()
{
    FTypeName<double> d;
    FTypeName< FTypeName<double> > dd;
    FTypeName< FTypeName< FTypeName<double> > > ddd;

    BackwardNode<double> bd;
    BackwardNode< BackwardNode<double> > bdd;
    BackwardNode< BackwardNode< BackwardNode<double> > > bddd;
    
    d.newArray(1);
    dd.newArray(1);
    ddd.newArray(1);
    
    bd.newArray(1);
    bdd.newArray(1);
    bddd.newArray(1);
}
