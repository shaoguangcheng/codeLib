#include "StdAfx.H"
#include <utils/Utils_IcosahedralSampler.H>

UTILSIcosahedralSampler::UTILSIcosahedralSampler()
: m_avecVertices(12), m_aiTriangles(20), m_aiEdges(30)
{
	// install the vertices of the icosahedron
	m_avecVertices[0] = RectangularCoordsOf(0, 0); // north pole

	double phi0 = acos(1 / sqrt(5.0));

	for (int k = 0; k < 5; k++) { // ring of nodes near north pole
         m_avecVertices[k+1] = RectangularCoordsOf(2 * M_PI * k / 5, phi0);
	}

	for (FORINT k = 0; k < 5; k++) { // ring of nodes near south pole
         m_avecVertices[k+6] = RectangularCoordsOf(M_PI / 5.0 + 2 * M_PI * k / 5, M_PI - phi0);
	}
     
	m_avecVertices[11] = RectangularCoordsOf(0, M_PI); // south pole

	//------------------------------------------------------------------------
	//	create the array of (oriented!) triangles. 	
	//------------------------------------------------------------------------

	int ltriangles[20][3] = {
 		{0, 1, 2}, 
		{0, 2, 3}, 
		{0, 3, 4}, 
		{0, 4, 5}, 
		{1, 0, 5}, 
		{2, 1, 6}, 
		{2, 6, 7},
		{3, 2, 7}, 
		{3, 7, 8}, 
		{4, 3, 8}, 
		{4, 8, 9},  
		{5, 4, 9}, 
		{5, 9, 10},  
		{1, 5, 10},  
		{1, 10, 6}, 
		{7, 6, 11},   
		{8, 7, 11},  
		{9, 8, 11},  
		{10, 9, 11}, 
		{6, 10, 11}}; 

	for (int i = 0 ; i < 20; i++) {
		for (int j = 0; j < 3; j++) {
			m_aiTriangles[i][j] = ltriangles[i][j];
		}
	}

	int iEdgeCounter = 0;
     SArray<R2Pt_i> aiEdgetemp(3);

     for (FORINT i = 0; i < 20; i++) {
         TriangleEdges(m_aiTriangles[i], aiEdgetemp);

         for (int k = 0; k < 3; k++) {
             if (aiEdgetemp[k][0] < aiEdgetemp[k][1]) { 
                 m_aiEdges[iEdgeCounter][0] = aiEdgetemp[k][0];	
                 m_aiEdges[iEdgeCounter++][1] = aiEdgetemp[k][1];	
             }
         }
	}

	ASSERT(iEdgeCounter == 30);
}


/*
**  Get samples at resolution n, which means 12 + 30 * n + 20 * ((n) * (n-1)) / 2; 
*/

void UTILSIcosahedralSampler::GetSamples(int n, Array<R3Vec> &out_avec )
{
    const int nSamples =  12 + 30 * n + 20 * ((n) * (n-1)) / 2;
    
    out_avec.need( nSamples );
	out_avec.need(0);
    for (int i = 0; i < m_avecVertices.num(); i++)
        out_avec += m_avecVertices[i];
    
    ASSERT(out_avec.num() == 12);
    
    
    GetEdgeSamples(n, out_avec); 
    GetFaceSamples(n, out_avec);

    ASSERT(out_avec.num() == nSamples);

    /// Just in case
    for ( FORINT i = 0; i < m_avecVertices.num(); i++ )
        m_avecVertices[i] = UnitSafe( m_avecVertices[i] );
}


R3Vec
UTILSIcosahedralSampler::RectangularCoordsOf(double theta, double phi)
{
    R3Vec out_vec;
    
    out_vec[0] = sin(phi) * cos(theta);
    out_vec[1] = sin(phi) * sin(theta);
    out_vec[2] = cos(phi);

    return out_vec;
}



void
UTILSIcosahedralSampler::TriangleEdges(const R3Pt_i &in_aiTri, SArray<R2Pt_i> &out_aiEdges)
{
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 2; j++) {
            out_aiEdges[i][j] = in_aiTri[ (i + j) % 3];
        }
    }
}

// for each edge, find the samples along that edge and shove 'em into res
void
UTILSIcosahedralSampler::GetEdgeSamples(int in_iN, Array<R3Vec> &out_avec)
{
    double dDiv = ( in_iN + 1.0 );

    for (int iE = 0; iE < 30; iE++) {
        int i = m_aiEdges[iE][0];	
        int j = m_aiEdges[iE][1];
        const R3Vec &vecVi = m_avecVertices[i];
        const R3Vec &vecVj = m_avecVertices[j];
        
        for (int k = 1; k<=in_iN; k++) {
            
            out_avec += vecVi * ( (double) k / dDiv ) +
                        vecVj * ( (double) (in_iN+1 - k) / dDiv );
        }
    }
}
			
void
UTILSIcosahedralSampler::GetFaceSamples(int in_iN, Array<R3Vec> &out_avec)
{
    double dDiv = ( in_iN + 1.0 );
    for (int iF = 0; iF < 20; iF++) {
        int i = m_aiTriangles[iF][0];	
        int j = m_aiTriangles[iF][1];
        int k = m_aiTriangles[iF][2];	
        
        const R3Vec &vecVi = m_avecVertices[i];
        const R3Vec &vecVj = m_avecVertices[j];
        const R3Vec &vecVk = m_avecVertices[k];
        
        for (int sj = 1; sj < in_iN; sj++) {
            for (int si = 1; si<= in_iN - sj; si++) {
                
                out_avec += vecVi * ( (double) si / dDiv )+ 
                            vecVj * ( (double) sj / dDiv ) +
                            vecVk * ( (double) (in_iN+1 - si - sj) / dDiv );
            }
        }
    }
}
	

