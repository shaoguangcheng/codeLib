#include "StdAfx.H"

#include <utils/Pm_MeshLite.H>
#include <boost/dynamic_bitset/dynamic_bitset.hpp>
#include <utils/Utils_Dots.H>
#include <utils/BaryPoly.h>

static WINbool s_bTrace = FALSE;

void PMeshLite::GrowShortestPathTree( const Vertex                  & in_v1,
                                      const boost::dynamic_bitset<> & in_abNoCross,
                                      const Array<double>           & in_adEdgeWeights,
                                      Array<Vertex>           & out_avFrom,
                                      Array<double>           & out_adDist,
                                      boost::dynamic_bitset<> & out_abTreeEdges, 
                                      const double              in_dStopGrow) const
{
	// So we don't have to keep asking
    const int nV = NumVertices();
    const int nE = NumEdges();

    // do initializations
	// Keep: current shortest path distance; initialize with stop grow plus a bit
	// Keep: Vertex we came from in the path list; initialize with null
	// Keep: Which edges we ended up using; initialize with false
    out_adDist.need( nV );
    out_adDist.fill( in_dStopGrow + 1.0 );
    out_avFrom.need( nV );
    out_avFrom.memfill( NULL );
    out_abTreeEdges.resize(nE);
    out_abTreeEdges.reset();

    // initialize the source node info
    out_adDist[ in_v1->IndexId() ] = 0.0;
    out_avFrom[ in_v1->IndexId() ] = in_v1;

    // initialize the priority queue
	// Enter each vertex in with it's current distance (will be stop grow plus one, except for source vertex)
    BHPqueue pq( nV );
    pq.enterUnsorted((Univ) in_v1, 0.0);

	// Will put source vertex at top of queue
    pq.sort();

	// do dijkstra's
    while(!pq.empty()) {
		// Get the next vertex on the stack
        const Vertex u = (Vertex)pq.removemin();
		// This is the id of the vertex pulled from the stack
        const int uid = u->IndexId();

        if ( out_adDist[uid] > in_dStopGrow )
            break;

		// Don't go through any of the vertices that were in the no cross list
		// Don't continue pass this vertex if it's too far away

        // Neighboring vertices and edges (star of vertex)
        ForVertexEdge( Mesh(), u, e ) {
            const Vertex v = EdgeOppositeVertex(e, u);
            const int vid = v->IndexId();
            const int eid = e->IndexId(); // Edge goes from vid to uid

            if ( !in_abNoCross[uid] ) {
				// If our current distance to vid is bigger than the distance to uid plus what it costs
				// to traverse that edge, update distance in queue and say uid is the parent
                if ( out_avFrom[vid] == NULL ) {
					// Update distance both in output array and in queue
                    out_adDist[vid] = out_adDist[uid] + in_adEdgeWeights[eid];
                    pq.enter((Univ) v, out_adDist[vid]);
                    
					// Mark this path edge and new parrent of v
                    out_abTreeEdges.set(eid);
                    out_avFrom[vid] = u;	
                } else if (out_adDist[vid] > out_adDist[uid] + in_adEdgeWeights[eid] ) {
                    // Unmark the previous path edge
                    out_abTreeEdges.reset( e->IndexId() );
                    pq.update((Univ)v, out_adDist[vid]);
                    
					// Mark this path edge and new parrent of v
                    out_abTreeEdges.set(eid);
                    out_avFrom[vid] = u;	
                }
            }
        }EndFor;
    }
}

int PMeshLite::ExponentialMap( const Vertex                    & in_v, 
                               const boost::dynamic_bitset<>   & in_abNoCross, 
                               Array< std::pair<Vertex,R2Pt> > & out_avPtDisk, 
                               const double in_dStopGrow ) const
{
    const int nV = NumVertices();
    static Array<Vertex> avFrom( nV );
    static Array<double> adDist( nV );
    static Array<R2Vec> avecProj( nV );
    static Array<double> adLocalAng( nV );
    static boost::dynamic_bitset<> abVisited( nV ), abTouched( nV );

    static Array<R3Vec> avecDs( nV ), avecDt( nV );
    
    if ( avFrom.num() != nV ) {
        avFrom.need( nV );
        adDist.need( nV );
        avecProj.need( nV );
        adLocalAng.need( nV );
        avecDs.need( nV );
        avecDt.need( nV );
        abVisited.resize( nV );
        abTouched.resize( nV );
    }

    // do initializations
    abVisited.reset();
    abTouched.reset();

    // initialize the source node info
    adDist[ in_v->IndexId() ] = 0.0;
    avFrom[ in_v->IndexId() ] = in_v;
    avecProj[ in_v->IndexId() ] = R2Vec(0,0);
    adLocalAng[ in_v->IndexId() ] = 0.0;
    abVisited.set( in_v->IndexId() );
    abTouched.set( in_v->IndexId() );
    avecDs[ in_v->IndexId() ] = UnitSafe( Rejection( in_v->GetNorm(), VertexVertices(in_v)[0]->GetLoc() - in_v->GetLoc() ) );
    avecDt[ in_v->IndexId() ] = UnitSafe( Cross( in_v->GetNorm(), avecDs[in_v->IndexId()] ) );

    // initialize the priority queue
    BHPqueue pq;
    pq.enter((Univ) in_v, adDist[in_v->IndexId()]);

    // do dijkstra's
    R3Matrix matRot;
    R3Vec vecSDir, vecTDir, vecToNeigh;
    R2Matrix matRotPlane;
    static Array<Vertex> avNeigh;
    static Array<R2Vec> avecNeigh;

    out_avPtDisk.need(0);

    while(!pq.empty()) {
        Vertex u = (Vertex)pq.removemin();
        int uid = u->IndexId();
        abVisited.set(uid);

        out_avPtDisk += std::pair<Vertex, R2Pt>( u, R2Pt(0,0) + avecProj[uid] );
        const double dRadius = ::Length( avecProj[uid] );

        if ( !in_abNoCross[uid] && dRadius < in_dStopGrow ) {
            // First, project the 1 ring onto u's tangent plane
            // Keep track of which index is the pointer back to the previous point

            avNeigh = VertexVerticesOrdered(u);
            vecToNeigh = avNeigh[0]->GetLoc() - u->GetLoc();
            if ( RNIsZero( LengthSq( vecToNeigh ) ) )
                continue;

            // Two tangent plane vectors in u's tangent plane
            vecSDir = UnitSafe( Rejection( u->GetNorm(), vecToNeigh ) );
            vecTDir = UnitSafe( Cross( u->GetNorm(), vecSDir ) );

            ASSERT( RNIsZero( Dot( vecSDir, vecTDir ) ) );
            ASSERT( RNIsZero( Dot( vecSDir, u->GetNorm() ) ) );
            ASSERT( RNIsZero( Dot( u->GetNorm(), vecTDir ) ) );

            // Rotate to align tangent planes with previous one
            const R3Vec vecToNeighPrev = UnitSafe( avFrom[uid]->GetLoc() - u->GetLoc() );
            const R3Vec vecInTangentPlanePrev = Rejection( u->GetNorm(), vecToNeighPrev );
            const R2Vec vecProjPrev = R2Vec( Dot( vecSDir, vecInTangentPlanePrev ), Dot( vecTDir, vecInTangentPlanePrev ) );
            const double dAngProjPrev = atan2( vecProjPrev[1], vecProjPrev[0] );
            // Undo local rotation, add in prev rotation
            matRotPlane = R2Matrix::Rotation( dAngProjPrev - adLocalAng[uid] );

            if ( s_bTrace ) avecNeigh.need(avNeigh.num());
            for ( int iV = 0; iV < avNeigh.num();iV++ ) {
                Vertex vv = avNeigh[iV];
                R3Vec vecToNeigh = vv->GetLoc() - u->GetLoc();
                const double dLen = vecToNeigh.Normalize();
                const R3Vec vecInTangentPlane = Rejection( u->GetNorm(), vecToNeigh );
                ASSERT( RNIsZero( Dot( vecInTangentPlane, u->GetNorm() ) ) );
                const R2Vec vecToNeigh2D = matRotPlane * R2Vec( Dot( vecSDir, vecInTangentPlane ), Dot( vecTDir, vecInTangentPlane ) );
                const R2Vec vecProj = UnitSafe( vecToNeigh2D ) * dLen;
                // Add previous point to this one
                const R2Vec vecProjFinal = avecProj[ uid ] + vecProj;
                const double dDistNew = adDist[uid] + dLen;

                if ( s_bTrace ) avecNeigh[iV] = vecProj;
                if ( abVisited[vv->IndexId()] )
                    continue;

                if ( abTouched[vv->IndexId()] ) {
                    if ( dDistNew < adDist[ vv->IndexId() ] ) {
                        adDist[ vv->IndexId() ] = dDistNew;
                        avecProj[ vv->IndexId() ] = vecProjFinal;
                        adLocalAng[ vv->IndexId() ] = atan2( -vecToNeigh2D[1], -vecToNeigh2D[0] );
                        pq.update((Univ)vv, dDistNew);

                        avFrom[ vv->IndexId() ] = u;
                    }
                } else {
                    adDist[ vv->IndexId() ] = dDistNew;
                    avecProj[ vv->IndexId() ] = vecProjFinal;
                    adLocalAng[ vv->IndexId() ] = atan2( -vecToNeigh2D[1], -vecToNeigh2D[0] );
                    pq.enter((Univ) vv, dDistNew);
                    
                    avFrom[ vv->IndexId() ] = u;
                    abTouched.set( vv->IndexId() );
                }
            } 

            if ( s_bTrace ) {
                UTILSDotArray dots;
                dots.Add( R2Pt(0,0) + avecProj[uid], UTILSColor::RED );
                for ( int i = 0; i < avecNeigh.num(); i++ ) {
                    if ( abVisited[ avNeigh[i]->IndexId() ] || avFrom[ avNeigh[i]->IndexId() ] ) 
                        dots.AddPair( R2Pt(0,0) + avecProj[uid] + avecNeigh[i], R2Pt(0,0) + avecProj[avNeigh[i]->IndexId()], abVisited[ avNeigh[i]->IndexId() ] ? UTILSColor::YELLOW : UTILSColor::GREEN);
                    else
                        dots.Add( R2Pt(0,0) + avecProj[uid] + avecNeigh[i], UTILSColor::BLUE );

                    if ( avFrom[ avNeigh[i]->IndexId() ] ) {
                        const R2Pt pt1 = R2Pt(0,0) + avecProj[uid] + avecNeigh[i];
                        const R2Pt pt2 = R2Pt(0,0) + avecProj[avNeigh[i]->IndexId()];
                        const double dDiff = Length( pt1 - pt2 );
                        const double dLenCheck = Length( avecNeigh[i] );
                        if ( dDiff > 0.2 * dLenCheck ) 
                            TRACE("Bad?\n");
                    }

                    R3Vec vecNorm = Cross( R3Vec( avecNeigh[i][0], avecNeigh[i][1], 0.0 ), R3Vec( avecNeigh.wrap(i+1)[0], avecNeigh.wrap(i+1)[1], 0.0 ) );
                    vecNorm.Normalize();
                    ASSERT( RNApproxEqual( fabs(vecNorm[2]), 1.0) );
                }
                dots.Write( WINDataHome("test/expmap.txt") );
            }
            /*
            avecDs[ u->IndexId() ] = UnitSafe( Rejection( u->GetNorm(), VertexVertices(u)[0]->GetLoc() - u->GetLoc() ) );
            avecDt[ u->IndexId() ] = UnitSafe( Cross( u->GetNorm(), avecDs[u->IndexId()] ) );

            R3Matrix::MatrixVecToVec( matRotTangentPlane, u->GetNorm(), avecDs[uid], avFrom[uid]->GetNorm(), avecDs[ avFrom[uid]->IndexId() ] );

            vecSDir = matRotTangentPlane * avecDs[u->IndexId()];
            vecTDir = matRotTangentPlane * avecDt[u->IndexId()];

            ASSERT( ApproxEqual( vecSDir, avecDs[ avFrom[uid]->IndexId()], 1e-6 ) );
            ASSERT( ApproxEqual( vecTDir, avecDt[ avFrom[uid]->IndexId()], 1e-6 ) );

            ForVertexVertex( Mesh(), u, vv ) {
                const R3Vec vecToNeigh = vv->GetLoc() - u->GetLoc();
                const R3Vec vecInTangentPlane = UnitSafe( Rejection( u->GetNorm(), vecToNeigh ) ) * Length( vecToNeigh );
                const R3Vec vecAlignPrev = matRotTangentPlane * vecInTangentPlane;

                ASSERT( RNIsZero( Dot( vecInTangentPlane, u->GetNorm() ) ) );
                const R2Vec vecProj = R2Vec( Dot( vecSDir, vecAlignPrev ), Dot( vecTDir, vecAlignPrev ) );
                // Add previous point to this one
                const R2Vec vecProjFinal = avecProj[ uid ] + vecProj;
                const double dDistNew = Length( vecProjFinal );
                if ( dDistNew < adDist[ vv->IndexId() ] ) {
                    adDist[ vv->IndexId() ] = dDistNew;
                    avecProj[ vv->IndexId() ] = vecProjFinal;
                    adLocalAng[ vv->IndexId() ] = atan2( -vecProj[1], -vecProj[0] );
                    pq.update((Univ)vv, dDistNew);

                    avFrom[ vv->IndexId() ] = u;
                } else {
                    TRACE("%f %f %f %f\n", avecProj[ vv->IndexId() ][0], avecProj[ vv->IndexId() ][1], vecProjFinal[0], vecProjFinal[1] );
                }
            } EndFor;
            */
        }
    }
    if ( s_bTrace ) {
        PMeshLite meshProj;
        MakeFlattenedMesh( out_avPtDisk, meshProj );
        meshProj.Write( ( g_strDataHome + std::string( "test/expMapII.bm") ).c_str() );
    }
    
    return out_avPtDisk.num();
}

inline double ComputeHerons( const double in_d1, const double in_d2, const double in_d3 )
{
    double dA = 0, dB = 0, dC = 0;
    if ( in_d1 > in_d2 && in_d1 > in_d3 ) {
        dA = in_d1;
        if ( in_d2 > in_d3 ) {
            dB = in_d2;
            dC = in_d3;
        } else {
            dB = in_d3;
            dC = in_d2;
        }
    } else if ( in_d2 > in_d3 ) {
        dA = in_d2;
        if ( in_d1 > in_d3 ) {
            dB = in_d1;
            dC = in_d3;
        } else {
            dB = in_d3;
            dC = in_d1;
        }
    } else {
        dA = in_d3;
        if ( in_d1 > in_d2 ) {
            dB = in_d1;
            dC = in_d2;
        } else {
            dB = in_d2;
            dC = in_d1;
        }
    }
    ASSERT( dA >= dB && dA >= dC && dB >= dC );
    
    const double dTerm = (dA + (dB + dC)) * (dC - (dA - dB)) * (dC + (dA - dB)) * (dA + (dB - dC));
    ASSERT( dTerm > -1e-16 );
    return sqrt( fabs( dTerm ) );
}

inline double ComputeDistance( const double in_dUk, const double in_dUj, const R3Pt &in_ptk, const R3Pt &in_ptj, const R3Pt &in_pti, int &out_iConvex )
{
    const double dDiffLen = fabs( in_dUk - in_dUj );
    const double dDiffLen3D = ::Length( in_ptj - in_ptk );
    const double dSumLen = in_dUk + in_dUj;
    const R3Vec vecEji = in_ptj - in_pti;
    const R3Vec vecEki = in_ptk - in_pti;
    const R3Vec vecEkj = in_ptk - in_ptj;
    const double dLenjk = ::Length( vecEkj );
    const double dLenji = ::Length( vecEji );
    const double dLenki = ::Length( vecEki );
    
    const double dH = ComputeHerons( dLenji, dLenki, dLenjk );
    const double dA = ::Length( Cross( in_ptk - in_pti, in_ptj - in_pti ) ) / 2.0;
    const double dDenom = 4.0 * dA * dLenjk * dLenjk;

    
    const double dXj = RNIsZero( dDenom ) ? -1.0 : ( 2.0 * dA * ( dLenjk * dLenjk + in_dUk * in_dUk - in_dUj * in_dUj) + Dot( vecEki, vecEkj ) * dH ) / dDenom;
    const double dXk = RNIsZero( dDenom ) ? -1.0 : ( 2.0 * dA * ( dLenjk * dLenjk - in_dUk * in_dUk + in_dUj * in_dUj) - Dot( vecEji, vecEkj ) * dH ) / dDenom;
    if ( dDiffLen3D < dDiffLen || dDiffLen3D > dSumLen || RNIsZero( dDenom ) || dXj < 0.0 || dXk < 0.0 || (dXj + dXk) < 1.0 ) {
        if ( RNIsZero( dDenom ) ) {
            cerr << "Bad denom, ComputeDistance\n";
        }
        // concave case
        const double dFromj = in_dUj + ::Length( in_ptj - in_pti );
        const double dFromk = in_dUk + ::Length( in_ptk - in_pti );
        if ( dFromj < dFromk ) {
            out_iConvex = 0;
            return dFromj;
        } else {
            out_iConvex = 1;
            return dFromk;
        }
    }
    
    
    // convex case
    const R3Vec vecSum = vecEji * dXj + vecEki * dXk;
    
    const double dNewDist = ::Length( vecSum );
    
    out_iConvex = -1;
    return dNewDist;
    
}


inline double ComputeAngle( const double in_dAk, const double in_dAj, 
                            const R3Pt &in_ptk, const R3Pt &in_ptj, const R3Pt &in_pti, int &out_iConvex )
{
    if ( out_iConvex == 0 ) {
        return in_dAk;
    }
    if ( out_iConvex == 1 ) {
        return in_dAj;
    }
    
    double dAngK = in_dAk;
    double dAngJ = in_dAj;
    const double dCase1 = fabs( in_dAk - in_dAj );
    const double dCase2 = fabs( in_dAk + 2.0 * M_PI - in_dAj );
    const double dCase3 = fabs( in_dAk - in_dAj - 2.0 * M_PI );
}    
    
    
inline void ProjectPlane( const R3Pt &in_pt, const Array<R3Pt> &in_apt, Array<R2Pt> &out_aptOut )
{
}

int PMeshLite::ExponentialMapII( const Vertex                    & in_v, 
                                const boost::dynamic_bitset<>   & in_abNoCross, 
                                Array< std::pair<Vertex,R2Pt> > & out_avPtDisk, 
                                const double in_dEpsDone, 
                                const double in_dStopGrow ) const
{
    const int nV = NumVertices();
    static Array<Vertex> avFrom( nV );
    static Array<double> adDist( nV );
    static Array<double> adAngle( nV );
    static boost::dynamic_bitset<> abVisited( nV ), abStillInQueue( nV );
    
    if ( avFrom.num() != nV ) {
        avFrom.need( nV );
        adDist.need( nV );
        adAngle.need( nV );
        abVisited.resize( nV );
    }
    
    static Array<R3Pt> aptLoc;
    static Array<R2Pt> aptProj2D;
    static Array<Vertex> avNeigh;
    
    avNeigh = VertexVertices( in_v );
    aptLoc.need( avNeigh.num() );
    aptProj2D.need( avNeigh.num() );
    
    for ( int i = 0; i < avNeigh.num(); i++ ) {
        aptLoc[i] = avNeigh[i]->GetLoc();
    }
    ProjectPlane( in_v->GetLoc(), aptLoc, aptProj2D );
    
    // do initializations
    abVisited.reset();
    abStillInQueue.reset();
    
    // initialize the source node info
    adDist[ in_v->IndexId() ] = 0.0;
    avFrom[ in_v->IndexId() ] = in_v;
    adAngle[ in_v->IndexId() ] = 0.0;
    abVisited.set( in_v->IndexId() );
    
    // initialize the priority queue
    BHPqueue pq;
    pq.enter((Univ) in_v, adDist[in_v->IndexId()]);

    for ( int i = 0; i < avNeigh.num(); i++ ) {
        adDist[ avNeigh[i]->IndexId() ] = ::Length( aptProj2D[i] - R2Pt(0,0) );
        adAngle[ avNeigh[i]->IndexId() ] = atan2( aptProj2D[i][1], aptProj2D[i][0] );
        abVisited.set( avNeigh[i]->IndexId() );
        abStillInQueue.set( avNeigh[i]->IndexId() );
        avFrom[avNeigh[i]->IndexId()] = in_v;
        
        pq.enter((Univ) avNeigh[i], adDist[avNeigh[i]->IndexId()]);
    }
    
    // do dijkstra's    
    out_avPtDisk.need(0);
    
    int iWasConvex = -1;
    while(!pq.empty()) {
        Vertex vCur = (Vertex)pq.removemin();
        const int iIdCur = vCur->IndexId();
        abVisited.set(iIdCur);
        
        const double dRadius = adDist[ iIdCur ];
        
        if ( !in_abNoCross[iIdCur] && dRadius < in_dStopGrow ) {
            // Do all the adjacent vertices in the 1 ring, starting with a triangle where we have both end points
            avNeigh = VertexVerticesOrdered(vCur);
            const int iStart = avNeigh.index( avFrom[ iIdCur ] );
            for ( int i = iStart; i < iStart + avNeigh.num(); i++ ) {
                const int iV2 = avNeigh.wrap(i)->IndexId();
                const int iVFind = avNeigh.wrap(i+1)->IndexId();
                
                const double dDistNew = ComputeDistance( adDist[ iIdCur], adDist[ iV2 ], vCur->GetLoc(), avNeigh.wrap(i)->GetLoc(), avNeigh.wrap(i+1)->GetLoc(), iWasConvex );
                if ( !abVisited[ iVFind ] || ( !RNIsZero(dDistNew) && adDist[ iVFind ] / dDistNew < 1.0 + in_dEpsDone ) ) {
                    abVisited.set(iVFind);
                    abStillInQueue.set(iVFind);
                    adDist[iVFind] = dDistNew;
                    if ( abVisited[ iVFind ] ) {
                        pq.update((Univ)avNeigh.wrap(i+1), dDistNew);
                    } else {
                        pq.enter((Univ)avNeigh.wrap(i+1), dDistNew);
                    }
                    adAngle[iVFind] = ComputeAngle( adAngle[ iIdCur ], adAngle[ iV2 ], vCur->GetLoc(), avNeigh.wrap(i)->GetLoc(), avNeigh.wrap(i+1)->GetLoc(), iWasConvex );
                }
                
            }
        }
    }

    out_avPtDisk.need( abVisited.count() );
    int iIndex = 0;
    for ( int i = abVisited.find_first(); i != -1; i = abVisited.find_next(i), iIndex++ ) {
        const double dRad = adDist[i];
        const double dAng = adAngle[i];
        const R2Pt pt( cos( dAng ) * dRad, sin( dAng ) * dRad );
        out_avPtDisk[iIndex] = std::pair<Vertex, R2Pt>( VertexFromIndexId(i), pt );
    }

    if ( s_bTrace ) {
        PMeshLite meshProj;
        MakeFlattenedMesh( out_avPtDisk, meshProj );
        meshProj.Write( ( g_strDataHome + std::string( "test/expMapII.bm") ).c_str() );
    }
    
    return out_avPtDisk.num();
}

// same as GrowShortestPathTree, only it goes on the faces instead of the vertices.
// this code gives the minimum spanning tree, but when I call it I tweak the 
// input weights so that it functions as a maximum spanning tree
void PMeshLite::DualMST( const Face                    & in_f1,
                         const boost::dynamic_bitset<> & in_abNoCross,
                         const Array<double>           & in_adEdgeWeights,
                         const double                    in_dStopGrow,
                               Array<double>           & out_adDists,
                               boost::dynamic_bitset<> & out_abTreeEdges) const
{
    const double dMax = 1e30;
    const int nF = NumFaces();
    const int nE = NumEdges();
    Array<Face> afMesh( nF );
    Array<Face> afFrom( nF );        // the predecessors of each face

    // do initializations
    out_adDists.fill( dMax );
    afFrom.memfill( NULL );
    out_abTreeEdges.resize( nE );
    out_abTreeEdges.reset();
    out_adDists.need(nF);
    AllMeshFaces(afMesh);
    
    // initialize the source node info
    out_adDists[ in_f1->IndexId() ] = 0.0;
    afFrom[ in_f1->IndexId() ] = in_f1;

    // initialize the priority queue
    BHPqueue pq( nF );
    for (int i = 0; i < nF; i++) {
        pq.enterUnsorted((Univ) afMesh[i], out_adDists[i]);
    }
    pq.sort();

    // do dijkstra's
    while(!pq.empty()) {
        Face f = (Face)pq.removemin();
        int fid = f->IndexId();

        Array<Edge> aeAdj = FaceEdges(f);
        for (int iE = 0; iE < aeAdj.num(); iE++) {
            Edge edgeToCross = aeAdj[iE];
            if ( !in_abNoCross[edgeToCross->IndexId()] ) {
                Face g = EdgeOtherFace(edgeToCross, f);
                int gid = g->IndexId();

                if (out_adDists[gid]   >   out_adDists[fid] + in_adEdgeWeights[ edgeToCross->IndexId() ]) {
                    out_adDists[gid] = out_adDists[fid] + in_adEdgeWeights[ edgeToCross->IndexId() ];

                    pq.update((Univ)g, out_adDists[gid]);
                    if (afFrom[gid] != NULL) {
                        Edge oldCrossedEdge = EdgeFromFaces(afFrom[gid], g);
                        out_abTreeEdges.reset(oldCrossedEdge->IndexId());
                    }
                    out_abTreeEdges.set(edgeToCross->IndexId());
                    afFrom[gid] = f;
                } 
            }
        }
        if ( out_adDists[fid] > in_dStopGrow )
            return;
    }
}


Array<Vertex> PMeshLite::FindPath( const Vertex                   & in_v1, 
                                   const Array<Vertex>            & in_aopBdryVs, 
                                   const boost::dynamic_bitset<>  & in_abNoCross, 
                                   const Array< double >          & in_adEdgeWeights  ) const
{
    const int nV = NumVertices();
    const int nE = NumEdges();
    Array<Vertex> avFrom( nV );   // the predecessors of each vertex
    Array<double> adDist( nV );   // the distance from the source to each vertex
    boost::dynamic_bitset<> abTreeEdges( nE );  // true if edge is in the tree

    GrowShortestPathTree(in_v1, in_abNoCross, in_adEdgeWeights, avFrom, adDist, abTreeEdges);

    // find the dest vertex with the smallest distance
    int iMin = 0;
    for ( int i = 0; i < in_aopBdryVs.num(); i++ ) {
        if ( adDist[ in_aopBdryVs[i]->IndexId() ] < adDist[ in_aopBdryVs[iMin]->IndexId() ] )
            iMin = i;
    }

    // build up the array of vertices to return, starting with the dest vertex found above
    Array<Vertex> avRet;
    avRet.need(0);
    avRet += in_aopBdryVs[iMin];
    while ( avFrom.Ok(avRet.last()->IndexId()) && avFrom[ avRet.last()->IndexId() ] != in_v1 ) {
        avRet += avFrom[ avRet.last()->IndexId() ];
    }
    avRet += in_v1;
    avRet.reverse();

    return avRet;
}


Array<Vertex> PMeshLite::FindPath( const Vertex &in_v1, 
                                   const Vertex &in_v2, 
                                   const boost::dynamic_bitset<> &in_abEdgeNoCross, 
                                   const Array< double >         &in_adEdgeWeights ) const
{
    Array<Vertex> av;
    av += in_v2;
    return FindPath( in_v1, av, in_abEdgeNoCross, in_adEdgeWeights );
}

Array<Vertex> PMeshLite::FindPath( const Vertex &in_v1, 
                                   const Vertex &in_v2, 
                                   const Array< double > &in_adEdgeWeights ) const
{
    Array<Vertex> av;
    av += in_v2;

    boost::dynamic_bitset<> abNoCross( NumVertices() );
    abNoCross.reset( );

    return FindPath( in_v1, av, abNoCross, in_adEdgeWeights );
}

Array<Vertex> PMeshLite::FindPath( const Vertex &in_v1, 
                                   const Vertex &in_v2 ) const
{
    Array<Vertex> av;
    av += in_v2;

    boost::dynamic_bitset<> abNoCross( NumVertices() );
    abNoCross.reset( );

    Array<double> adEdgeLen( NumEdges() );
    adEdgeLen.fill( 1 );

    return FindPath( in_v1, av, abNoCross, adEdgeLen );
}

Array<Vertex> PMeshLite::FindPath( const Vertex &in_v1, 
                                   const Array<Vertex> &in_av2, 
                                   const Array< double > &in_adEdgeWeights ) const
{
    boost::dynamic_bitset<> abNoCross( NumVertices() );
    abNoCross.reset( );

    return FindPath( in_v1, in_av2, abNoCross, in_adEdgeWeights );
}

Array<Vertex> PMeshLite::FindPath( const Vertex &in_v1, 
                                   const Vertex &in_v2, 
                                   const boost::dynamic_bitset<> &in_abEdgeNoCross ) const
{
    Array<double> adEdgeLen( NumEdges() );
    adEdgeLen.fill( 1 );

    Array<Vertex> av;
    av += in_v2;
    return FindPath( in_v1, av, in_abEdgeNoCross, adEdgeLen );
}

Array<Vertex> PMeshLite::FindPath( const Vertex &in_v1, 
                                   const Array<Vertex> &in_av, 
                                   const boost::dynamic_bitset<> &in_abEdgeNoCross ) const
{
    boost::dynamic_bitset<> abFoo(10), abBar(10);
    abFoo.reset();
    abBar.reset();
    
    Array<double> adEdgeLen( NumEdges() );
    adEdgeLen.fill( 1 );

    return FindPath( in_v1, in_av, in_abEdgeNoCross, adEdgeLen );
}

Array<Vertex> PMeshLite::FindPath( const Vertex &in_v1, 
                                   const Array<Vertex> &in_av ) const
{
    boost::dynamic_bitset<> abNoCross( NumVertices() );
    abNoCross.reset( );

    Array<double> adEdgeLen( NumEdges() );
    adEdgeLen.fill( 1 );

    return FindPath( in_v1, in_av, abNoCross, adEdgeLen );
}

///
const Array<double> PMeshLite::EdgeLengths() const
{
    Array<double> adEdgeLengths( NumEdges() );

    ForMeshEdge( Mesh(), e ) {
        adEdgeLengths[ e->IndexId() ] = GetEdgeLength( e );
    } EndFor;

    return adEdgeLengths;
}



WINbool PMeshLite::FindPath( const Face in_oF1,
                             const Face in_oF2,
                             const boost::dynamic_bitset<> & in_abEdgeNoCross,
                             Array<Face >                  & out_aopFs ) const
{
    Array<Face> afMesh( NumFaces() );
    AllMeshFaces(afMesh);

    const int iMax = 10 * NumEdges();
    Array<Face> aopFFrom( NumFaces() );
    Array<int> aiDist( NumFaces() );
    Array< Array<Face> > aafNeigh( NumFaces() );
    for ( int i = 0; i < aiDist.num(); i++ ) {
        aiDist[i] = iMax;
        aopFFrom[i] = NULL;

        ASSERT( i == afMesh[i]->IndexId() );
        Array<Edge> aopEs = FaceEdges( afMesh[i] );
        for ( int iE = 0; iE < aopEs.num(); iE++ ) {
            if ( !in_abEdgeNoCross[ aopEs[iE]->IndexId() ] ) {
                Face f1 = EdgeFace1( aopEs[iE] );
                Face f2 = EdgeFace2( aopEs[iE] );
                if ( f1 == afMesh[i] ) {
                    aafNeigh[i] += f2;
                } else {
                    ASSERT( f2 == afMesh[i] );
                    aafNeigh[i] += f1;
                }
            }
        }
    }

    WINbool bAllFound = FALSE;

    aiDist[ in_oF1->IndexId() ] = 0;
    aopFFrom[ in_oF1->IndexId() ] = in_oF1;
    while ( bAllFound == FALSE ) {
        bAllFound = TRUE;
        for ( int i = 0; i < NumFaces(); i++ ) {
            const int iDist = aiDist[ i ];
            if ( iDist == iMax ) continue;

            const Array<Face> &afNeigh = aafNeigh[i];
            for ( int j = 0; j < afNeigh.num(); j++ ) {
                const int iFId = afNeigh[j]->IndexId();
                if ( iDist + 1 < aiDist[ iFId ] ) {
                    //TRACE("%d owner %d\n", iVId, m_aiVertexOwner[ iVId ] );
                    aopFFrom[iFId] = afMesh[i];
                    aiDist[ iFId ] = iDist + 1;
                    bAllFound = FALSE;
                }
            }
        }
    }

    Face opMe = in_oF2;
    Face opF =  aopFFrom[ in_oF2->IndexId() ];
    Face opHome = in_oF1;
    out_aopFs.need(0);

    if ( aopFFrom[ opMe->IndexId() ] == NULL ) {
        return FALSE;
    }

    //ASSERT( aopVFrom[ in_oV2->IndexId() ] != NULL );

    out_aopFs += opMe;
    while ( ! ( out_aopFs.last() == opHome ) ) {
        out_aopFs += opF;
        opMe = opF;
        opF = aopFFrom[ opF->IndexId() ];
    }

    return TRUE;
}

int PMeshLite::SwapEdges( const Array<double> in_adDist ) {
   int iSwap = 0;

    Array<Edge> aeAll;
    AllMeshEdges( aeAll );

    Array<Face> afNorm;
    for ( int i = 0; i < aeAll.num(); i++ ) {
        if ( IsOkToSwap( aeAll[i] ) == FALSE ) 
            continue;

        Vertex v1 = EdgeVertex1( aeAll[i] );
        Vertex v2 = EdgeVertex2( aeAll[i] );
        Vertex vOp1 = SideVertex1( aeAll[i] );
        Vertex vOp2 = SideVertex2( aeAll[i] );
        Face f1 = EdgeFace1( aeAll[i] );
        Face f2 = EdgeFace2( aeAll[i] );

        const Array<Vertex> avF1 = FaceVertices( f1 );
		  const R3Vec vecF1 = Cross( avF1[1]->GetLoc() - avF1[0]->GetLoc(), avF1[2]->GetLoc() - avF1[0]->GetLoc() );

		  const R3Vec vecFNew1 = Cross( vOp1->GetLoc() - v1->GetLoc(), vOp2->GetLoc() - v1->GetLoc() );
		  const R3Vec vecFNew2 = Cross( vOp2->GetLoc() - v2->GetLoc(), vOp1->GetLoc() - v2->GetLoc() );
	
        const double dDot1 = Dot( vecF1, vecFNew1 );
        const double dDot2 = Dot( vecF1, vecFNew2 );

        if ( dDot1 > 0.0 || dDot2 > 0.0 )
            continue;

        const double dLen = Length( v1->GetLoc() - v2->GetLoc() );
        const double dLenSwap = Length( vOp1->GetLoc() - vOp2->GetLoc() );

        if ( VertexVertices( v1 ).num() == 4 )
            continue;
        if ( VertexVertices( v2 ).num() == 4 )
            continue;

        const double dIdealLen = 0.5 * (in_adDist[v1->IndexId()] + in_adDist[v2->IndexId()]);

        if ( fabs( dLen - dIdealLen ) > fabs( dLenSwap - dIdealLen ) ) {
            EdgeSwap( aeAll[i] );

            v1->SetColor( UTILSColor(1,0,1) );
            v2->SetColor(  UTILSColor(1,0,1) );

            afNorm += f1;
            afNorm += f2;

            iSwap++;
        }
    }

    Array<Vertex> av;
    Compute_normals( av, afNorm );

    return iSwap;
}

int PMeshLite::Grow( const Array<Vertex> &in_aopVs, 
                     Array<Edge> &out_aopEs,
                     Array<Face> &out_aopFs ) const
{
    int iCount = 0;

    boost::dynamic_bitset<> abEs( Mesh().nextEdgeId() ), abFs( Mesh().nextFaceId() );
    abEs.reset();
    abFs.reset();
    for ( int iE = 0; iE < out_aopEs.num(); iE++ )
        abEs.set(out_aopEs[iE]->IndexId());
    for ( int iF = 0; iF < out_aopFs.num(); iF++ )
        abFs.set(out_aopFs[iF]->IndexId());

    for ( int i = 0; i < in_aopVs.num(); i++ ) {
        ForVertexEdge( Mesh(), in_aopVs[i], e ) {
            if ( !abEs[ e->IndexId() ] ) {
                out_aopEs += e;
                abEs.set( e->IndexId() );
                iCount++;
            }
        } EndFor;

        ForVertexFace( Mesh(), in_aopVs[i], f ) {
            if ( !abFs[ f->IndexId() ] ) {
                out_aopFs += f;
                abFs.set( f->IndexId() );
                iCount++;
            }
        }EndFor;
    }
    return iCount;
}

int PMeshLite::Grow( const Array<Face> &  in_aopFs, 
                           Array<Vertex> &out_aopVs,
                           Array<Edge  > &out_aopEs ) const
{
    int iCount = 0;

    boost::dynamic_bitset<> abVs( Mesh().nextVertexId() ), abEs( Mesh().nextEdgeId() );
    abVs.reset();
    abEs.reset();
    for ( int iV = 0; iV < out_aopVs.num(); iV++ )
        abVs.set(out_aopVs[iV]->IndexId());
    for ( int iE = 0; iE < out_aopEs.num(); iE++ )
        abEs.set(out_aopEs[iE]->IndexId());

    for ( int i = 0; i < in_aopFs.num(); i++ ) {
        ForFaceVertex( Mesh(), in_aopFs[i], v ) {
            if ( !abVs[ v->IndexId() ] ) {
                out_aopVs += v;
                abVs.set(v->IndexId());
                iCount++;
            }
        } EndFor;

        ForFaceEdge( Mesh(), in_aopFs[i], e ) {
            if ( !abEs[ e->IndexId() ] ) {
                out_aopEs += e;
                abEs.set( e->IndexId() );
                iCount++;
            }
        }EndFor;
    }
    return iCount;
}
    ///
int PMeshLite::Grow( const Array<Edge> &  in_aopEs, 
                           Array<Vertex> &out_aopVs,
                           Array<Face  > &out_aopFs ) const
{ 
    int iCount = 0;

    boost::dynamic_bitset<> abVs( Mesh().nextVertexId() ), abFs( Mesh().nextFaceId() );
    abVs.reset();
    abFs.reset();
    for ( int iV = 0; iV < out_aopVs.num(); iV++ )
        abVs.set(out_aopVs[iV]->IndexId());
    for ( int iF = 0; iF < out_aopFs.num(); iF++ )
        abFs.set(out_aopFs[iF]->IndexId());

    for ( int i = 0; i < in_aopEs.num(); i++ ) {
        Vertex v1 = EdgeVertex1( in_aopEs[i] );
        Vertex v2 = EdgeVertex2( in_aopEs[i] );
        Face   f1 = EdgeFace1( in_aopEs[i] );
        Face   f2 = EdgeFace2( in_aopEs[i] );

        if ( !abVs[v1->IndexId()] ) {
            out_aopVs += v1;
            abVs.set(v1->IndexId());
            iCount++;
        }

        if ( !abVs[v2->IndexId()] ) {
            out_aopVs += v2;
            abVs.set(v2->IndexId());
            iCount++;
        }

        if ( f1 && !abFs[f1->IndexId()] ) {
            out_aopFs += f1;
            abFs.set( f1->IndexId() );
            iCount++;
        }
        if ( f2 && !abFs[f2->IndexId()] ) {
            out_aopFs += f2;
            abFs.set( f1->IndexId() );
            iCount++;
        }
    }
    return iCount;
}

int PMeshLite::Grow( boost::dynamic_bitset<> &io_abVs, const int in_iLoops ) const
{
    int iCount = 0;

    boost::dynamic_bitset<> abEs( Mesh().nextEdgeId() ), abVNew( Mesh().nextVertexId() );
    abEs.reset();
    
    abVNew = io_abVs;
    for ( int iL = 0; iL < in_iLoops; iL++ ) {
        abEs.reset();
        
        for ( int iV = abVNew.find_first(); iV != -1; iV = abVNew.find_next( iV ) ) {
            const Vertex v = VertexFromIndexId(iV);
            ForVertexEdge( Mesh(), v, e ) {
                abEs.set( e->IndexId() );
            }EndFor;
        }
        
        abVNew.reset();
        for ( int iE = abEs.find_first(); iE != -1; iE = abEs.find_next( iE ) ) {
            const Edge e = EdgeFromIndexId( iE );
            if ( !io_abVs[ EdgeVertex1(e)->IndexId() ] ) {
                abVNew.set( EdgeVertex1(e)->IndexId() );
            }
            if ( !io_abVs[ EdgeVertex2(e)->IndexId() ] ) {
                abVNew.set( EdgeVertex2(e)->IndexId() );
                iCount++;
            }
        }
        io_abVs = io_abVs | abVNew;
    }
    return iCount;
}

void PMeshLite::allAttached(const Array<Vertex> &in_Vs, boost::dynamic_bitset<> &out_Vs, boost::dynamic_bitset<> &out_Es, boost::dynamic_bitset<> &out_Fs)
{

	out_Vs = boost::dynamic_bitset<>(Mesh().numVertices());
	out_Vs.reset();

	out_Es = boost::dynamic_bitset<>(Mesh().numEdges());
	out_Es.reset();

	out_Fs = boost::dynamic_bitset<>(Mesh().numFaces());
	out_Fs.reset();

	for(int i = 0; i < in_Vs.num(); ++i){
		out_Vs.set(in_Vs[i]->IndexId());
	}

	Array<Face> faces;
	Array<Edge> edges;
	Array<Vertex> faceVs;
	for( FORINT i = 0; i < in_Vs.num(); ++i){
		faces = VertexFaces(in_Vs[i]);
		edges = VertexEdges(in_Vs[i]);

		for(int j = 0; j < faces.num(); ++j){
			faceVs = PMeshLite::FaceVertices(faces[j]);
			ASSERT(faceVs.num() == 3);
			const bool v1 = out_Vs.test(faceVs[0]->IndexId());
			const bool v2 = out_Vs.test(faceVs[1]->IndexId());
			const bool v3 = out_Vs.test(faceVs[2]->IndexId());
			if(v1 && v2 && v3){
				out_Fs.set(faces[j]->IndexId());
			}
		}

		for( FORINT j = 0; j < edges.num(); ++j){
			const Vertex edgeV1 = PMeshLite::EdgeVertex1(edges[j]);
			const Vertex edgeV2 = PMeshLite::EdgeVertex2(edges[j]);
			const bool v1 = out_Vs.test(edgeV1->IndexId());
			const bool v2 = out_Vs.test(edgeV2->IndexId());
			if(v1 && v2){
				out_Es.set(edges[j]->IndexId());
			}

		}
	}
}

void PMeshLite::allAttached(const boost::dynamic_bitset<> &in_Vs, boost::dynamic_bitset<> &out_Es, boost::dynamic_bitset<> &out_Fs)
{

	out_Es = boost::dynamic_bitset<>(Mesh().numEdges());
	out_Es.reset();

	out_Fs = boost::dynamic_bitset<>(Mesh().numFaces());
	out_Fs.reset();



	Array<Face> faces;
	Array<Edge> edges;
	Array<Vertex> faceVs;
	int pos = 0;
	while((pos = in_Vs.find_next(pos)) != in_Vs.npos){
		faces = VertexFaces(VertexFromIndexId(pos));
		edges = VertexEdges(VertexFromIndexId(pos));

		for(int j = 0; j < faces.num(); ++j){
			faceVs = PMeshLite::FaceVertices(faces[j]);
			ASSERT(faceVs.num() == 3);
			const bool v1 = in_Vs.test(faceVs[0]->IndexId());
			const bool v2 = in_Vs.test(faceVs[1]->IndexId());
			const bool v3 = in_Vs.test(faceVs[2]->IndexId());
			if(v1 && v2 && v3){
				out_Fs.set(faces[j]->IndexId());
			}
		}

		for( FORINT j = 0; j < edges.num(); ++j){
			const Vertex edgeV1 = PMeshLite::EdgeVertex1(edges[j]);
			const Vertex edgeV2 = PMeshLite::EdgeVertex2(edges[j]);
			const bool v1 = in_Vs.test(edgeV1->IndexId());
			const bool v2 = in_Vs.test(edgeV2->IndexId());
			if(v1 && v2){
				out_Es.set(edges[j]->IndexId());
			}

		}
	}
}

int PMeshLite::GrowRings( const Vertex &in_vertex, 
                          const int nRings,
                          Array<Vertex> &out_aopVs,
				          Array<Face>   &out_aopFs ) const
{
	int i, j, k, n;
	R3Pt P;
	Array<R3Pt>   apt;
    Array<Vertex> aov;
	Array<Edge>   aopEs;

	out_aopVs.clearcompletely();
	out_aopFs.clearcompletely();
	out_aopVs += in_vertex;
	apt += in_vertex->GetLoc();

	for( i=0; i<nRings; i++ ) {

		// Find adjacent faces for next ring
		n = Grow( out_aopVs, aopEs, out_aopFs );

		// Update list vertices for new ring
		for( j=0; j<out_aopFs.num(); j++ ) {
			aov = FaceVertices(out_aopFs[j]);
			for( k=0; k<aov.num(); k++ ) {
				P = aov[k]->GetLoc();
				const int iIndx = apt.index( P );
				if( iIndx == -1 ) {
					out_aopVs += aov[k];
						apt += P;
				}
			}
		}
	}

	return out_aopFs.num();
}
//might be the same as ExtractCopy below
void PMeshLite::MakeSubMesh( const boost::dynamic_bitset<> &in_abFaces, PMeshLite &newMesh ) const
{
    newMesh.Clear();
    WINbool s_bTrace = FALSE;
    Array<int> aiVNewMesh;
    for ( int fid = in_abFaces.find_first(); fid != -1; fid = in_abFaces.find_next(fid) ) {
        Array<Vertex> avFace = FaceVertices(FaceFromIndexId(fid));
        Array<Vertex> avFaceNew(avFace.num()) ;
        for ( int iV = 0; iV < avFace.num(); iV ++ ) {
            if(aiVNewMesh.index( avFace[iV]->IndexId() ) == -1){
                Vertex v = newMesh.AddVertex(avFace[iV]->GetLoc());
                aiVNewMesh += avFace[iV]->IndexId();
                avFaceNew[iV] = v;
            }
            else
                avFaceNew[iV] = newMesh.VertexFromIndexId(aiVNewMesh.index( avFace[iV]->IndexId() ));         

        }
        newMesh.AddFace(avFaceNew);
    }
    
    //newMesh.Write(WINDataHome("test/chartMesh.m"));
    if( s_bTrace && (newMesh.NumVertices() - newMesh.NumEdges() + newMesh.NumFaces() != 1))
            TRACE("Chart is not a disk\n");

    if(s_bTrace){
        UTILSDotArray dots;
        ForMeshVertex( newMesh.Mesh(), v ) {
            dots.Add( v->GetLoc(), UTILSColor::GREY );
        } EndFor;

	    dots.Write( WINDataHome("test/newMesh.txt") );
        
    }
}

int PMeshLite::ExtractCopy(const Array<Face> &in_aopFs,
					       PMeshLite &newMesh ) const
{
	int i, j;
	R3Pt P;
	Array<R3Pt> apt;
    int newId;

	newMesh.Clear();
	Array<Vertex> aov;
    Array<Vertex> aopVs;
    Array<Vertex> aopF;

	for( i=0; i<in_aopFs.num(); i++ ) {
		aov = FaceVertices(in_aopFs[i]);
		aopF.need(0);
		for( j=0; j<aov.num(); j++ ) {
			P = aov[j]->GetLoc();
			const int iIndx = apt.index( P );
			if ( iIndx == -1 ) {
                newId = apt.num();
                aopVs += newMesh.AddVertex( P );
				// Copy normal
                apt += P;
            } else {
                newId = iIndx;
            }
			aopF += aopVs[newId];
		}
        if ( newMesh.IsOkToAdd( aopF ) )
            newMesh.AddFace( aopF );
        else
            ASSERT(FALSE);
	}
	
    newMesh.Renumber();

	return newMesh.NumVertices();
}

int PMeshLite::ExtractCopy(const Array<Face> &in_aopFs,
					       PMeshLite &newMesh, Array<Vertex> &out_aopVs ) const
{
	int i, j;
	R3Pt P;
	Array<R3Pt> apt;
    int newId;

	newMesh.Clear();
	Array<Vertex> aov;
    Array<Vertex> aopVs;
    Array<Vertex> aopF;

	FILE *out = NULL;
	out = fopen(WINDataHome("extract.dat"),"a");

	out_aopVs.need(0);

	if( out != NULL ) {
		fprintf(out,"\nExtracting %d faces from $d vertices, %d faces\n",
			        in_aopFs.num(), NumVertices(), NumFaces() );
	}

	for( i=0; i<in_aopFs.num(); i++ ) {
		aov = FaceVertices(in_aopFs[i]);
		aopF.need(0);
		for( j=0; j<aov.num(); j++ ) {
			P = aov[j]->GetLoc();
			const int iIndx = apt.index( P );
			if ( iIndx == -1 ) {
				out_aopVs += aov[j];
                newId = apt.num();
                aopVs += newMesh.AddVertex( P );
				// Copy normal
                apt += P;
				if( out != NULL ) {
					fprintf(out,"j=%d, IndexId=%d, NewId=%d (%lf %lf %lf)\n",
						        j, aov[j]->IndexId(), newId, P[0], P[1], P[2] );
				}
            } else {
                newId = iIndx;
            }
			aopF += aopVs[newId];
		}
        if ( newMesh.IsOkToAdd( aopF ) )
            newMesh.AddFace( aopF );
        else
            ASSERT(FALSE);
	}
	
    newMesh.Renumber();

	if(out != NULL ) fclose(out);

	return newMesh.NumVertices();
}

int PMeshLite::GetComponents( Array< unsigned short > &out_ausLabels, Array<int> &out_aiLabels ) const
{
    TRACE("Find components\n");
    out_ausLabels.need( NumVertices() );
    out_ausLabels.memfill( 0 );

    out_aiLabels.need(1);
    out_aiLabels[0] = 0;

    int iTouched = 0;
    Array<int> aiStack;
    Array<Vertex> av;
    AllMeshVertices( av );

    while ( iTouched < NumVertices() ) {
        const int iLabel = out_aiLabels.num();
        out_aiLabels += 1;
        iTouched++;
        for ( int i = 0; i < out_ausLabels.num(); i++ ) {
            if ( out_ausLabels[i] == 0 ) {
                aiStack += i;
                out_ausLabels[i] = iLabel;
                break;
            }
        }
        while ( aiStack.num() ) {
            const int iStack = aiStack.last();
            aiStack.sub(1);
            ForVertexVertex( Mesh(), av[iStack], vv ) {
                if ( out_ausLabels[ vv->IndexId() ] == 0 ) {
                    out_ausLabels[ vv->IndexId() ] = iLabel;
                    aiStack += vv->IndexId();
                    out_aiLabels[ iLabel ]++;
                    iTouched++;
                } else {
                    ASSERT( out_ausLabels[ vv->IndexId() ] == iLabel );
                }
            } EndFor;
        }
    }

    TRACE("Num components %d: ", out_aiLabels.num() - 1 );
    for ( int i = 1; i < out_aiLabels.num(); i++ ) {
        TRACE("%d,%d ", i,out_aiLabels[i]);
    }
    TRACE("\n");

    return out_aiLabels.num() - 1;
}


void PMeshLite::GetOneComponent( PMeshLite &out_mesh ) const
{
    Array<unsigned short> ausLabel( NumVertices() );
    Array<int> aiLabels;

    GetComponents( ausLabel, aiLabels );

    int iKeep = 1;
    for ( int i = 1; i < aiLabels.num(); i++ ) {
        if ( aiLabels[iKeep] < aiLabels[i] )
            iKeep = i;
    }

    out_mesh = *this;

    ForMeshVertex( out_mesh.Mesh(), v ) {
        if ( ausLabel[v->IndexId()] != iKeep ) {
            out_mesh.RemoveAdjacentFaces( v );
        } else if ( out_mesh.VertexFaces(v).num() == 0 ) {
            out_mesh.RemoveVertex(v);
        }
    } EndFor;

    ForMeshVertex( out_mesh.Mesh(), v ) {
        if ( ausLabel[v->IndexId()] != iKeep ) {
            out_mesh.RemoveVertex( v );
        } 
    } EndFor;

    out_mesh.Renumber();
}

// Called by TryCorners
void PMeshLite::CheckBoundary( const Array<Vertex> &in_av, const Array<Edge> &in_ae) const
{
#ifdef DEBUG
    for ( int i = 0; i < in_av.num(); i++ ) {
        Vertex v1 = EdgeVertex1( in_ae[i] );
        Vertex v2 = EdgeVertex2( in_ae[i] );

        ASSERT( (in_av.wrap( i-1 ) == v1 && in_av.wrap( i ) == v2) ||
                (in_av.wrap( i-1 ) == v2 && in_av.wrap( i ) == v1)
            );

    }
#endif
}

WINbool PMeshLite::CheckVs( Face                  in_of, 
                             const Array<Vertex > &in_aopVs ) const
{
    const Array<Vertex > &aopFVs = FaceVertices( in_of );
    Array<int> aiIndex( aopFVs.num() );
    for (int i = 0; i < aopFVs.num(); i++ ) {
        aiIndex[i] = in_aopVs.index( aopFVs[i] );
    }
    WINbool bFoundE1 = FALSE, bFoundE2 = FALSE;
    WINbool bFoundContiguous = FALSE, bFoundOrder = FALSE;
    for ( FORINT i = 0; i < aopFVs.num(); i++ ) {
        if ( aiIndex[i] != -1 && aiIndex.wrap(i+1) != -1 ) {
            if ( aiIndex.wrap(i+2) != -1 ) {
                bFoundContiguous = TRUE;
                const int iNextIndex = (aiIndex[i] - 1 + in_aopVs.num()) % in_aopVs.num();
                const int iNextNextIndex = (aiIndex.wrap(i+1) - 1 + in_aopVs.num()) % in_aopVs.num();
                if ( aiIndex.wrap(i+1) == iNextIndex && aiIndex.wrap(i+2) == iNextNextIndex ) {
                    bFoundOrder = TRUE;
                }
            } else {
                const int iNextIndex = (aiIndex[i] - 1 + in_aopVs.num()) % in_aopVs.num();
                if ( aiIndex.wrap(i+1) != iNextIndex ) {
                    return FALSE;
                }
            }
        } else if ( aiIndex[i] != -1 && aiIndex.wrap(i+1) == -1  ) {
            if ( bFoundE1 == TRUE )
                return FALSE;
            bFoundE1 = TRUE;
        } else if ( aiIndex[i] == -1 && aiIndex.wrap(i-1) != -1 ) {
            if ( bFoundE2 == TRUE )
                return FALSE;
            bFoundE2 = TRUE;
        }
    }

    if ( bFoundContiguous == TRUE && bFoundOrder == TRUE )
        return TRUE;

    if ( bFoundContiguous == TRUE && bFoundOrder == FALSE )
        return FALSE;

    ASSERT( bFoundE1 == TRUE && bFoundE2 == TRUE );

    return TRUE;
}

WINbool PMeshLite::EatWedge( Array<Vertex> & io_avBdry, 
                             Array<Edge>   & io_aeBdry, 
                             boost::dynamic_bitset<>       & io_abInDisk, 
                             const boost::dynamic_bitset<> & in_abNoCross ) const
{

    for ( int iV = 0; iV < io_avBdry.num(); iV++ ) {
        const Face f1 = EdgeFace1( io_aeBdry[iV] );
        const Face f2 = EdgeFace2( io_aeBdry[iV] );

        Face fWedge = NULL;
        // Only one of these should be true
        if ( f1 && !io_abInDisk[f1->IndexId()] ) {
            const Array<Vertex> avF = FaceVertices( f1 );
            const int iIndex = avF.index( io_avBdry[iV] );
            if ( avF.wrap(iIndex - 1) == io_avBdry.wrap(iV+1) && avF.wrap(iIndex + 1) == io_avBdry.wrap(iV-1) ) {
                fWedge = f1;
            }
        }
        if ( f2 && !io_abInDisk[f2->IndexId()] ) {
            const Array<Vertex> avF = FaceVertices( f2 );
            const int iIndex = avF.index( io_avBdry[iV] );
            if ( avF.wrap(iIndex - 1) == io_avBdry.wrap(iV+1) &&
                 avF.wrap(iIndex + 1) == io_avBdry.wrap(iV-1) ) {
                fWedge = f2;
            }
        }
        if ( fWedge ) {
            io_avBdry.del( iV, 1 );
            io_aeBdry.del( iV, 1 );
            io_aeBdry.wrap(iV) = EdgeFromVertices( io_avBdry.wrap(iV-1), io_avBdry.wrap(iV) );
            io_abInDisk.set( fWedge->IndexId() );
            CheckBoundary( io_avBdry, io_aeBdry );
            return TRUE;
        }
    }
    return FALSE;
}

WINbool PMeshLite::GrowDisk( Array<Vertex> & io_avBdry, 
                             Array<Edge>   & io_aeBdry, 
                             boost::dynamic_bitset<> & io_abInDisk, 
                             const boost::dynamic_bitset<> & in_abNoCross ) const
{
		//UTILSDotArray mDots;
    if ( s_bTrace ){
        CheckBoundary( io_avBdry, io_aeBdry );
/*
		for ( int iE = 0; iE < io_aeBdry.num(); iE++ ) {
			mDots.Add(io_avBdry[iE]->GetLoc(), UTILSColor::RED);
			mDots.AddPair( EdgeVertex1( io_aeBdry[iE] )->GetLoc(), 
							  EdgeVertex2( io_aeBdry[iE] )->GetLoc(), UTILSColor::GREEN  );
		}    
		mDots.Write( "E:/CVS-graphics-XP/cmg/Data/data-from-Sandra/chick1-040410-Mar1/m-files/180/test/GrowDisk0.txt" );*/
	}

    // Edge i has vertex i and i-1
    Array< Edge > aopVEs;
    Array< Face>  aopVFs;
    boost::dynamic_bitset<> abBdryF( NumFaces() );

    abBdryF.reset();

    // Get all faces touching a boundary vertex that are
    // not already owned.
    for ( int i = 0; i < io_avBdry.num(); i++ ) {
        VertexEdgeFace( io_avBdry[i], aopVEs, aopVFs );
		/*
		mDots.RemoveAll();		
		mDots.Add(io_avBdry[i]->GetLoc(), UTILSColor::RED);
		mDots.AddPair( EdgeVertex1( io_aeBdry[i] )->GetLoc(), EdgeVertex2( io_aeBdry[i] )->GetLoc(), UTILSColor::GREEN );
		mDots.Write( "E:/CVS-graphics-XP/cmg/Data/data-from-Sandra/chick1-040410-Mar1/m-files/180/test/GrowDisk0.txt" );
		for ( int iE = 0; iE < aopVEs.num(); iE++ ) {
				mDots.AddPair( EdgeVertex1( aopVEs[iE] )->GetLoc(), 
							  EdgeVertex2( aopVEs[iE] )->GetLoc(), 
									UTILSColor::Ramp(0, aopVEs.num(), iE, UTILSColor::INCREASING_RGB ) );
		}    
		mDots.Write( "E:/CVS-graphics-XP/cmg/Data/data-from-Sandra/chick1-040410-Mar1/m-files/180/test/GrowDisk0.txt" );
*/
        
        const int iIndx = aopVEs.index( io_aeBdry[i] );

        if ( in_abNoCross[ io_aeBdry[i]->IndexId() ] )
            continue;

		if( aopVFs.num() == iIndx ){
			ASSERT(IsBoundary(io_aeBdry[i]));
			continue;
		}
		else{
			if ( io_abInDisk[ aopVFs[iIndx]->IndexId() ] ) 
				continue;

			if ( abBdryF[ aopVFs[iIndx]->IndexId() ] ) 
				continue;

			abBdryF.set( aopVFs[iIndx]->IndexId() );
		}
    }

    if ( abBdryF.count() == 0 ) {
        if ( s_bTrace )
	  TRACE("GrowCap: No grow %d\n", (int) io_abInDisk.count() );
        return FALSE;
    }

    // Need to mark any edges which are no longer boundaries
    // Mark edges which are now boundaries
    // Replace string of old edges with new edges
    // start, stop of replaced edges/vertices on current string
    // start, stop of new edges/vertices in edges/vertices around face
    int iAdded = 0;
    Array<Vertex> aopFVs, aopNewVs;
    Array<Edge>   aopFEs, aopNewEs;
    Array<int>    aiLabelE;
    for ( FORINT i = abBdryF.find_first(); i != -1; i = abBdryF.find_next(i) ) {
        Face f = FaceFromIndexId(i);

        // Check that the intersection of the face and the boundary chain is contiguous
        if ( CheckVs( f, io_avBdry ) == FALSE ) {
            continue;
        }

        aopFVs = FaceVertices( f );
        aopFEs = FaceEdges( f );
        aiLabelE.need( aopFEs.num() );

        // Walk through the edges of the face
        //   If this edge is on the boundary, get its index
        for ( int j = 0; j < aopFVs.num(); j++ ) {
            int iEIndx = io_aeBdry.index( aopFEs[j] );
            if ( iEIndx != -1 ) {
                // This edge is on the boundary chain
                for ( int k = iEIndx + 1; k < io_aeBdry.num(); k++ ) {
                    if ( io_aeBdry[k] != aopFEs[j] ) 
                        continue;

                    // Look for latest occurance of this face in the edge list
                    Face opF1 = EdgeFace1( io_aeBdry[k] );
                    Face opF2 = EdgeFace2( io_aeBdry[k] );
                    Vertex opV1 = EdgeVertex1( io_aeBdry[k] );
                    if ( opV1 == io_avBdry.wrap( k-1 ) ) {
                        if ( opF2 == f )
                            iEIndx = k;
                    } else {
                        if ( opF1 == f )
                            iEIndx = k;
                    }
                }
            }
            aiLabelE[j] = iEIndx; // Where in old edge bdry
            //TRACE("V %d E %d Label %d\n", aopFVs[j]->IndexId(), aopFEs[j]->IndexId(), aiLabelE[j] );
        }
        int iStartOldBdry = -1, iEndOldBdry = -1;
        int iStartNewBdry = -1, iEndNewBdry = -1;
        int iDel = 0, iAdd = 0;
        for ( FORINT j = 0; j < aiLabelE.num(); j++ ) {
            if ( aiLabelE[j] == -1 && aiLabelE.wrap(j+1) != -1 ) {
                if (iStartOldBdry != -1)
                    ASSERT(FALSE);
                iStartOldBdry = (j+1) % aiLabelE.num();
                iEndNewBdry = j;
            }
            if ( aiLabelE[j] != -1 && aiLabelE.wrap(j+1) == -1 ) {
                if ( iEndOldBdry != -1 ) ASSERT(FALSE);
                iEndOldBdry = j;
                iStartNewBdry = (j+1) % aiLabelE.num();
            } 
            if ( aiLabelE[j] != -1 ) {
                iDel++;
            } else {
                iAdd++;
            }
        }

        if ( iStartOldBdry == -1 && iEndOldBdry == -1 ) {
            int iMin = aiLabelE[0];
            for ( int j = 0; j < aiLabelE.num(); j++ )
                iMin = WINmin( aiLabelE[j], iMin );
            ASSERT( io_avBdry.wrap( iMin - 1 ) == io_avBdry.wrap( iMin + 2 ) );
            io_avBdry.del( (iMin - 1 + io_avBdry.num()) % io_avBdry.num() , 3 );
            io_aeBdry.del( iMin, 3 );
        } else {

            //TRACE("%d %d  %d %d\n", iStartOldBdry, iDel, iStartNewBdry, iAdd );

            const int iKill = aiLabelE[ iEndOldBdry ];
            int iAddAtV = iKill;
            int iAddAtE = iKill;
            if ( iKill + iDel > io_avBdry.num() + 1 ) {
                ASSERT( iDel == 2 );

                io_avBdry.del( iKill, iDel - 1 );
                Array<Vertex > aopNewVs;
                for ( FORINT j = 0; j < iAdd-1; j++ )
                    aopNewVs += aopFVs.wrap( iStartNewBdry + j );
                io_avBdry.add( aopNewVs, 0 );
        
                io_aeBdry.del( iKill, 1 );
                io_aeBdry.del( 0, 1 );
                aopNewEs.need(0);
                for ( FORINT j = 0; j < iAdd; j++ )
                    aopNewEs += aopFEs.wrap( iStartNewBdry + j );
                io_aeBdry.add( aopNewEs, 0  );
            } else {
            //TRACE("Kill %d  AddV %d AddE %d\n", iKill, iAddAtV, iAddAtE );
                if ( iKill + iDel == io_avBdry.num() + 1 ) {
                    iAddAtV = 0;
                    iAddAtE = 0;
                }

                io_avBdry.del( iKill, iDel - 1 );
                aopNewVs.need(0);
                for ( FORINT j = 0; j < iAdd-1; j++ )
                    aopNewVs += aopFVs.wrap( iStartNewBdry + j );
                io_avBdry.add( aopNewVs, iAddAtV );
        
                io_aeBdry.del( iKill, iDel );
                aopNewEs.need(0);
                for ( FORINT j = 0; j < iAdd; j++ )
                    aopNewEs += aopFEs.wrap( iStartNewBdry + j );
                io_aeBdry.add( aopNewEs, iAddAtE  );
            }
        }

        //TRACE("\n");

        ASSERT( io_avBdry.num() == io_aeBdry.num() );

        if ( s_bTrace )
            CheckBoundary( io_avBdry, io_aeBdry );

        io_abInDisk.set( i );
        iAdded++;
    }

    if ( iAdded > 0 ) {
        while ( EatWedge( io_avBdry, io_aeBdry, io_abInDisk, in_abNoCross ) )
            ;
    }
    return (iAdded > 0) ? TRUE : FALSE;
}
int PMeshLite::GrowDiskByFace( const Face &in_face,
                                  boost::dynamic_bitset<> &io_abInDisk,
                                  Array<Vertex> & io_avBdry, 
                                  Array<Edge>   & io_aeBdry,
                                  Array<int>   & out_wedgeEaten) const
{
    WINbool faceAdded = AddFaceToDisk(in_face, io_abInDisk, io_avBdry, io_aeBdry);
    boost::dynamic_bitset<> abNoCross( 0 );
    abNoCross.reset();
    if(faceAdded){
        out_wedgeEaten.need(0);
        boost::dynamic_bitset<> temp_abInDisk = io_abInDisk;
        for ( int iF = io_abInDisk.find_first(); iF != -1; iF = io_abInDisk.find_next(iF) ) {
            if(!temp_abInDisk[iF])
                out_wedgeEaten += iF;
        }
    }
    return (faceAdded? 1:0) + out_wedgeEaten.num();
}
///given current Vs and Es on the boundary, add the new face to chart
WINbool PMeshLite::AddFaceToDisk( const Face &in_face,
                                  boost::dynamic_bitset<> &io_abInDisk,
                                  Array<Vertex> & io_avBdry, 
                                  Array<Edge>   & io_aeBdry) const
{
   //actually adding the face
    ASSERT(io_avBdry.num()!=0);
    ASSERT(io_aeBdry.num()!=0);
    //CheckBoundary( io_avBdry, io_aeBdry );    

    // Need to mark any edges which are no longer boundaries
    // Mark edges which are now boundaries
    // Replace string of old edges with new edges
    // start, stop of replaced edges/vertices on current string
    // start, stop of new edges/vertices in edges/vertices around face
    Array<Vertex> avFVs, avNewVs;
    Array<Edge>   aeFEs, aeNewEs;
    Array<int>    aiLabelE;  

    avFVs = FaceVertices( in_face );
    aeFEs = FaceEdges( in_face );
    aiLabelE.need( aeFEs.num() );

    // Walk through the edges of the face
    //   If this edge is on the boundary, get its index
    for ( int iE = 0; iE < aeFEs.num(); iE++ ) {
        int iEIndx = io_aeBdry.index( aeFEs[iE] );
        aiLabelE[iE] = iEIndx; // Where in old edge bdry        
    }
    int iStartOldBdry = -1, iEndOldBdry = -1;
    int iStartNewBdry = -1, iEndNewBdry = -1;
    int iDel = 0, iAdd = 0;
    for ( FORINT iE = 0; iE < aiLabelE.num(); iE++ ) {
        if ( aiLabelE[iE] == -1 && aiLabelE.wrap(iE+1) != -1 ) {
            ASSERT(iStartOldBdry == -1);
            iStartOldBdry = (iE+1) % aiLabelE.num();
            iEndNewBdry = iE;
        }
        if ( aiLabelE[iE] != -1 && aiLabelE.wrap(iE+1) == -1 ) {
            ASSERT(iEndOldBdry == -1 );
            iEndOldBdry = iE;
            iStartNewBdry = (iE+1) % aiLabelE.num();
        } 
        if ( aiLabelE[iE] != -1 ) {
            iDel++;
        } else {
            iAdd++;
        }
    }

    if ( iStartOldBdry == -1 && iEndOldBdry == -1 ) {
        int iMin = aiLabelE[0];
        for ( int j = 0; j < aiLabelE.num(); j++ )
            iMin = WINmin( aiLabelE[j], iMin );
        ASSERT( io_avBdry.wrap( iMin - 1 ) == io_avBdry.wrap( iMin + 2 ) );
        io_avBdry.del( (iMin - 1 + io_avBdry.num()) % io_avBdry.num() , 3 );
        io_aeBdry.del( iMin, 3 );
    } else {
        const int iKill = aiLabelE[ iEndOldBdry ];
        int iAddAtV = iKill;
        int iAddAtE = iKill;
        if ( iKill + iDel > io_avBdry.num() + 1 ) {
            ASSERT( iDel == 2 );

            io_avBdry.del( iKill, iDel - 1 );
            Array<Vertex > aopNewVs;
            for ( int j = 0; j < iAdd-1; j++ )
                avNewVs += avFVs.wrap( iStartNewBdry + j );
            io_avBdry.add( aopNewVs, 0 );
    
            io_aeBdry.del( iKill, 1 );
            io_aeBdry.del( 0, 1 );
            aeNewEs.need(0);
            for ( FORINT j = 0; j < iAdd; j++ )
                aeNewEs += aeFEs.wrap( iStartNewBdry + j );
            io_aeBdry.add( aeNewEs, 0  );
        } else {
            if ( iKill + iDel == io_avBdry.num() + 1 ) {
                iAddAtV = 0;
                iAddAtE = 0;
            }

            io_avBdry.del( iKill, iDel - 1 );
            avNewVs.need(0);
            for ( int j = 0; j < iAdd-1; j++ )
                avNewVs += avFVs.wrap( iStartNewBdry + j );
            io_avBdry.add( avNewVs, iAddAtV );
    
            io_aeBdry.del( iKill, iDel );
            aeNewEs.need(0);
            for ( FORINT j = 0; j < iAdd; j++ )
                aeNewEs += aeFEs.wrap( iStartNewBdry + j );
            io_aeBdry.add( aeNewEs, iAddAtE  );
        }
    }
    ASSERT( io_avBdry.num() == io_aeBdry.num() );

    //CheckBoundary( io_avBdry, io_aeBdry );

    io_abInDisk.set(in_face->IndexId());

    return TRUE;
}

///check if the chart will remain a disk after adding this face
//might be duplicated with another method in this class
WINbool PMeshLite::OkayToAdd( const Face &in_of, const Array<Vertex > &in_aopVs ) const
{
    const Array<Vertex > &aopFVs = FaceVertices( in_of );
    Array<int> aiIndex( aopFVs.num() );
    for (int i = 0; i < aopFVs.num(); i++ ) {
        aiIndex[i] = in_aopVs.index( aopFVs[i] );
    }
    WINbool bFoundE1 = FALSE, bFoundE2 = FALSE;
    WINbool bFoundContiguous = FALSE, bFoundOrder = FALSE;
    for ( FORINT i = 0; i < aopFVs.num(); i++ ) {
        if ( aiIndex[i] != -1 && aiIndex.wrap(i+1) != -1 ) {
            if ( aiIndex.wrap(i+2) != -1 ) {
                bFoundContiguous = TRUE;
                const int iNextIndex = (aiIndex[i] - 1 + in_aopVs.num()) % in_aopVs.num();
                const int iNextNextIndex = (aiIndex.wrap(i+1) - 1 + in_aopVs.num()) % in_aopVs.num();
                if ( aiIndex.wrap(i+1) == iNextIndex && aiIndex.wrap(i+2) == iNextNextIndex ) {
                    bFoundOrder = TRUE;
                }
            } else {
                const int iNextIndex = (aiIndex[i] - 1 + in_aopVs.num()) % in_aopVs.num();
                if ( aiIndex.wrap(i+1) != iNextIndex ) {
                    return FALSE;
                }
            }
        } else if ( aiIndex[i] != -1 && aiIndex.wrap(i+1) == -1  ) {
            if ( bFoundE1 == TRUE )
                return FALSE;
            bFoundE1 = TRUE;
        } else if ( aiIndex[i] == -1 && aiIndex.wrap(i-1) != -1 ) {
            if ( bFoundE2 == TRUE )
                return FALSE;
            bFoundE2 = TRUE;
        }
    }

    if ( bFoundContiguous == TRUE && bFoundOrder == TRUE )
        return TRUE;

    if ( bFoundContiguous == TRUE && bFoundOrder == FALSE )
        return FALSE;

    ASSERT( bFoundE1 == TRUE && bFoundE2 == TRUE );

    return TRUE;    
}

pair<int,int> PMeshLite::ExtremePointsDistance( const boost::dynamic_bitset<> &in_abVs ) const
{
    double dDistMax = 0.0;
    pair<int,int> pairBest(-1,-1);
    for ( int i = in_abVs.find_first(); i != -1; i = in_abVs.find_next(i) ) {
        const Vertex v1 = VertexFromIndexId(i);
        
        for ( int j = in_abVs.find_next(i); j != -1; j = in_abVs.find_next(j) ) {
            const Vertex v2 = VertexFromIndexId(j);
            
            if ( ::Length( v1->GetLoc() - v2->GetLoc() ) > dDistMax ) {
                dDistMax = ::Length( v1->GetLoc() - v2->GetLoc() );
                pairBest.first = i;
                pairBest.second = j;
            }
        }
    }
    
    return pairBest;
}


pair<int,int> PMeshLite::ExtremePointsXYZ( const boost::dynamic_bitset<> &in_abVs ) const
{
    double dDistMax = 0.0;
    pair<int,int> pairBest(-1,-1);
    for ( int i = in_abVs.find_first(); i != -1; i = in_abVs.find_next(i) ) {
        const Vertex v1 = VertexFromIndexId(i);
        
        for ( int j = in_abVs.find_next(i); j != -1; i = in_abVs.find_next(j) ) {
            const Vertex v2 = VertexFromIndexId(j);
            
            const R3Vec vec = v2->GetLoc() - v1->GetLoc();
            const double dDist = WINmax( WINmax(vec[0], vec[1]), vec[2] );
            if ( dDist > dDistMax ) {
                dDistMax = dDist;
                pairBest.first = i;
                pairBest.second = j;
            }
        }
    }
    
    return pairBest;
}


bool PMeshLite::GrowDiskByDijkstra(  const Face &in_face,
                          const int targetFsInDisk,
                          boost::dynamic_bitset<> &out_abFsInDisk,
                          Array<Vertex> & out_avBdry, 
                          Array<Edge>   & out_aeBdry ) const
{    
    out_abFsInDisk.resize( NumFaces() );
    out_abFsInDisk.reset();
    out_abFsInDisk.set( in_face->IndexId() );

    out_avBdry.need(0);
    out_aeBdry.need(0);
    out_avBdry = FaceVertices( in_face );
    out_aeBdry = FaceEdges( in_face );
    CheckBoundary(out_avBdry,out_aeBdry);
    
    Array<int> wedgesEaten(0);
    // initialize the priority queue
    BHPqueue facesInQueue( 0 );

    ForFaceFace( Mesh(), in_face, fNext){
        double dist = Length(GetFaceCentroid(fNext) - GetFaceCentroid(in_face));

        ASSERT ( !out_abFsInDisk[ fNext->IndexId() ] );
        facesInQueue.enterUnsorted((Univ) fNext, dist );
    }EndFor;  
    facesInQueue.sort();
    
    // do dijkstra's
    while(!facesInQueue.empty() && (int) out_abFsInDisk.count() <  targetFsInDisk) {
        
        const double dClosestDist = facesInQueue.minpriority();
        const Face fClosest = (Face)facesInQueue.removemin();
        const int fClosestId = fClosest->IndexId();

        //skip if face already added
        if(out_abFsInDisk[fClosestId])
            continue;

        int facesAdded = 0;
        if ( OkayToAdd( fClosest, out_avBdry ) ){
            wedgesEaten.need(0);
            //do add and update data
            facesAdded = GrowDiskByFace( fClosest, out_abFsInDisk, out_avBdry, out_aeBdry, wedgesEaten);   
        }

        if(facesAdded > 0){
            ASSERT(out_abFsInDisk[fClosestId]);
            CheckBoundary( out_avBdry, out_aeBdry );        
            
            ForFaceFace( Mesh(), fClosest, fNext){                
                const int fNextId = fNext->IndexId();
            
                if ( out_abFsInDisk[ fNextId ] )
                    continue;

                double dNextDist = dClosestDist + Length(GetFaceCentroid(fNext) - GetFaceCentroid(fClosest));
                if(facesInQueue.contains((Univ)fNext)){
                    if(facesInQueue.retrieve((Univ)fNext) > dNextDist)
                        facesInQueue.update((Univ)fNext, dNextDist);
                }
                else
                    facesInQueue.enter((Univ)fNext, dNextDist);

            }EndFor;
            if(wedgesEaten.num() > 0){
                for(int iW = 0; iW < wedgesEaten.num(); iW++){
                    Face curWedge = FaceFromIndexId(wedgesEaten[iW]);
                    ForFaceFace( Mesh(), curWedge, fNext){
                        const int fNextId = fNext->IndexId();
            
                        if ( out_abFsInDisk[ fNextId ] )
                            continue;

                        double dNextDist = dClosestDist + Length(GetFaceCentroid(fNext) - GetFaceCentroid(curWedge));
                        if(facesInQueue.contains((Univ)fNext)){
                            if(facesInQueue.retrieve((Univ)fNext) > dNextDist)
                                facesInQueue.update((Univ)fNext, dNextDist);
                        }
                        else
                            facesInQueue.enter((Univ)fNext, dNextDist);

                    }EndFor;
                }
            }
            bool bTrace = FALSE;
            
            if ( bTrace && out_abFsInDisk.count() % 500 == 0) {
                UTILSDotArray dots;
                for ( int iV = 0; iV < out_avBdry.num(); iV++ ) 
                    dots.Add( out_avBdry[iV]->GetLoc(), UTILSColor::GREY );

                for ( unsigned int iF = 0; iF < out_abFsInDisk.size(); iF++ ) {
                    if(out_abFsInDisk[iF])                            
                        if(iF == in_face->IndexId())
                            dots.Add( GetFaceCentroid(in_face), UTILSColor::BLACK );
                        else if(iF == fClosest->IndexId())
                            dots.Add( GetFaceCentroid(fClosest), UTILSColor::YELLOW );                        
                        else
                            dots.Add( GetFaceCentroid(FaceFromIndexId(iF)), UTILSColor::RED );                        
                    else {
                        if(facesInQueue.contains((Univ)FaceFromIndexId(iF)))
                            dots.Add( GetFaceCentroid(FaceFromIndexId(iF)), UTILSColor::PURPLE );                            
                    }
                }
                dots.Write(WINDataHome("test/grow_disk.txt"));
            }

        }
        else 
            ASSERT(!out_abFsInDisk[fClosestId]);
    }
    return true;
}


void PMeshLite::MakeFlattenedMesh( const Array< std::pair<Vertex,R2Pt> > &in_aptVLoc, PMeshLite &out_mesh ) const
{
    out_mesh.Clear();
    
    Array<Vertex> avNew( in_aptVLoc.num() );
    Array<int> aiMap( NumVertices() );
    aiMap.fill(-1);
    
    for ( int i = 0; i < in_aptVLoc.num(); i++ ) {
        avNew[i] = out_mesh.AddVertex( R3Pt( in_aptVLoc[i].second[0], in_aptVLoc[i].second[1], 0.0 ) );
        aiMap[ in_aptVLoc[i].first->IndexId() ] = i;
    }

    Array<Vertex> avF(3);
    ForMeshFace( Mesh(), f ) {
        avF.need(0);
        bool bFoundAll = true;
        ForFaceVertex( Mesh(), f, v ) {
            if ( aiMap[ v->IndexId() ] == -1 ) {
                bFoundAll = false;
                break;
            } else {
                avF += avNew[ aiMap[ v->IndexId() ] ];
            }
        }EndFor;
        if ( bFoundAll == true ) {
            out_mesh.AddFace( avF );
        }
    }EndFor;
    
    out_mesh.Compute_normals();
}

