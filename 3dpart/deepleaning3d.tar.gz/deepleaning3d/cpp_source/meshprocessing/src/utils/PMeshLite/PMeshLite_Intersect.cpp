#include "StdAfx.H"

#include <utils/Pm_MeshLite.H>
#include <utils/Mesh_PolygonSpatial.H>
#include <utils/R3_Plane.H>

WINbool PMeshLite::IsOkToAdd( const Array<Vertex> &in_avs )
{
    if ( !legalCreateFace(in_avs) )
        return FALSE;
    return TRUE;
}


void PMeshLite::Compute_normals( const Array<Vertex> &in_aopVs, const Array<Face> &in_aopFs )
{
    Array<Vertex> aopV;
    Array<double> adWeight;
    Array<Face> aopFaces;

    const double dAng90 = cos( M_PI / 2.0 );
    for (int i = 0; i < in_aopFs.num(); i++) {
        vertices( in_aopFs[i], aopV );
        const R3Vec v1v2 = UnitSafe( aopV[0]->GetLoc() - aopV[1]->GetLoc() );
        const R3Vec v2v3 = UnitSafe( aopV[1]->GetLoc() - aopV[2]->GetLoc() );
        const R3Vec v3v1 = UnitSafe( aopV[2]->GetLoc() - aopV[0]->GetLoc() );
        const double dDot1 = fabs( Dot( v3v1, v1v2 ) - dAng90 );
        const double dDot2 = fabs( Dot( v1v2, v2v3 ) - dAng90 );
        const double dDot3 = fabs( Dot( v2v3, v3v1 ) - dAng90 );

        if ( dDot1 < dDot2 && dDot1 < dDot3 ) {
            in_aopFs[i]->SetNorm( UnitSafe( Cross( v1v2, -v3v1 ) ) );
        } else if ( dDot1 < dDot3 ) {
            in_aopFs[i]->SetNorm( UnitSafe( Cross( v2v3, -v1v2 ) ) );
        } else {
            in_aopFs[i]->SetNorm( UnitSafe( Cross( v3v1, -v2v3 ) ) );
        }
    }

    for (FORINT i = 0; i < in_aopVs.num(); i++) {
        R3Vec vec(0,0,0);
        double dSum = 0.0;
        
        aopFaces = VertexFaces( in_aopVs[i] );
        adWeight.need( aopFaces.num() );
        for (int j = 0; j < aopFaces.num(); j++) {
            adWeight[j] = Length( aopFaces[j]->GetNorm() );
            dSum += adWeight[j];
        } 
        if ( RNIsZero( dSum ) ) {
            in_aopVs[i]->SetNorm( R3Vec(0,1,0 ));
        } else {
            for (int j = 0; j < aopFaces.num(); j++) {
                vec += aopFaces[j]->GetNorm() * adWeight[j];
                //vec += aopFaces[j]->GetNorm() * (1.0 / (double) adWeight.num() );
            } 
            in_aopVs[i]->SetNorm( UnitSafe( vec ) );
        }
    }

    m_bHasChanged = FALSE;
}

void PMeshLite::Compute_normals( )
{
    Array<Face> aopFaces;
    AllMeshFaces( aopFaces );

    Array<Vertex> aopVerts;
    AllMeshVertices( aopVerts );

    Compute_normals( aopVerts, aopFaces );
}


void PMeshLite::Compute_face_normals( )
{
    Array<Face> aopFaces;
    AllMeshFaces( aopFaces );

    Array<Vertex> aopVerts;

    Compute_normals( aopVerts, aopFaces );
}





PMeshLite &PMeshLite::operator=(const PMeshLite &in_oPick)
{
    Clear();

    copy( in_oPick );
    m_bHasChanged = TRUE;

    return *this;
}

R3Pt PMeshLite::GetCenter( R3Pt &out_ptScale ) const
{
	R3Pt ptMin(1e30, 1e30, 1e30);
	R3Pt ptMax(-1e30, -1e30, -1e30);

	ForMeshVertex( *this, v ) {
		const R3Pt &p = point(v);
		for (int j = 0; j < 3; j++) {
			ptMin[j] = WINmin(ptMin[j], (double) p[j]);
			ptMax[j] = WINmax(ptMax[j], (double) p[j]);
		}
	} EndFor;

	R3Pt ptCenter;
	for (int j = 0; j < 3; j++) {
		out_ptScale[j] = ptMax[j] - ptMin[j];
        ptCenter[j] = (RNIsZero(out_ptScale[j]) ? 0.0 : (0.5 * (ptMax[j] + ptMin[j])) );
	}
	return ptCenter;
}

void PMeshLite::Flip()
{
    Array< Array<Vertex> > aaFVs;
    Array< Face >          aF;
    ForMeshFace( *this, f ) {
        aaFVs.add(1);
        vertices(f, aaFVs.last());
        aaFVs.last().reverse();
        aF += f;
    }EndFor;

    for (int i = 0; i < aF.num(); i++)
        RemoveFace( aF[i] );

    Array< Vertex > aVs;
    for ( FORINT i = 0; i < aaFVs.num(); i++ ) {
        aVs.need( aaFVs[i].num() );
        for (int j = 0; j < aVs.num(); j++)
            aVs[j] = aaFVs[i][j];

        AddFace( aVs );
    }
}


void
PMeshLite::Contours( const R3Vec &in_vecPlaneNormal,
                     double       in_dStartOffset,
                     double       in_dSpacing,
                     Array< Array< std::pair<Edge, double> > >  &out_aaRings ) const
{ 
    const R3Vec vecNorm( UnitSafe( in_vecPlaneNormal ) );

    out_aaRings.need(0);

    R3Pt ptCenter, ptScale;    
    Array<R3Pt> aptRotated( NumVertices() );
    
    ptCenter = GetCenter( ptScale );
    
    R3Matrix mat;
    R3Matrix::MatrixVecToVec( mat, vecNorm, R3Vec(0,0,1) );
    const R4Matrix matTrans = (R4Matrix) mat * R4Matrix::Translation( R3Pt(0,0,0) - ptCenter );

    ASSERT( ApproxEqual( mat * vecNorm, R3Vec(0,0,1) ) );
    
    // Line up the mesh so the desired axis is the z-axis
    double dZMin = 1e30, dZMax = -1e30;
    ForMeshVertex( Mesh(), v ) {
        aptRotated[ v->IndexId() ] = matTrans * v->GetLoc();
        dZMin = WINmin( aptRotated[ v->IndexId() ][2], dZMin );
        dZMax = WINmax( aptRotated[ v->IndexId() ][2], dZMax );
    }EndFor;
    
    // Starting slice
    const double dZStart = in_dSpacing * ( (int) (dZMin / in_dSpacing) ) + in_dStartOffset;

    // jiggle any points that lie exactly on one of the contour lines
    const double dEps = 1e-6 * in_dSpacing * ( ptScale[0] + ptScale[1] + ptScale[2] ) / 3.0;
    for ( int i = 0; i < aptRotated.num(); i++ ) {
        const int iSlice = (int) ( aptRotated[i][2] - dZStart ) / in_dSpacing;
        const double dRemainder = ( aptRotated[i][2] - dZStart ) - iSlice * in_dSpacing;
        if ( fabs(dRemainder) < dEps ) {
            aptRotated[i][2] += dEps - dRemainder;
        }
    }

    double dZ = dZStart;

    boost::dynamic_bitset<> abEdgeCross( NumEdges() ), abBoundary( NumEdges() ), abStart(NumEdges());
    Array<double> adCross( NumEdges() );
    Array<Edge> aeMap( NumEdges() );

    // Always start a contour at a boundary, if there is one
    ForMeshEdge( Mesh(), e ) {
        if ( IsBoundary(e) ) {
            abBoundary.set(e->IndexId());
        } else {
            abBoundary.reset(e->IndexId());
        }
        aeMap[ e->IndexId() ] = e;
    }EndFor;
    while ( dZ <= dZMax ) {
        // Find all edges that cross the current slice line
        abEdgeCross.reset();
        
        ForMeshEdge( Mesh(), e ) {
            const Vertex &v1 = EdgeVertex1(e);
            const Vertex &v2 = EdgeVertex2(e);
            const R3Pt &p1 = v1->GetLoc();
            const R3Pt &p2 = v2->GetLoc();

            if ( (dZ - p1[2]) * (dZ - p2[2]) < 0.0 ) {
                abEdgeCross.set( e->IndexId() );
                adCross[ e->IndexId() ] = (dZ - p1[2]) / (p2[2] - p1[2]);
            }
        } EndFor;
        
        // Now stitch together
        while ( abEdgeCross.count() ) {
            abStart = abEdgeCross & abBoundary;
            const int iStart = abStart.count() ? abStart.find_first() : abEdgeCross.find_first();
            Edge eCur = aeMap[iStart];
            
            out_aaRings.add(1);
            out_aaRings.last().need(0);
            while ( eCur != NULL ) {
                out_aaRings.last() += std::pair< Edge, double >( eCur, adCross[eCur->IndexId()] );
                abEdgeCross.reset( eCur->IndexId() );

                const Face f1 = EdgeFace1(eCur);
                const Face f2 = EdgeFace2(eCur);
                eCur = NULL;
                if ( f1 ) {
                    ForFaceEdge( Mesh(), f1, e ) {
                        if ( abEdgeCross[e->IndexId()] ) {
                            eCur = e;
                            break;
                        }
                    }EndFor;
                }
                if ( eCur == NULL && f2 ) {
                    ForFaceEdge( Mesh(), f2, e ) {
                        if ( abEdgeCross[e->IndexId()] ) {
                            eCur = e;
                            break;
                        }
                    }EndFor;
                }
            }
        }   
        
        dZ += in_dSpacing;
    }
}

void
PMeshLite::Contours( const R3Vec &in_vecPlaneNormal,
                    double       in_dStartOffset,
                    double       in_dSpacing,
                    Array<R3Pt>  &out_apt,
                    Array<R3Vec> &out_avec ) const
{ 
    Array< Array< std::pair< Edge, double > > > aaRings;
    Contours( in_vecPlaneNormal, in_dStartOffset, in_dSpacing, aaRings );
    
    out_apt.need(0);
    out_avec.need(0);
    for ( int i = 0; i < aaRings.num(); i++ ) {
        for ( int j = 0; j < aaRings[i].num(); j++ ) {
            const Vertex &v1 = EdgeVertex1( aaRings[i][j].first );
            const Vertex &v2 = EdgeVertex2( aaRings[i][j].first );
            out_apt += Lerp( v1->GetLoc(), v2->GetLoc(), aaRings[i][j].second );
            out_avec += UnitSafe( v1->GetNorm() * aaRings[i][j].second + v2->GetNorm() * (1.0 - aaRings[i][j].second ) );
        }
    }
}

void
PMeshLite::SlicingPlaneContour( const R3Plane &in_plane, Array<R3Pt>  &out_apt) const
{ 
	const R3Vec vecNorm( UnitSafe( in_plane.Normal() ) );

	out_apt.need(0);

	GMesh oMesh;
	ASSERT( ! RNIsZero( Length( vecNorm ) ) );

	R3Matrix mat;
	R3Matrix::MatrixVecToVec( mat, vecNorm, R3Vec(0,0,1) );

	// Line up the mesh so the desired axis is the z-axis
	oMesh.copy( *this );
	oMesh.transform( mat );

	R3Pt ptOnSlicePlane = in_plane.PtOnPlane();
	R3Pt ptOnRotatedPlane = mat * ptOnSlicePlane;

	// jiggle any points that lie exactly on the contour lines
	double dZ = ptOnRotatedPlane[2];
	ForMeshVertex( oMesh, v ) {
		R3Pt p = oMesh.point( v );
		if ( RNApproxEqual( p[2], dZ ) ) {
			p[2] += 0.00001;  // might want to scale this based on dimensions of mesh
			oMesh.setPoint( v, p );
		}
	} EndFor;

	// Find an edge that crosses the current slice line
	Edge currEdge = NULL;
	ForMeshEdge( oMesh, e ) {
		const Vertex &v1 = VertexFromIndexId( oMesh.vertex1( e )->IndexId() );
		const Vertex &v2 = VertexFromIndexId( oMesh.vertex2( e )->IndexId() );
		const R3Pt &p1 = oMesh.point( oMesh.vertex1( e ) );
		const R3Pt &p2 = oMesh.point( oMesh.vertex2( e ) );

		if ( dZ < p1[2] && dZ > p2[2] ) {
			out_apt += Lerp( v2->GetLoc(), v1->GetLoc(), (dZ - p2[2]) / (p1[2] - p2[2]) );
			currEdge = e;
			break;
		} else if ( dZ < p2[2] && dZ > p1[2] ) {
			out_apt += Lerp( v1->GetLoc(), v2->GetLoc(), (dZ - p1[2]) / (p2[2] - p1[2]) );
			currEdge = e;
			break;
		}
	} EndFor;

	if (currEdge != NULL) {		// if currEdge == NULL, we can stop, because the plane does not intersect the mesh
		Face currFace = EdgeFace1(currEdge);
		Face endFace = EdgeFace2(currEdge);
		Array<Edge> faceEdges;
		bool edgeUpdated;

		while ( currFace->Id()!= endFace->Id() ) {	//we want to march around the intersecting faces, until we get back where we began
			faceEdges.clearcompletely();
			faceEdges = FaceEdges(currFace);
			edgeUpdated = FALSE;

			for (int i=0; i<faceEdges.num(); i++) {
				if (faceEdges[i]->Id() != currEdge->Id()) {
					const Vertex &v1 = VertexFromIndexId( oMesh.vertex1( faceEdges[i] )->IndexId() );
					const Vertex &v2 = VertexFromIndexId( oMesh.vertex2( faceEdges[i] )->IndexId() );
					const R3Pt &p1 = oMesh.point( oMesh.vertex1( faceEdges[i] ) );
					const R3Pt &p2 = oMesh.point( oMesh.vertex2( faceEdges[i] ) );

					if ( dZ < p1[2] && dZ > p2[2] ) {	//we found the next intersection, update and break
						out_apt += Lerp( v2->GetLoc(), v1->GetLoc(), (dZ - p2[2]) / (p1[2] - p2[2]) );
						currEdge = faceEdges[i];
						if (EdgeFace1(currEdge)->Id() == currFace->Id()) {
							currFace = EdgeFace2(currEdge);
						}
						else {
							currFace = EdgeFace1(currEdge);
						}
						edgeUpdated = TRUE;
						break;
					} else if ( dZ < p2[2] && dZ > p1[2] ) {	//we found the next intersection, update and break
						out_apt += Lerp( v1->GetLoc(), v2->GetLoc(), (dZ - p1[2]) / (p2[2] - p1[2]) );
						currEdge = faceEdges[i];
						if (EdgeFace1(currEdge)->Id() == currFace->Id()) {
							currFace = EdgeFace2(currEdge);
						}
						else {
							currFace = EdgeFace1(currEdge);
						}
						edgeUpdated = TRUE;
						break;
					}
				} 		
			}
			
			if(!edgeUpdated) {
				cout << "Warning!  SlicingPlaneContour() aborted early.  Probably missing some contour points.\n";
				return;
			}
		}
	}

}

/**************
 * Constructor/destructors
 *   GMesh doesn't have anything special but BMesh does
 **************/

PMeshLite::PMeshLite() : 
m_colDefault( 0.8, 0.2, 0.5 )
{
}

void PMeshLite::VertexEdgeFace( Vertex         in_v,
                                Array<Edge > & out_aopEs,
                                Array<Face > & out_aopFs ) const
{
    out_aopEs.clearcompletely();
    out_aopFs.clearcompletely();

    ASSERT(isNice( in_v ) );

    out_aopEs += mostClwEdge( in_v );
    if ( out_aopEs[0] == NULL ) return;

    do {
        out_aopEs += ccwEdge( in_v, out_aopEs.last() );
    } while ( out_aopEs.last() && (out_aopEs.last() != out_aopEs[0]) );

    out_aopEs.sub(1);

    ForVertexCcwFace( *this, in_v, f ) {
        out_aopFs += f;
    } EndFor;

    WINbool bFound = FALSE;

    for ( int i = 0; i < out_aopFs.num(); i++) {
        int iE1 = -1, iE2 = -1, iE = 0;
        ForFaceEdge( *this, out_aopFs[0], e ) {
            if ( e == out_aopEs[i] ) {
                iE2 = iE;
            }
            if ( e == out_aopEs.wrap(i+1) ) {
                iE1 = iE;
            }
            iE++;
        } EndFor;
        if ( iE1 != -1 && iE2 != -1 ) {
            ASSERT( iE2 - iE1 == 1 || iE2 == 0 && iE1 == iE-1 );
            bFound = TRUE;
        }
    }
    ASSERT( bFound == TRUE );
}

Edge PMeshLite::EdgeFromFaces( Face in_f,  Face in_g ) const 
{
    Array<Edge> ae1 = FaceEdges(in_f);
    Array<Edge> ae2 = FaceEdges(in_g);
    Edge e;
    for (int i = 0; i < ae1.num(); i++) {
        for (int j = 0; j < ae2.num(); j++) {
            if (ae1[i]->IndexId() == ae2[j]->IndexId()) {
                e = ae1[i];
                break;
            }
        }
    }
    return e;
}


void PMeshLite::Transform( const R4Matrix & in_oFrame )
{
    transform(in_oFrame);
    Compute_normals();
}



