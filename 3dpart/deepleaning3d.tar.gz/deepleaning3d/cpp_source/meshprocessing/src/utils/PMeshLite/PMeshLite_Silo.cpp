#include "StdAfx.H"

#include <utils/Pm_MeshLite.H>



WINbool PMeshLite::IsSilho(const Edge & in_e, const R3Vec & in_lookVec) const
{
	Face face1 = EdgeFace1(in_e);
	Face face2 = EdgeFace2(in_e);

	if(face2 == NULL || face1 == NULL)
		return true;

	const R3Vec &norm1 = face1->GetNorm();
	const R3Vec &norm2 = face2->GetNorm();

	const double d2 = Dot(norm1, in_lookVec);
	const double d1 = Dot(norm2, in_lookVec);
	return (d1 >= 0 && d2 <= 0 || d1 <= 0 && d2 >= 0 );	
}


void PMeshLite::SilhouetteEdgesVertices(const R3Vec &in_lookVec, Array< Array<Vertex> > &o_aVertices, Array< Array<Edge> > &o_aEdges, Array < Array<int> > &o_adDist ) const
{
	Array< WINbool > visited;
	Array<Vertex> aVertices;
	AllMeshVertices(aVertices);
	Array<Vertex> nextFront, stack;
	Array< WINbool > amSilh;
	Array <Vertex> silVert;
	Array<Edge> aEdges;
	AllMeshEdges(aEdges);
	nextFront.need(0);
	visited.need(aVertices.num());
	int j,k;

	for(j = 0; j < aVertices.num(); j++)
		visited[j] = true;
	
	for(int i = 0; i < aEdges.num(); i++){
		if(IsSilho(aEdges[i], in_lookVec)) {
			amSilh+=true;
			if(!(silVert.contains(EdgeVertex1(aEdges[i]))))
				silVert+=EdgeVertex1(aEdges[i]);
			if(!(silVert.contains(EdgeVertex2(aEdges[i]))))
				silVert+=EdgeVertex2(aEdges[i]);
		}else{
			amSilh+=false;
		}
	}

	for(k = 0; k < silVert.num(); k++)
		visited[silVert[k]->IndexId()] = false;


	stack += silVert[0];

	Array <Edge> nearbyE;
	Vertex v;
	int iOffset = 0;
	int iIndex;
	int vId;
	o_adDist.add(1);
	o_aVertices.add(1);
	o_aEdges.add(1);
	visited[silVert[0]->IndexId()] = false;

	o_adDist[0] += 0;
	o_aVertices[0] += silVert[0];
	o_aEdges[0] += aEdges[0];
	while(amSilh.contains(true)) {
		// Start a loop
		while(stack.num() > 0) {
			const int depth = stack.num() - 1;
	
			WINbool deadEnd = true;

			nearbyE = VertexEdges(stack[depth]);

			for(k = 0; k < nearbyE.num(); k++) { // Search my neighbors
				iIndex = nearbyE[k]->IndexId();
				if(amSilh[iIndex]){
					o_aEdges[iOffset] += aEdges[iIndex];
					v = EdgeOppositeVertex(nearbyE[k], stack[depth]);
					vId = v->IndexId();
					if(!visited[vId]) {
						stack += v;
						deadEnd = false;
						o_adDist[iOffset] += (depth);
						o_aVertices[iOffset] += v;
						visited[vId] = false;
						amSilh[iIndex] = false;						
						break;
					}
				}
			}

			if(deadEnd)
				stack.sub(1); // Pop
		}
	

		iIndex = amSilh.index(true);
		if ( iIndex != -1 ) {
			iOffset++;
			o_adDist.add(1);
			o_aVertices.add(1);
			o_aEdges.add(1);
			v = EdgeVertex1(aEdges[iIndex]);
			
			// Look, Cindy, an assertion!  All by myself.  - Jim
			ASSERT(stack.num() == 0);

			stack += v;

			o_adDist[iOffset] += (0);
			o_aVertices[iOffset] += v;
			o_aEdges[iOffset] += aEdges[iIndex];
			visited[v->IndexId()] = false;
			amSilh[iIndex] = false;
		}
	}

}

