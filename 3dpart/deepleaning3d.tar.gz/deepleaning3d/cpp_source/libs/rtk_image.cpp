/******************************************************************************

  Robot Toolkit ++ (RTK++)

  Copyright (c) 2007-2013 Shuhui Bu <bushuhui@nwpu.edu.cn>
  http://www.adv-ci.com

  ----------------------------------------------------------------------------
  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU Affero General Public License as
  published by the Free Software Foundation, either version 3 of the
  License, or (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  GNU Affero General Public License for more details.

  You should have received a copy of the GNU Affero General Public License
  along with this program. If not, see <http://www.gnu.org/licenses/>.

*******************************************************************************/

// Note:
//      RTK_Image image buffer byte order: BGRA
//      Cairo format: CAIRO_FORMAT_ARGB32
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <cairo/cairo.h>            // Cario graphic libary

#include <jpeglib.h>                // jpeg lib

#include "rtk_debug.h"
#include "rtk_image.h"
#include "rtk_utils.h"

using namespace cv;

namespace rtk {

/******************************************************************************
 *
 *****************************************************************************/
struct rtk_image_dat {
    // cairo objs
    cairo_t             *cr;
    cairo_surface_t     *cr_s;

    // QImage objs
    QImage              *q_img;

    // SDL surface
    SDL_Surface         *sdl;
    uint8               *sdl_pixel;

    // initialize
    rtk_image_dat() {
        cr        = NULL;
        cr_s      = NULL;

        q_img     = NULL;

        sdl       = NULL;
        sdl_pixel = NULL;
    }

    ~rtk_image_dat() {
        cr        = NULL;
        cr_s      = NULL;

        q_img     = NULL;

        sdl       = NULL;
        sdl_pixel = NULL;
    }
};

/******************************************************************************
 *
 *****************************************************************************/
RTK_Image::RTK_Image()
{
    m_pri_data = NULL;

    m_iw = 0;
    m_ih = 0;

    m_jpeg_qual = 90;
}

RTK_Image::RTK_Image(int w, int h)
{
    m_jpeg_qual = 90;

    alloc(w, h);
}

RTK_Image::~RTK_Image()
{
    free();
}

int RTK_Image::width(void)
{
    return m_iw;
}

int RTK_Image::height(void)
{
    return m_ih;
}

// set/get image properties
int RTK_Image::set_size(int w, int h)
{
    return alloc(w, h);
}

int RTK_Image::get_size(int *w, int *h)
{
    *w = m_iw;
    *h = m_ih;
}

// get raw pixel
uint8* RTK_Image::get_bits(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data != NULL ) {
        p_dat = (rtk_image_dat*) m_pri_data;
        return cairo_image_surface_get_data(p_dat->cr_s);
    } else {
        dbg_pw("Image not exist");
        return NULL;
    }
}

int RTK_Image::create(int w, int h)
{
    return alloc(w, h);
}

// alloc/free
int RTK_Image::alloc(int w, int h)
{
    rtk_image_dat   *p_dat;
    uint8           *p_buf;
    uint32          rmask, gmask, bmask, amask;

    // check width & height
    if( w <= 0 || h <= 0 ) {
        dbg_pe("input image size not correct (%d, %d)", w, h);
        return -1;
    }

    // check cairo surface exist
    if( m_pri_data != NULL ) {
        if( m_iw != w && m_ih != h )
            free();
        else {
            clear();
            return 0;
        }
    }

    // create cairo image
    p_dat = new rtk_image_dat();
    m_pri_data = p_dat;

    // set image size
    m_iw = w;
    m_ih = h;

    // create image surface BGRA byte order
    p_dat->cr_s = cairo_image_surface_create(CAIRO_FORMAT_ARGB32,
                                             m_iw, m_ih);
    p_buf = cairo_image_surface_get_data(p_dat->cr_s);

    // create cairo object
    p_dat->cr = cairo_create(p_dat->cr_s);

    // create QImage
    p_dat->q_img = new QImage(p_buf, m_iw, m_ih, QImage::Format_ARGB32);

    // create SDL surface (FIXME: just for intel CPU)
    rmask = 0x00ff0000;
    gmask = 0x0000ff00;
    bmask = 0x000000ff;
    amask = 0x00000000;

    p_dat->sdl = SDL_CreateRGBSurface(
                SDL_SWSURFACE,
                m_iw, m_ih,
                32,
                rmask, gmask, bmask, amask);
    if( p_dat->sdl == NULL ) {
        dbg_pe("SDL_CreateRGBSurface failed!\n");
        return -1;
    }

    // backup old pixel buffer, and share same buffer of cairo
    p_dat->sdl_pixel = (uint8*) p_dat->sdl->pixels;
    p_dat->sdl->pixels = p_buf;

    return 0;
}

int RTK_Image::free(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data != NULL ) {
        p_dat = (rtk_image_dat *) m_pri_data;

        // free cairo image objs
        cairo_surface_destroy(p_dat->cr_s);
        cairo_destroy(p_dat->cr);

        // free QImage
        delete p_dat->q_img;

        // free SDL_Surface
        p_dat->sdl->pixels = p_dat->sdl_pixel;
        SDL_FreeSurface(p_dat->sdl);

        delete p_dat;
    }

    m_pri_data = NULL;
    m_iw = 0;
    m_ih = 0;

    return 0;
}

int RTK_Image::clear(void)
{
    RTK_Color   c;

    c.r = 0;
    c.g = 0;
    c.b = 0;
    c.a = 0xFF;

    return clear(c);
}

int RTK_Image::clear(RTK_Color &c)
{
#if 1
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_save(p_dat->cr);

    cairo_set_source_rgba(
                p_dat->cr,
                c.r*1.0/255.0, c.g*1.0/255.0, c.b*1.0/255.0, c.a*1.0/255.0);
    cairo_set_operator(p_dat->cr, CAIRO_OPERATOR_SOURCE);
    cairo_paint(p_dat->cr);

    cairo_restore(p_dat->cr);

    return 0;
#endif

#if 0
    uint8   *p;
    int     i;

    p = get_bits();
    if( p == NULL )
        return -1;

    for(i=0; i<m_iw*m_ih; i++) {
        p[i*4+0] = c.b;
        p[i*4+1] = c.g;
        p[i*4+2] = c.r;
        p[i*4+3] = c.a;
    }

    return 0;
#endif
}

// set drawing properties
int RTK_Image::set_pen_width(double pw)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_set_line_width(p_dat->cr, pw);
    return 0;
}

int RTK_Image::set_pen_color(RTK_Color &pc)
{
    rtk_image_dat   *p_dat;
    double          r, g, b, a;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    r = pc.r*1.0/255;
    g = pc.g*1.0/255;
    b = pc.b*1.0/255;
    a = pc.a*1.0/255;
    cairo_set_source_rgba(p_dat->cr, r, g, b, a);

    return 0;
}

int RTK_Image::set_font(const char *fname)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_select_font_face(p_dat->cr, fname,
                           CAIRO_FONT_SLANT_NORMAL,
                           CAIRO_FONT_WEIGHT_NORMAL);

    return 0;
}

int RTK_Image::set_font_size(double s)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_set_font_size(p_dat->cr, s);

    return 0;
}

int RTK_Image::set_font_color(RTK_Color &fc)
{
    return set_pen_color(fc);
}

int RTK_Image::translate(double tx, double ty)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_translate(p_dat->cr, tx, ty);

    return 0;
}

int RTK_Image::scale(double sx, double sy)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_scale(p_dat->cr, sx, sy);

    return 0;
}

int RTK_Image::rotate(double ang)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_rotate(p_dat->cr, ang);

    return 0;
}

// drawing functions
int RTK_Image::move_to(double x, double y)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_move_to(p_dat->cr, x, y);

    return 0;
}

int RTK_Image::line_to(double x, double y)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_line_to(p_dat->cr, x, y);

    return 0;
}

int RTK_Image::draw_line(double x1, double y1, double x2, double y2)
{
    move_to(x1, y1);
    line_to(x2, y2);

    return 0;
}

int RTK_Image::draw_rect(double x1, double y1, double x2, double y2)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_move_to(p_dat->cr, x1, y1);
    cairo_line_to(p_dat->cr, x2, y1);
    cairo_line_to(p_dat->cr, x2, y2);
    cairo_line_to(p_dat->cr, x1, y2);
    cairo_line_to(p_dat->cr, x1, y1);

    return 0;
}

int RTK_Image::draw_circle(double x, double y, double r)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_arc(p_dat->cr, x, y, r, 0, 2*M_PI);

    return 0;
}

int RTK_Image::draw_ellipse(double x, double y, double w, double h, double ang)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_save(p_dat->cr);
    cairo_translate(p_dat->cr, x, y);
    cairo_rotate(p_dat->cr, ang);
    cairo_scale(p_dat->cr, w/2.0, h/2.0);
    cairo_arc(p_dat->cr, 0, 0, 1.0, 0, 2*M_PI);
    cairo_restore(p_dat->cr);

    return 0;
}

int RTK_Image::close_path(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_close_path(p_dat->cr);

    return 0;
}

int RTK_Image::stroke(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_stroke(p_dat->cr);

    return 0;
}

int RTK_Image::fill(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_fill(p_dat->cr);

    return 0;
}

int RTK_Image::fill_preserve(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_fill_preserve(p_dat->cr);

    return 0;
}

int RTK_Image::draw_text(double x, double y, const char *s, int xalign, int yalign, double ang)
{
    rtk_image_dat           *p_dat;
    cairo_text_extents_t    te;
    double                  nx, ny, dy;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_text_extents(p_dat->cr, s, &te);

#if 0
    printf("te:\n");
    printf("    width     = %f\n", te.width);
    printf("    height    = %f\n", te.height);
    printf("    x_advance = %f\n", te.x_advance);
    printf("    y_advance = %f\n", te.y_advance);
    printf("    x_bearing = %f\n", te.x_bearing);
    printf("    y_bearing = %f\n", te.y_bearing);
#endif

    if( xalign < 0 ) {
        nx = x - te.x_bearing;
    } else if ( xalign == 0 ) {
        nx = x - te.width/2.0 - te.x_bearing;
    } else {
        nx = x - te.width - te.x_bearing;
    }

    dy = te.height + te.y_bearing;
    if( yalign < 0 ) {
        ny = y + te.height - dy;
    } else if ( yalign == 0 ) {
        ny = y + te.height/2.0  - dy;
    } else {
        ny = y  - dy;
    }

    // draw text
    cairo_matrix_t c_mat;

    cairo_get_matrix(p_dat->cr, &c_mat);

    cairo_translate(p_dat->cr, x, y);
    cairo_rotate(p_dat->cr, ang);
    cairo_move_to(p_dat->cr, nx-x, ny-y);

    cairo_show_text(p_dat->cr, s);

    cairo_set_matrix(p_dat->cr, &c_mat);

    return 0;
}


// load/save image file
int RTK_Image::save(const char *fname)
{
    string      fn_ext;
    StringArray sa;

    // get ext name
    sa = path_splitext(fname);

    if( sa.size () < 2 ) {
        dbg_pe("input file name wrong! fname: %s\n", fname);
        return -1;
    }

    fn_ext = sa[1];
    str_tolower(fn_ext);

    // save image
    if( fn_ext == ".png" )
        return save_png(fname);
    else if( fn_ext == ".bmp" )
        return save_bmp(fname);
    else if( fn_ext == ".jpg" || fn_ext == "jpeg" )
        return save_jpg(fname);
    else {
        dbg_pe("Unsupported file format! fname: %s, extname: %s\n",
               fname, fn_ext.c_str());
        return -1;
    }
}

int RTK_Image::load(const char *fname)
{
    string      fn_ext;
    StringArray sa;

    // get ext name
    sa = path_splitext(fname);

    if( sa.size () < 2 ) {
        dbg_pe("input file name wrong! fname: %s\n", fname);
        return -1;
    }

    // free old data
    free();

    fn_ext = sa[1];
    str_tolower(fn_ext);

    if( fn_ext == ".png" )
        return load_png(fname);
    else if( fn_ext == ".bmp" )
        return load_bmp(fname);
    else if( fn_ext == ".jpg" || fn_ext == ".jpeg" )
        return load_jpg(fname);
    else {
        dbg_pe("Unsupported file format! fname: %s, extname: %s\n",
               fname, fn_ext.c_str());
        return -1;
    }
}

int RTK_Image::save_png(const char *fname)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data == NULL ) return -1;

    p_dat = (rtk_image_dat*) m_pri_data;

    cairo_surface_write_to_png(p_dat->cr_s, fname);

    return 0;
}

int RTK_Image::load_png(const char *fname)
{
    cairo_surface_t *img;
    int             w, h, stride;
    cairo_format_t  fmt;

    uint8           *ps, *pd;

    // load png image
    img = cairo_image_surface_create_from_png(fname);
    w = cairo_image_surface_get_width(img);
    h = cairo_image_surface_get_height(img);
    stride = cairo_image_surface_get_stride(img);
    fmt = cairo_image_surface_get_format(img);

    // check input image format
    if( ! (fmt == CAIRO_FORMAT_ARGB32 || fmt == CAIRO_FORMAT_RGB24) ) {
        dbg_pe("input png format not supported! fname: %s, fmt: %d\n",
               fname, fmt);
        return -1;
    }

    // alloc new RGBA image if not exist/matched
    if( m_pri_data == NULL || w != m_iw || h != m_ih )
        alloc(w, h);

    // copy image data
    ps = cairo_image_surface_get_data(img);
    pd = get_bits();

    // FIXME: only support PNG RBG 4 bytes
    memcpy(pd, ps, w*h*4);

    // free load image
    cairo_surface_destroy(img);

    return 0;
}


int RTK_Image::save_bmp(const char *fname)
{
    int     i, j, ji;
    int     bpp_s,   bpp_d;
    int     l_bpp_s, l_bpp_d;
    uint8   *ps, *pd;
    FILE    *fp;

    unsigned char bmp_header[] =
    {
        66,77,54,16,14,0,0,0,0,0,54,0,0,0,40,0,0,0,128,2,0,0,224,1,0,0,
        1,0,24,0,0,0,0,0,0,16,14,0,18,11,0,0,18,11,0,0,0,0,0,0,0,0,0,0
    };

    // check image exist
    if( m_pri_data == NULL )
        return -1;

    // set file header
    bmp_header[18] = m_iw%256;
    bmp_header[19] = m_iw/256;
    bmp_header[22] = m_ih%256;
    bmp_header[23] = m_ih/256;

    // set bpp, l_bpp
    bpp_s = 4;
    bpp_d = 3;
    l_bpp_s = m_iw*bpp_s;
    l_bpp_d = m_iw*bpp_d;

    if( l_bpp_d % 4 != 0 )
        l_bpp_d = (l_bpp_d/4+1)*4;      // make sure bmp line bpp is 4 times

    // cairo image buffer
    ps = get_bits();
    if( ps == NULL ) return -1;

    // output image buffer
    pd = new uint8[m_ih*l_bpp_d];

    // copy image buffer
    for(j=0; j<m_ih; j++) {
        ji = m_ih-1 - j;
        for(i=0; i<m_iw; i++) {
            pd[ji*l_bpp_d + i*bpp_d + 0] = ps[j*l_bpp_s + i*bpp_s + 0];
            pd[ji*l_bpp_d + i*bpp_d + 1] = ps[j*l_bpp_s + i*bpp_s + 1];
            pd[ji*l_bpp_d + i*bpp_d + 2] = ps[j*l_bpp_s + i*bpp_s + 2];
        }
    }

    // write to file
    fp = fopen(fname, "wb");
    ASSERT(fp);

    fwrite(bmp_header, 54, 1, fp);
    fwrite(pd, m_ih*l_bpp_d, 1, fp);
    fclose(fp);

    // free buffer
    delete pd;

    return 0;
}

int RTK_Image::load_bmp(const char *fname)
{
    int     w, h;
    int     i, j, ji;
    int     bpp_s,   bpp_d;
    int     l_bpp_s, l_bpp_d;
    int     ret;
    uint8   *ps, *pd;
    FILE    *fp;

    unsigned char bmp_header[] =
    {
        66,77,54,16,14,0,0,0,0,0,54,0,0,0,40,0,0,0,128,2,0,0,224,1,0,0,
        1,0,24,0,0,0,0,0,0,16,14,0,18,11,0,0,18,11,0,0,0,0,0,0,0,0,0,0
    };

    // read file
    fp = fopen(fname, "rb");
    ASSERT(fp);

    ret = fread(bmp_header, 54, 1, fp);
    w = bmp_header[19]*256 + bmp_header[18];
    h = bmp_header[23]*256 + bmp_header[22];

    // set bpp, l_bpp
    bpp_s = 3;
    bpp_d = 4;
    l_bpp_s = w*bpp_s;
    if( l_bpp_s % 4 != 0 )
        l_bpp_s = (l_bpp_s/4+1)*4;      // make sure bmp line bpp is 4 times
    l_bpp_d = w*bpp_d;

    // read image data
    ps = new uint8[h*l_bpp_s];
    ret = fread(ps, h*l_bpp_s, 1, fp);
    fclose(fp);

    // create new image buffer if necessary
    if( m_pri_data == NULL || w != m_iw || h != m_ih )
        alloc(w, h);

    // get image buffer
    pd = get_bits();

    // copy image buffer
    for(j=0; j<h; j++) {
        ji = h-1 - j;
        for(i=0; i<w; i++) {
            pd[ji*l_bpp_d + i*bpp_d + 0] = ps[j*l_bpp_s + i*bpp_s + 0];
            pd[ji*l_bpp_d + i*bpp_d + 1] = ps[j*l_bpp_s + i*bpp_s + 1];
            pd[ji*l_bpp_d + i*bpp_d + 2] = ps[j*l_bpp_s + i*bpp_s + 2];
            pd[ji*l_bpp_d + i*bpp_d + 3] = 0xFF;
        }
    }

    // free temp buffer
    delete ps;

    return 0;
}

int RTK_Image::save_jpg(const char *fname)
{
    int     i, j, ji;
    int     bpp_s,   bpp_d;
    int     l_bpp_s, l_bpp_d;
    uint8   *ps, *pd;
    FILE    *fp;

    struct jpeg_compress_struct cinfo;
    struct jpeg_error_mgr jerr;
    JSAMPROW row_pointer[1];

    // check image exist
    if( m_pri_data == NULL )
        return -1;

    // set image bpp/l_bpp
    bpp_s = 4;
    bpp_d = 3;
    l_bpp_s = m_iw*bpp_s;
    l_bpp_d = m_iw*bpp_d;

    // source image buffer
    ps = get_bits();
    if( ps == NULL ) return -1;

    // dest image buffer
    pd = new uint8[m_ih*l_bpp_d];

    // copy image data
    for(j=0; j<m_ih; j++) {
        ji = j;
        for(i=0; i<m_iw; i++) {
            pd[ji*l_bpp_d + i*bpp_d + 0] = ps[j*l_bpp_s + i*bpp_s + 2];
            pd[ji*l_bpp_d + i*bpp_d + 1] = ps[j*l_bpp_s + i*bpp_s + 1];
            pd[ji*l_bpp_d + i*bpp_d + 2] = ps[j*l_bpp_s + i*bpp_s + 0];
        }
    }

    // begin jpeg compress
    fp = fopen(fname, "wb");
    ASSERT(fp);

    cinfo.err = jpeg_std_error( &jerr );
    jpeg_create_compress(&cinfo);
    jpeg_stdio_dest(&cinfo, fp);

    cinfo.image_width = m_iw;
    cinfo.image_height = m_ih;
    cinfo.input_components = 3;
    cinfo.in_color_space = JCS_RGB;
    jpeg_set_defaults( &cinfo );
    jpeg_set_quality (&cinfo, m_jpeg_qual, true);

    jpeg_start_compress( &cinfo, TRUE );
    while( cinfo.next_scanline < cinfo.image_height ) {
        row_pointer[0] = &pd[ cinfo.next_scanline * cinfo.image_width * cinfo.input_components];
        jpeg_write_scanlines( &cinfo, row_pointer, 1 );
    }

    jpeg_finish_compress( &cinfo );
    jpeg_destroy_compress( &cinfo );

    fclose( fp );

    // free buffer
    delete pd;

    return 0;
}

int RTK_Image::load_jpg(const char *fname)
{
    int     i, j, ji;
    int     w, h;
    int     bpp_s,   bpp_d;
    int     l_bpp_s, l_bpp_d;
    uint8   *ps, *pd;
    FILE    *fp;
    int     ret = 0;

    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    JSAMPROW row_pointer[1];

    cinfo.err = jpeg_std_error( &jerr );
    jpeg_create_decompress(&cinfo);

    // open file
    fp = fopen(fname, "rb");
    ASSERT(fp);

    // read jpg header
    jpeg_stdio_src(&cinfo, fp);
    jpeg_read_header(&cinfo, TRUE);

    w = cinfo.image_width;
    h = cinfo.image_height;

    // set bpp
    bpp_s = cinfo.num_components;
    bpp_d = 4;
    l_bpp_s = w*bpp_s;
    l_bpp_d = w*bpp_d;

    // alloc image buffers if necessary
    if( m_pri_data == NULL || m_iw != w || m_ih != h )
        alloc(w, h);

    // get image buffer
    pd = get_bits();
    ps = new uint8[h*l_bpp_s];

    // begin jpeg decompress
    jpeg_start_decompress(&cinfo);

    while( cinfo.output_scanline < cinfo.output_height ) {
        row_pointer[0] = &ps[ cinfo.output_scanline * cinfo.image_width * cinfo.num_components];
        jpeg_read_scanlines(&cinfo, row_pointer, 1);
    }

    jpeg_finish_decompress( &cinfo );
    jpeg_destroy_decompress( &cinfo );

    fclose(fp);

    // copy image buffer
    if( cinfo.num_components == 3 ) {
        for(j=0; j<h; j++) {
            ji = j;
            for(i=0; i<w; i++) {
                pd[ji*l_bpp_d + i*bpp_d + 0] = ps[j*l_bpp_s + i*bpp_s + 2];
                pd[ji*l_bpp_d + i*bpp_d + 1] = ps[j*l_bpp_s + i*bpp_s + 1];
                pd[ji*l_bpp_d + i*bpp_d + 2] = ps[j*l_bpp_s + i*bpp_s + 0];
                pd[ji*l_bpp_d + i*bpp_d + 3] = 255;
            }
        }
    }
    else if( cinfo.num_components == 1 ) {
        for(j=0; j<h; j++) {
            ji = j;
            for(i=0; i<w; i++) {
                pd[ji*l_bpp_d + i*bpp_d + 0] = ps[j*l_bpp_s + i*bpp_s + 0];
                pd[ji*l_bpp_d + i*bpp_d + 1] = ps[j*l_bpp_s + i*bpp_s + 0];
                pd[ji*l_bpp_d + i*bpp_d + 2] = ps[j*l_bpp_s + i*bpp_s + 0];
                pd[ji*l_bpp_d + i*bpp_d + 3] = 255;
            }
        }
    }
    else {
        dbg_pe("unsupport jpeg num_components (%d)!\n", cinfo.num_components);
        ret = -1;
    }

    // free buffer
    delete ps;

    return ret;
}

int RTK_Image::to_sdl(SDL_Surface **sdl_surf)
{
    SDL_Surface     *surf;
    uint32          rmask, gmask, bmask, amask;
    uint8           *pd, *ps;
    int             w, h, bpp;
    uint32          bmask_sdl;

    // check image exist
    if( m_pri_data == NULL )
        return -1;

    // FIXME: just for intel CPU
    rmask = 0x00ff0000;
    gmask = 0x0000ff00;
    bmask = 0x000000ff;
    amask = 0x00000000;

    // check old object exist
    surf = *sdl_surf;
    if( surf != NULL ) {
        try {
            w = surf->w;
            h = surf->h;
            bpp = surf->format->BytesPerPixel;
            bmask_sdl = surf->format->Bmask;
        } catch(...) {
            dbg_pw("input parameter not initialized!\n");
            goto TO_SDL_1;
        }

        // check old SDL_Surface format is matched
        if( w != m_iw || h != m_ih || bpp != 4 || bmask_sdl != bmask )
            goto TO_SDL_1;

        // if matched, then directly copy image buffer
        goto TO_SDL_2;
    }

TO_SDL_1:
    // create SDL surface
    surf = SDL_CreateRGBSurface(
                SDL_SWSURFACE,
                m_iw, m_ih,
                32,
                rmask, gmask, bmask, amask);
    if( surf == NULL ) {
        dbg_pe("SDL_CreateRGBSurface failed!\n");
        return -1;
    }

TO_SDL_2:
    // copy image buffer
    ps = get_bits();
    pd = (uint8*) surf->pixels;
    memcpy(pd, ps, m_iw*m_ih*4);

    // return
    *sdl_surf = surf;

    return 0;
}

int RTK_Image::from_sdl(SDL_Surface *sdl_surf)
{
    int             i;
    int             w, h;
    uint8           *pd, *ps;
    int             bpp_s;

    // check input SDL_Surface
    if( sdl_surf == NULL ) {
        dbg_pe("input SDL_Surface not exist!\n");
        return -1;
    }

    // get image w, h, bpp
    try {
        w = sdl_surf->w;
        h = sdl_surf->h;
        bpp_s = sdl_surf->format->BytesPerPixel;
    } catch(...) {
        dbg_pe("input SDL_Surface not exist!\n");
        return -1;
    }

    // renew image size if necessary
    if( m_pri_data == NULL || w != m_iw || h != m_ih )
        alloc(w, h);

    // get image buffer
    pd = get_bits();
    ps = (uint8*) sdl_surf->pixels;

    // copy image buffer
    if( bpp_s == 3 ) {
        if( sdl_surf->format->Bmask == 0xFF ) {
            for(i=0; i<w*h; i++) {
                pd[0] = ps[0];
                pd[1] = ps[1];
                pd[2] = ps[2];
                pd[3] = 0xFF;

                pd += 4;
                ps += 3;
            }
        } else {
            dbg_pe("input SDL surface not supported! (byte order)\n");
            return -1;
        }
    } else if ( bpp_s == 4 ) {
        if( sdl_surf->format->Bmask == 0xFF ) {
            for(i=0; i<w*h; i++) {
                pd[0] = ps[0];
                pd[1] = ps[1];
                pd[2] = ps[2];
                pd[3] = 0xFF;

                pd += 4;
                ps += 4;
            }
        } else {
            dbg_pe("input SDL surface not supported! (byte order)\n");
            return -1;
        }
    } else {
        dbg_pe("input SDL surface not supported! (bpp size)\n");
        return -1;
    }

    // return
    return 0;
}

/******************************************************************************
 * Return private SDL_Surface object (Fast speed)
 *****************************************************************************/
SDL_Surface* RTK_Image::to_sdl(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data != NULL ) {
        p_dat = (rtk_image_dat *) m_pri_data;
        return p_dat->sdl;
    }

    return NULL;
}


/******************************************************************************
 * Convert RTK_Image to QImage
 *
 * NOTE:
 *  QImage didn't create new image buffer, so RTK_Image can not be deleted.
 *****************************************************************************/
int RTK_Image::to_QImage(QImage **qimage)
{
    QImage  *img;
    uint8   *pd;
    int     w, h;

    // check image exist
    if( m_pri_data == NULL )
        return -1;

    // check input argument
    img = *qimage;
    if( img != NULL ) {
        try {
            w = img->width();
            h = img->height();
        } catch(...) {
            dbg_pw("input QImage pointer not initialized!\n");
            goto TO_QIMAGE_1;
        }

        // delete old object
        delete img;
    }

TO_QIMAGE_1:
    // create QImage object
    pd = get_bits();
    img = new QImage(pd, m_iw, m_ih, QImage::Format_ARGB32);
    *qimage = img;

    return 0;
}

int RTK_Image::from_QImage(QImage *qimage)
{
    int             w, h;
    QImage::Format  img_fmt;
    QImage          img;
    unsigned char   *ps, *pd;

    // get input image size, format
    w = qimage->width();
    h = qimage->height();
    img_fmt = qimage->format();

    // alloc new image buffer if necessary
    if( m_pri_data == NULL || m_iw != w || m_ih != h )
        alloc(w, h);

    // get image buffer
    pd = get_bits();
    if( img_fmt != QImage::Format_ARGB32 ) {
        img = qimage->convertToFormat(QImage::Format_ARGB32);
        ps = img.bits();
    } else
        ps = qimage->bits();

    // copy image buffer
    memcpy(pd, ps, w*h*4);

    return 0;
}

/******************************************************************************
 * Return private QImage object (Fast speed)
 *****************************************************************************/
QImage* RTK_Image::to_QImage(void)
{
    rtk_image_dat    *p_dat;

    if( m_pri_data != NULL ) {
        p_dat = (rtk_image_dat *) m_pri_data;
        return p_dat->q_img;
    }

    return NULL;
}

/******************************************************************************
 * Convert to OpenCV Mat
 *****************************************************************************/
int RTK_Image::to_mat(Mat **cv_img)
{
    int     i, j;
    uint8   *ps, *pd;
    Mat     *img;
    int     w, h, c;

    // check image buffer
    if( m_pri_data == NULL )
        return -1;

    // create OpenCV Mat if necessary
    img = *cv_img;
    if( img != NULL ) {
        try {
            w = img->cols;
            h = img->rows;
            c = img->channels();
        } catch(...) {
            // alough point is not NULL, but acutally object is not created
            // or pointer is not initialized
            dbg_pw("input cv_img not initialized!\n");
            goto TO_MAT_1;
        }

        if( w != m_iw || h != m_ih || c != 3 ) {
            // if input Mat is not matched, then delete old obj
            delete img;
            goto TO_MAT_1;
        } else {
            // if input Mat is matched, then direct copy
            goto TO_MAT_2;
        }
    }

TO_MAT_1:
    img = new Mat(m_ih, m_iw, CV_8UC3);

TO_MAT_2:
    // get image buffer
    pd = img->data;
    ps = get_bits();

    // copy image buffer
    for(i=0; i<m_iw*m_ih; i++) {
        pd[0] = ps[0];
        pd[1] = ps[1];
        pd[2] = ps[2];

        pd += 3;
        ps += 4;
    }

    *cv_img = img;

    return 0;
}

int RTK_Image::from_mat(Mat *cv_img)
{
    int             w, h, c;
    unsigned char   *ps, *pd;
    int             i;

    // get input image size, format
    try {
        w = cv_img->cols;
        h = cv_img->rows;
        c = cv_img->channels();
    } catch(...) {
        dbg_pe("input cv_img not exist!\n");
        return -1;
    }

    // alloc new image buffer
    if( m_pri_data == NULL || m_iw != w || m_ih != h )
        alloc(w, h);

    // get image buffer
    pd = get_bits();
    ps = cv_img->data;

    // copy image data
    if( c == 3 ) {
        for(i=0; i<w*h; i++) {
            pd[0] = ps[0];
            pd[1] = ps[1];
            pd[2] = ps[2];
            pd[3] = 0xFF;

            pd += 4;
            ps += 3;
        }
    } else if ( c == 1 ) {
        for(i=0; i<w*h; i++) {
            pd[0] = ps[0];
            pd[1] = ps[0];
            pd[2] = ps[0];
            pd[3] = 0xFF;

            pd += 4;
            ps += 1;
        }
    } else {
        dbg_pe("Unsupported OpenCV Mat format!\n");
        return -1;
    }

    return 0;
}

} // end of namespace rtk

